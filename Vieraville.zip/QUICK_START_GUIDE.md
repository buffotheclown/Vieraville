# VieraVille - Quick Start Guide

## 🎮 Your First 10 Minutes

Welcome to VieraVille! This guide will get you from title screen to thriving community in just a few minutes.

---

## Step 1: Launch the Game

1. Open `index.html` in your browser
2. **Click anywhere** on the title screen (initializes sound)
3. Click **"START NEW TOWN"**

---

## Step 2: Hire Your First Manager

You'll see 10 managers to choose from. For your first game, we recommend:

### Best First-Time Manager: **Alex Chen** (Balanced Developer)
- No specialty, but no weaknesses
- Good all-around choice
- Easy to understand

### Alternative Choices:
- **Maria Rodriguez** - Great for residential focus
- **James Thompson** - Commercial specialist for early revenue
- **David Park** - Civic buildings for happiness

**Click on Alex Chen**, then click **"BEGIN CONSTRUCTION"**

---

## Step 3: Understand the Interface

### Top Bar (Status)
- **Logo** - VieraVille (that's you!)
- **Date** - Current year, season, month
- **💰** - Your budget ($5.00M to start)
- **👥** - Population (0 at start)
- **😊** - Town happiness (100% at start)
- **🔊** - Sound toggle (press M to mute)

### Left Panel (Managers)
- Shows your hired manager(s)
- Click to view details
- "Hire" button appears when slots unlock

### Right Panel (Dashboard)
- Revenue breakdown
- Population stats
- Happiness factors
- Building counts

---

## Step 4: Approve Your First Plan

**Within 30 seconds**, Alex will propose a construction plan:

1. A **notification toast** appears (bottom-right)
2. Alex's card in the left panel shows **"Proposing"**
3. **Click on Alex's card** to open details
4. Review the plan:
   - Building type (e.g., Small Houses)
   - Quantity (e.g., 3 buildings)
   - Total cost (e.g., $150K)
5. Click the **green checkmark** ✅ to approve

---

## Step 5: Watch Construction

After approval:
1. Alex's status changes to **"Building"**
2. A small **manager entity** appears on the map
3. Watch as roads are built tile-by-tile
4. Buildings appear along the road
5. When complete, Alex returns to **"Idle"**

**This takes about 30-60 seconds in real-time**

---

## Step 6: Wait for Monthly Update

Every **10 seconds = 1 game month**:
1. You'll hear a subtle sound
2. **Revenue is calculated** from your buildings
3. **Population grows** in residential buildings
4. **Budget updates** in the top bar
5. A **toast notification** shows monthly profit/loss

**Watch your first month pass!**

---

## Step 7: Approve More Plans

Alex will generate new plans every 30 seconds:
- **Always review** before approving
- Check if you can **afford** the cost
- Balance **residential** (population) and **commercial** (jobs/revenue)
- Deny plans you don't like (red X ❌)

---

## Step 8: Monitor Happiness

Keep happiness above **70%** for victory:

**Open Dashboard (right panel) → Happiness tab:**
- **Employment** - Need jobs for population
- **Diversity** - Build different building types
- **Amenities** - Add parks, schools, hospitals
- **Housing** - Upgrade to better residences
- **Relationships** - Manager likes/dislikes (unlocks with multiple managers)

**Tip:** If happiness drops below 60%, focus on civic/recreational buildings!

---

## Step 9: Manage Your Budget

**If budget gets low (<$500K):**
1. **Deny expensive plans** temporarily
2. Wait for **monthly revenue** to accumulate
3. Build **commercial/industrial** for high revenue
4. Check **Dashboard → Revenue** tab for breakdown

**If budget goes negative:**
- You can still operate at a loss
- But below **-$100K = bankruptcy** (game over!)

---

## Step 10: Unlock More Managers

**Population Milestones:**
- **500 pop** → Unlock 2nd manager slot + $250K bonus
- **1,000 pop** → $500K bonus
- **5,000 pop** → $1M bonus + efficiency boost
- **10,000 pop** → $2M bonus + unlock 5th manager slot

**To hire more managers:**
1. Click **"Hire Additional Manager"** in left panel
2. Choose compatible managers (avoid 💔 conflicts)
3. Hire up to **5 total managers**

---

## Step 11: Handle Random Events

Every **~1 minute**, a random event occurs:
- **Positive** (green): Tourism boom, grants → +money/happiness
- **Negative** (red): Hurricane, scandal → -money/happiness
- **Neutral** (blue): News coverage → minor effects

**Just read and click "Close"** - effects are automatic!

---

## Step 12: Aim for Victory

**Victory Condition:**
- **16,000 population**
- **70% happiness**

**Strategy:**
1. **Early game (0-1K pop):** Build residential, approve all plans
2. **Mid game (1K-5K):** Balance residential + commercial for jobs
3. **Late game (5K-16K):** Add civic/recreational for happiness, hire more managers
4. **Always:** Monitor dashboard, keep budget positive, maintain 70%+ happiness

---

## 🎯 Quick Tips

### Do's ✅
- ✅ Approve plans early to build momentum
- ✅ Balance residential and commercial buildings
- ✅ Monitor happiness factors in Dashboard
- ✅ Save frequently (Ctrl+S)
- ✅ Hire compatible managers (green 💚 indicators)

### Don'ts ❌
- ❌ Don't spend all your money at once
- ❌ Don't ignore happiness warnings
- ❌ Don't hire conflicting managers early
- ❌ Don't deny all plans (managers need to work!)
- ❌ Don't forget to build civic/recreational

---

## ⌨️ Essential Controls

### Camera
- **Mouse Drag:** Pan around map
- **Scroll Wheel:** Zoom in/out
- **W/A/S/D:** Pan with keyboard

### Shortcuts
- **M:** Mute/unmute sound
- **Ctrl+S / Cmd+S:** Quick save
- **Click Manager Card:** View details

---

## 🐛 Common Issues

### "Nothing is happening!"
- Make sure you **approved a plan** (green checkmark)
- Check if manager status shows **"Building"**
- Wait for construction to complete (~30-60 seconds)

### "Happiness dropped suddenly!"
- Check **random events** (bottom-right toasts)
- Review **Dashboard → Happiness** for low factors
- Build **parks, schools, hospitals** to boost happiness

### "I'm running out of money!"
- **Deny expensive plans** temporarily
- Build **commercial/industrial** for revenue
- Wait for **monthly income** to accumulate
- Check if **costs > revenue** in Dashboard

### "No sound playing!"
- Make sure you **clicked to initialize** audio
- Check **sound toggle** (🔊 should show, not 🔇)
- Press **M** to toggle
- Check browser console for errors

---

## 📊 First Victory Timeline

**Realistic first-time victory: 30-60 minutes**

- **Minutes 0-5:** Hire Alex, approve 2-3 plans
- **Minutes 5-15:** Reach 500 population, hire 2nd manager
- **Minutes 15-30:** Reach 1,000 population, build commercial
- **Minutes 30-45:** Reach 5,000 population, hire more managers
- **Minutes 45-60:** Push to 16,000 population, maintain 70% happiness
- **Victory!** 🎉

---

## 🎓 Advanced Strategies (After First Win)

### Specialization Strategy
- Hire **Maria Rodriguez** → Spam residential buildings → Fast population growth
- Hire **James Thompson** → Spam commercial → High revenue → Buy whatever you want

### Balanced Strategy
- Hire **Alex Chen** + **Priya Patel** → Mix of everything → Stable growth

### Speed Run Strategy
- Hire **Maria** + **James** + **Emily** → Aggressive expansion → 16K in 20 minutes

### Happiness-First Strategy
- Hire **David Park** + **Emily Zhang** → Civic/recreational focus → 90% happiness easy mode

---

## 🏆 You're Ready!

Now you know the basics. Remember:
1. **Hire a manager**
2. **Approve plans**
3. **Watch construction**
4. **Monitor happiness**
5. **Reach 16,000 population**
6. **Maintain 70% happiness**
7. **WIN!**

**Good luck, Developer!** Build the best VieraVille possible! 🏖️

---

**Pro Tip:** Press **M** to mute sound during long sessions, and **Ctrl+S** to save before experimenting with risky strategies!

**Need help?** Check the full **CONTROLS_REFERENCE.md** for detailed information.
