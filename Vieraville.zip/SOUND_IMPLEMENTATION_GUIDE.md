# Sound Implementation Guide

## Sound Files
- **sound_button.wav** - All UI clicks and buttons
- **sound_positive.wav** - Achievements, hires, victories, positive events  
- **sound_negative.wav** - Fires, defeats, negative events, errors

## Implementation Pattern

### 1. Pass `soundManager` as prop
```javascript
// Parent component
React.createElement(ChildComponent, {
  ...otherProps,
  soundManager: soundManager
})

// Child component
export function ChildComponent({ ...otherProps, soundManager }) {
  // Use soundManager in handlers
}
```

### 2. Call sounds in event handlers
```javascript
// Button click
const handleClick = () => {
  if (soundManager) soundManager.playButton();
  // Rest of handler logic
};

// Positive action
const handleSuccess = () => {
  if (soundManager) soundManager.playPositive();
  // Rest of handler logic
};

// Negative action
const handleError = () => {
  if (soundManager) soundManager.playNegative();
  // Rest of handler logic
};
```

## Components Needing Sound Implementation

### ✅ COMPLETED
- [x] TitleScreen - Continue, New Game buttons
- [x] ConfirmModal - Yes/No buttons
- [x] GameScene - Approve/Deny plans, Raise, Fire, Hire button

### ⏳ TODO: Manager Selection
**File:** `/components/scenes/ManagerSelection.js`
- [ ] Button: Click manager card (playButton)
- [ ] Button: "Back to Game" button (playButton)
- [ ] Positive: Hire manager success (playPositive)
- [ ] Negative: Can't hire (conflict, max managers) (playNegative)

### ⏳ TODO: Options Modal
**File:** `/components/modals/OptionsModal.js`
- [ ] Button: All speed buttons (playButton)
- [ ] Button: Sound toggle button (playButton)
- [ ] Button: Resume Game button (playButton)
- [ ] Button: Close button (playButton)

### ⏳ TODO: Manager Detail Modal
**File:** `/components/modals/ManagerDetailModal.js`
- [ ] Button: Plan selection tabs (playButton)
- [ ] Button: Approve Plan button (playPositive)
- [ ] Button: Deny Plan button (playNegative)
- [ ] Button: Give Raise button (playPositive or playNegative if can't afford)
- [ ] Button: Fire Manager button (playNegative)
- [ ] Button: Close modal (playButton)

### ⏳ TODO: Event Modal
**File:** `/components/modals/EventModal.js`
- [ ] Button: Close button (playButton)
- [ ] Positive: When positive event shows (playPositive) - call in GameScene when setCurrentEvent
- [ ] Negative: When negative event shows (playNegative) - call in GameScene when setCurrentEvent

### ⏳ TODO: Victory/Defeat Modals
**File:** `/components/modals/VictoryModal.js`
- [ ] Positive: When modal opens (playPositive)
- [ ] Button: Continue button (playButton)
- [ ] Button: Restart button (playButton)

**File:** `/components/modals/DefeatModal.js`
- [ ] Negative: When modal opens (playNegative)
- [ ] Button: Restart button (playButton)
- [ ] Button: Quit button (playButton)

### ⏳ TODO: Save/Load Modal
**File:** `/components/modals/SaveLoadModal.js`
- [ ] Button: Save button (playButton)
- [ ] Button: Load button (playButton)
- [ ] Button: Delete save button (playNegative)
- [ ] Button: Close button (playButton)
- [ ] Positive: Successful save (playPositive)
- [ ] Positive: Successful load (playPositive)

### ⏳ TODO: Plan Proposal Notification
**File:** `/components/modals/PlanProposalNotification.js`
- [ ] Button: "View Plans" button (playButton)
- [ ] Button: "Later" button (playButton)

### ⏳ TODO: Manager Panel
**File:** `/components/hud/ManagerPanel.js`
- [ ] Button: Click manager card (playButton)
- [ ] Button: "Hire Manager" button (playButton)

### ⏳ TODO: Dashboard Panel
**File:** `/components/hud/DashboardPanel.js`
- No buttons currently, but if any are added, use playButton()

## Event-Based Sounds (Handle in GameScene)

### Revenue Events
```javascript
// In GameScene, listen for revenue-calculated event
useEffect(() => {
  const handleRevenue = (report) => {
    if (report.net > 0) {
      if (soundManager) soundManager.playPositive();
    } else if (report.net < 0) {
      if (soundManager) soundManager.playNegative();
    }
  };
  
  gameState.on('revenue-calculated', handleRevenue);
  return () => gameState.off('revenue-calculated', handleRevenue);
}, [gameState, soundManager]);
```

### Random Events
```javascript
// In GameScene, when setting currentEvent
const handleRandomEvent = (eventData) => {
  // Play sound based on event result
  if (eventData.result && eventData.result.budget) {
    if (eventData.result.budget > 0) {
      if (soundManager) soundManager.playPositive();
    } else {
      if (soundManager) soundManager.playNegative();
    }
  }
  
  setCurrentEvent({
    type: 'event',
    name: eventData.name,
    message: eventData.message,
    result: eventData.result
  });
};
```

### Milestones
```javascript
// In GameScene, when milestone achieved
const handleMilestone = (milestoneData) => {
  if (soundManager) soundManager.playPositive(); // Achievements are positive
  
  setCurrentEvent({
    type: 'milestone',
    name: milestoneData.name,
    message: 'Congratulations!',
    description: milestoneData.description,
    reward: milestoneData.reward
  });
};
```

### Victory/Defeat
```javascript
// In GameScene, when gameEndState changes
useEffect(() => {
  if (gameEndState) {
    if (gameEndState.type === 'victory') {
      if (soundManager) soundManager.playPositive();
    } else if (gameEndState.type === 'defeat') {
      if (soundManager) soundManager.playNegative();
    }
  }
}, [gameEndState, soundManager]);
```

## Testing Checklist

After implementing sounds in a component:
- [ ] Test with sound enabled
- [ ] Test with sound disabled (should work silently)
- [ ] Test rapid clicking (sounds should overlap gracefully)
- [ ] Verify correct sound type (button/positive/negative)

## Notes

- Always check `if (soundManager)` before calling sound methods
- Sounds will fail gracefully if not initialized
- Browser autoplay policies may prevent sounds until user interaction
- Sound cloning allows overlapping sounds (multiple buttons clicked rapidly)
