# VieraVille Sound System Documentation

## Overview
The game features a comprehensive procedural audio system using Tone.js, providing dynamic sound effects for all major game events without requiring audio file assets.

## Architecture

### SoundManager (`/managers/SoundManager.js`)
Central audio controller that manages all sound generation and playback using Tone.js synthesizers.

**Key Features:**
- Procedural sound generation (no audio files needed)
- Multiple synthesizers for different sound types
- Master volume control with mute/unmute
- Safe initialization (requires user interaction per browser requirements)
- Clean disposal system

## Sound Categories

### 1. UI Sounds
- **Click** - Sharp sine wave for button clicks
- **Hover** - Soft sine wave for button hovers
- **Modal Open** - Two-note ascending arpeggio
- **Modal Close** - Two-note descending arpeggio
- **Success** - Uplifting two-note confirmation
- **Error** - Low warning tone

### 2. Money Sounds
- **Coin Gain** - Bright metallic chime (positive revenue)
- **Coin Loss** - Lower metallic tone (negative revenue)
- **Big Money** - Rapid succession of coin sounds (events, milestones)

### 3. Building Sounds
- **Building Placed** - Harmonic chord based on building type
  - Residential: C-E-G (major)
  - Commercial: D-F#-A (major)
  - Industrial: E-G-B (major)
  - Civic: F-A-C (major)
  - Recreational: G-B-D (major)
- **Construction** - Brief noise burst for placement
- **Building Demolished** - Dissonant minor chord

### 4. Manager Sounds
- **Manager Hired** - Ascending melody (C-E-G-C)
- **Plan Proposed** - Two-note question tone
- **Plan Approved** - Success chime
- **Plan Denied** - Error tone

### 5. Event Sounds
- **Positive Event** - Rising major chord progression
- **Negative Event** - Falling minor chord progression
- **Neutral Event** - Stable two-note chord

### 6. Milestone Sounds
- **Milestone Achieved** - Grand fanfare with rising chords
- **Victory** - Extended celebratory melody
- **Defeat** - Somber descending melody

### 7. Ambient Sounds
- **Month Change** - Subtle ambient tone
- **Season Change** - Seasonal themed notes
  - Spring: E (renewal)
  - Summer: G (bright)
  - Fall: A (warm)
  - Winter: C (cool)

## Integration Points

### GameScene.js
Main integration hub with event listeners for:
- Revenue calculations
- Population updates
- Manager actions (plan proposed/approved/denied)
- Month/season changes
- Building placement
- Random events
- Milestones
- Victory/Defeat conditions

### ManagerSelection.js
Sounds for:
- Manager card clicks
- Hiring managers
- Error feedback for unavailable managers

### TitleScreen.js
Sounds for:
- Button hovers
- Start/Continue game
- Error on cancellation

### TopHUD.js
Features:
- Sound toggle button (🔊/🔇)
- Persistent volume control
- Visual feedback for sound state
- Keyboard shortcut: Press **M** to toggle mute
- Keyboard shortcut: **Ctrl+S** / **Cmd+S** to save game

## Technical Details

### Synthesizers Used
1. **UI Synth** - Clean sine waves (attack: 5ms, decay: 100ms)
2. **Coin Synth** - MetalSynth for metallic sounds
3. **Building Synth** - PolySynth with triangle waves for chords
4. **Event Synth** - PolySynth with square waves for dramatic effects
5. **Ambient Synth** - Soft sine waves with long attack/release
6. **Noise Synth** - White noise for construction effects

### Initialization
- Audio context starts on first user click (browser requirement)
- Graceful fallback if audio initialization fails
- Test sound plays on successful initialization

### Volume Control
- Master gain node controls all audio
- Volume range: -60dB to 0dB
- Smooth ramping for volume changes
- Separate enable/disable toggle

## Usage Example

```javascript
// In GameScene.js
const soundManager = new SoundManager(gameState);
await soundManager.initialize();

// Play sounds
soundManager.playUIClick();
soundManager.playBuildingPlaced('residential');
soundManager.playPositiveEvent();

// Control volume
soundManager.setVolume(-10); // Set to -10dB
soundManager.toggle(); // Mute/unmute

// Cleanup
soundManager.dispose();
```

## Event Listening Pattern

```javascript
useEffect(() => {
  const handleEvent = (data) => {
    if (soundManager) {
      soundManager.playEventSound();
    }
  };

  gameState.on('event-name', handleEvent);
  return () => gameState.off('event-name', handleEvent);
}, [gameState, soundManager]);
```

## Browser Compatibility
- Uses Web Audio API (supported by all modern browsers)
- Requires user interaction before audio playback (browser security policy)
- Graceful degradation if audio is blocked
- No external dependencies (Tone.js loaded via importmap)

## Performance
- Minimal CPU usage (procedural synthesis is efficient)
- No network requests for audio files
- Instantaneous sound generation
- No memory overhead from audio buffers

## Future Enhancements (Optional)
- Volume slider in settings menu
- Individual volume controls per category
- Background music loops
- More complex melodies for major events
- Spatial audio for entity positions

---

**Status:** ✅ Fully Implemented and Integrated
**Version:** 1.0
**Last Updated:** Current Session
