/**
 * GameCanvas.js
 * Main canvas renderer with camera controls
 * Composites all three layers: terrain, roads, buildings
 */

import React, { useRef, useEffect, useState, memo } from 'react';
import { GRID } from '../../constants/gameConfig.js';
import { COLORS } from '../../constants/uiConstants.js';
import { renderEntities } from './EntityLayer.js';

function GameCanvasComponent({ gridManager, managers, managerCoordinator, onCameraChange, onTileClick }) {
  const canvasRef = useRef(null);
  const [camera, setCamera] = useState({
    x: 0,
    y: 0,
    zoom: 1.0,
    canvas: null
  });
  const [isPanning, setIsPanning] = useState(false);
  const [lastMousePos, setLastMousePos] = useState({ x: 0, y: 0 });
  const [mouseDownPos, setMouseDownPos] = useState({ x: 0, y: 0 });

  // Clamp camera position to keep map edges within viewport (with 300px padding)
  const clampCamera = (x, y, zoom, canvas) => {
    if (!canvas) return { x, y };
    
    const mapWidth = GRID.WIDTH * GRID.TILE_SIZE * zoom;
    const mapHeight = GRID.HEIGHT * GRID.TILE_SIZE * zoom;
    const canvasWidth = canvas.width;
    const canvasHeight = canvas.height;
    const padding = 300; // Allow 300px of movement beyond map edges
    
    // Calculate bounds with padding - allow camera to move 300px beyond map edges
    const minX = canvasWidth - mapWidth - padding;  // Max pan right (with padding)
    const maxX = padding;                           // Max pan left (with padding)
    const minY = canvasHeight - mapHeight - padding; // Max pan down (with padding)
    const maxY = padding;                           // Max pan up (with padding)
    
    // If map is smaller than viewport, center it
    const clampedX = mapWidth < canvasWidth 
      ? (canvasWidth - mapWidth) / 2  // Center horizontally
      : Math.max(minX, Math.min(maxX, x));
      
    const clampedY = mapHeight < canvasHeight
      ? (canvasHeight - mapHeight) / 2  // Center vertically
      : Math.max(minY, Math.min(maxY, y));
    
    return { x: clampedX, y: clampedY };
  };

  // Initial camera position (center of map)
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Set initial cursor to default pointer
    canvas.style.cursor = 'default';

    // Center on the middle of the 100x100 tile map
    // Map center in world coordinates: (50, 50) tiles = (1600, 1600) pixels
    const mapCenterX = (GRID.WIDTH / 2) * GRID.TILE_SIZE;
    const mapCenterY = (GRID.HEIGHT / 2) * GRID.TILE_SIZE;
    
    const zoomLevel = 0.75;
    
    // Calculate camera offset to center the map center on screen
    let x = (canvas.width / 2) - (mapCenterX * zoomLevel);
    let y = (canvas.height / 2) - (mapCenterY * zoomLevel);
    
    // Apply bounds clamping
    const clamped = clampCamera(x, y, zoomLevel, canvas);
    
    const newCamera = {
      x: clamped.x,
      y: clamped.y,
      zoom: zoomLevel,
      canvas: canvas
    };
    
    setCamera(newCamera);
    
    // Notify parent of camera changes
    if (onCameraChange) {
      onCameraChange(newCamera);
    }
  }, [onCameraChange]);
  
  // FIXED PROBLEM #8: Use ref to avoid dependency hell
  const onCameraChangeRef = useRef(onCameraChange);
  useEffect(() => {
    onCameraChangeRef.current = onCameraChange;
  }, [onCameraChange]);
  
  // Notify parent whenever camera changes
  useEffect(() => {
    if (onCameraChangeRef.current && camera.canvas) {
      onCameraChangeRef.current(camera);
    }
  }, [camera]);

  // Render loop - continuous animation
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas || !gridManager) {
      return;
    }

    const ctx = canvas.getContext('2d');
    let animationFrameId;
    let frameCount = 0;
    let firstRenderLogged = false;
    
    const render = () => {
      const frameStart = performance.now();
      
      // Clear canvas
      ctx.fillStyle = '#000000';
      ctx.fillRect(0, 0, canvas.width, canvas.height);

      // Save context state
      ctx.save();

      // Apply camera transform
      ctx.translate(camera.x, camera.y);
      ctx.scale(camera.zoom, camera.zoom);

      // Get pop animations if available
      const popAnimations = managerCoordinator && managerCoordinator.constructionEffects 
        ? managerCoordinator.constructionEffects.getPopAnimations() 
        : [];
      
      // Render all layers
      renderTerrainLayer(ctx, gridManager);
      renderRoadLayer(ctx, gridManager, popAnimations);
      renderBuildingLayer(ctx, gridManager, popAnimations);
      
      // Render construction effects (construction tiles + particles)
      if (managerCoordinator && managerCoordinator.constructionEffects) {
        renderConstructionLayer(ctx, gridManager, managerCoordinator.constructionEffects);
      }
      
      // Render manager entities
      if (managers && managers.length > 0) {
        renderEntities(ctx, managers);
      }

      // Restore context
      ctx.restore();

      // Render UI overlays (zoom level, etc)
      renderUI(ctx, camera);
      
      frameCount++;
      
      // Continue animation loop
      animationFrameId = requestAnimationFrame(render);
    };

    render();
    
    return () => {
      if (animationFrameId) {
        cancelAnimationFrame(animationFrameId);
      }
    };
  }, [gridManager, camera, managers, managerCoordinator]);

  // Mouse event handlers for panning
  const handleMouseDown = (e) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Always start panning on mouse down - we'll check for clicks in mouseUp
    canvas.style.cursor = 'grabbing';
    setIsPanning(true);
    setLastMousePos({ x: e.clientX, y: e.clientY });
    setMouseDownPos({ x: e.clientX, y: e.clientY });
  };

  const handleMouseMove = (e) => {
    if (!isPanning) return;

    const dx = e.clientX - lastMousePos.x;
    const dy = e.clientY - lastMousePos.y;

    setCamera(prev => {
      const newX = prev.x + dx;
      const newY = prev.y + dy;
      const clamped = clampCamera(newX, newY, prev.zoom, canvasRef.current);
      
      return {
        ...prev,
        x: clamped.x,
        y: clamped.y,
        canvas: canvasRef.current
      };
    });

    setLastMousePos({ x: e.clientX, y: e.clientY });
  };

  const handleMouseUp = (e) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    setIsPanning(false);
    
    // ALWAYS reset cursor to default after mouse up
    canvas.style.cursor = 'default';
    
    // Check if this was a click (not a drag) - INCREASED TOLERANCE
    const dx = Math.abs(e.clientX - mouseDownPos.x);
    const dy = Math.abs(e.clientY - mouseDownPos.y);
    const wasClick = dx < 10 && dy < 10; // Increased tolerance to 10px
    
    if (wasClick && onTileClick) {
      // Convert screen coordinates to world coordinates
      const rect = canvas.getBoundingClientRect();
      const mouseX = e.clientX - rect.left;
      const mouseY = e.clientY - rect.top;
      
      // Convert to world position
      const worldX = (mouseX - camera.x) / camera.zoom;
      const worldY = (mouseY - camera.y) / camera.zoom;
      
      // Convert to grid coordinates
      const tileX = Math.floor(worldX / GRID.TILE_SIZE);
      const tileY = Math.floor(worldY / GRID.TILE_SIZE);
      
      // Check if within bounds
      if (tileX >= 0 && tileX < GRID.WIDTH && tileY >= 0 && tileY < GRID.HEIGHT) {
        onTileClick(tileX, tileY);
      }
    }
  };

  const handleWheel = (e) => {
    e.preventDefault();
    
    // Get mouse position relative to canvas
    const rect = canvasRef.current.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    
    // Calculate world position before zoom
    const worldXBefore = (mouseX - camera.x) / camera.zoom;
    const worldYBefore = (mouseY - camera.y) / camera.zoom;
    
    // Apply zoom (can zoom in beyond 0.75, but can't zoom out below 0.75)
    const zoomFactor = e.deltaY > 0 ? 0.9 : 1.1;
    const newZoom = Math.max(0.75, Math.min(3.0, camera.zoom * zoomFactor));
    
    // Calculate world position after zoom
    const worldXAfter = (mouseX - camera.x) / newZoom;
    const worldYAfter = (mouseY - camera.y) / newZoom;
    
    // Adjust camera position to keep mouse pointer over same world position
    const offsetX = (worldXAfter - worldXBefore) * newZoom;
    const offsetY = (worldYAfter - worldYBefore) * newZoom;

    setCamera(prev => {
      const newX = prev.x + offsetX;
      const newY = prev.y + offsetY;
      const clamped = clampCamera(newX, newY, newZoom, canvasRef.current);
      
      return {
        x: clamped.x,
        y: clamped.y,
        zoom: newZoom,
        canvas: canvasRef.current
      };
    });
  };



  // Keyboard controls
  useEffect(() => {
    const handleKeyDown = (e) => {
      const panSpeed = 20;

      switch (e.key) {
        case 'w':
        case 'W':
        case 'ArrowUp':
          setCamera(prev => {
            const clamped = clampCamera(prev.x, prev.y + panSpeed, prev.zoom, canvasRef.current);
            return { ...prev, x: clamped.x, y: clamped.y, canvas: canvasRef.current };
          });
          break;
        case 's':
        case 'S':
        case 'ArrowDown':
          setCamera(prev => {
            const clamped = clampCamera(prev.x, prev.y - panSpeed, prev.zoom, canvasRef.current);
            return { ...prev, x: clamped.x, y: clamped.y, canvas: canvasRef.current };
          });
          break;
        case 'a':
        case 'A':
        case 'ArrowLeft':
          setCamera(prev => {
            const clamped = clampCamera(prev.x + panSpeed, prev.y, prev.zoom, canvasRef.current);
            return { ...prev, x: clamped.x, y: clamped.y, canvas: canvasRef.current };
          });
          break;
        case 'd':
        case 'D':
        case 'ArrowRight':
          setCamera(prev => {
            const clamped = clampCamera(prev.x - panSpeed, prev.y, prev.zoom, canvasRef.current);
            return { ...prev, x: clamped.x, y: clamped.y, canvas: canvasRef.current };
          });
          break;
        case '+':
        case '=':
          // Zoom in (max 3.0)
          setCamera(prev => {
            const newZoom = Math.min(3.0, prev.zoom * 1.1);
            const clamped = clampCamera(prev.x, prev.y, newZoom, canvasRef.current);
            return { ...prev, x: clamped.x, y: clamped.y, zoom: newZoom, canvas: canvasRef.current };
          });
          break;
        case '-':
        case '_':
          // Zoom out (min 0.75 - can't go below starting zoom)
          setCamera(prev => {
            const newZoom = Math.max(0.75, prev.zoom * 0.9);
            const clamped = clampCamera(prev.x, prev.y, newZoom, canvasRef.current);
            return { ...prev, x: clamped.x, y: clamped.y, zoom: newZoom, canvas: canvasRef.current };
          });
          break;
        case ' ':
          // Reset to center at max zoom (0.75)
          const resetZoom = 0.75;
          const mapCenterX = (GRID.WIDTH / 2) * GRID.TILE_SIZE;
          const mapCenterY = (GRID.HEIGHT / 2) * GRID.TILE_SIZE;
          const resetX = (canvasRef.current.width / 2) - (mapCenterX * resetZoom);
          const resetY = (canvasRef.current.height / 2) - (mapCenterY * resetZoom);
          const resetClamped = clampCamera(resetX, resetY, resetZoom, canvasRef.current);
          setCamera(prev => ({
            ...prev,
            x: resetClamped.x,
            y: resetClamped.y,
            zoom: resetZoom,
            canvas: canvasRef.current
          }));
          break;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return React.createElement('canvas', {
    ref: canvasRef,
    width: window.innerWidth,
    height: window.innerHeight,
    style: styles.canvas,
    onMouseDown: handleMouseDown,
    onMouseMove: handleMouseMove,
    onMouseUp: handleMouseUp,
    onMouseLeave: handleMouseUp,
    onWheel: handleWheel
  });
}

/**
 * Render terrain layer
 */
function renderTerrainLayer(ctx, gridManager) {
  const tilesetImage = gridManager.tilesetImage;
  const tilesPerRow = tilesetImage ? Math.floor(tilesetImage.width / 32) : 0;
  const sourceTileSize = 32;

  for (let y = 0; y < GRID.HEIGHT; y++) {
    for (let x = 0; x < GRID.WIDTH; x++) {
      const terrain = gridManager.getTerrainAt(x, y);
      if (!terrain) continue;

      const px = x * GRID.TILE_SIZE;
      const py = y * GRID.TILE_SIZE;

      // If we have tileset image and tile ID, render from tileset
      if (tilesetImage && terrain.tileId !== undefined && terrain.tileId !== null) {
        const tileId = terrain.tileId === 0 ? 0 : terrain.tileId - 1; // Tiled uses 1-based indexing
        const sx = (tileId % tilesPerRow) * sourceTileSize;
        const sy = Math.floor(tileId / tilesPerRow) * sourceTileSize;
        
        ctx.drawImage(
          tilesetImage,
          sx, sy, sourceTileSize, sourceTileSize,
          px, py, GRID.TILE_SIZE, GRID.TILE_SIZE
        );
      } else {
        // Fallback to color rendering
        let color;
        switch (terrain.type) {
          case 'grass':
            color = COLORS.GRASS;
            break;
          case 'water':
            color = COLORS.WATER;
            break;
          case 'dirt':
            color = COLORS.DIRT;
            break;
          default:
            color = '#333333';
        }

        ctx.fillStyle = color;
        ctx.fillRect(px, py, GRID.TILE_SIZE, GRID.TILE_SIZE);
      }
    }
  }
}

/**
 * Render road layer
 */
function renderRoadLayer(ctx, gridManager, popAnimations = []) {
  for (let y = 0; y < GRID.HEIGHT; y++) {
    for (let x = 0; x < GRID.WIDTH; x++) {
      const road = gridManager.getRoadAt(x, y);
      if (!road) continue;

      const px = x * GRID.TILE_SIZE;
      const py = y * GRID.TILE_SIZE;
      const center = GRID.TILE_SIZE / 2;

      // Check if this tile has a pop animation
      const popAnim = popAnimations.find(anim => anim.x === x && anim.y === y);
      
      if (popAnim) {
        // Apply scale transformation
        ctx.save();
        ctx.translate(px + center, py + center);
        ctx.scale(popAnim.scale, popAnim.scale);
        ctx.translate(-(px + center), -(py + center));
      }

      ctx.fillStyle = COLORS.ROAD;
      ctx.fillRect(px, py, GRID.TILE_SIZE, GRID.TILE_SIZE);

      // Draw repair indicator if needed
      if (road.needs_repair) {
        ctx.fillStyle = 'rgba(255, 193, 7, 0.4)'; // Yellow overlay
        ctx.fillRect(px, py, GRID.TILE_SIZE, GRID.TILE_SIZE);
        
        // Draw floating repair cost (animated bounce) - moved up one tile
        const time = Date.now() / 1000;
        const bounce = Math.sin(time * 2 + x + y) * 2; // Slow bounce effect
        const cost = road.repair_cost || 200;
        
        // White text with black stroke
        ctx.font = 'bold 12px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        
        // Black stroke
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 3;
        ctx.strokeText(`$${cost}`, px + center, py - GRID.TILE_SIZE / 2 + bounce);
        
        // White fill
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(`$${cost}`, px + center, py - GRID.TILE_SIZE / 2 + bounce);
      }

      // Road markings based on orientation
      ctx.strokeStyle = '#666666';
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 4]);
      ctx.beginPath();

      const orientation = road.orientation || 'vertical';

      switch (orientation) {
        case 'vertical':
          // Vertical dashed line
          ctx.moveTo(px + center, py);
          ctx.lineTo(px + center, py + GRID.TILE_SIZE);
          break;
        
        case 'horizontal':
          // Horizontal dashed line
          ctx.moveTo(px, py + center);
          ctx.lineTo(px + GRID.TILE_SIZE, py + center);
          break;
        
        case 'corner_top_right':
          // Connects NORTH and EAST
          ctx.moveTo(px + center, py); // from north edge
          ctx.lineTo(px + center, py + center); // to center
          ctx.lineTo(px + GRID.TILE_SIZE, py + center); // to east edge
          break;
        
        case 'corner_top_left':
          // Connects NORTH and WEST
          ctx.moveTo(px + center, py); // from north edge
          ctx.lineTo(px + center, py + center); // to center
          ctx.lineTo(px, py + center); // to west edge
          break;
        
        case 'corner_bottom_right':
          // Connects SOUTH and EAST
          ctx.moveTo(px + center, py + GRID.TILE_SIZE); // from south edge
          ctx.lineTo(px + center, py + center); // to center
          ctx.lineTo(px + GRID.TILE_SIZE, py + center); // to east edge
          break;
        
        case 'corner_bottom_left':
          // Connects SOUTH and WEST
          ctx.moveTo(px + center, py + GRID.TILE_SIZE); // from south edge
          ctx.lineTo(px + center, py + center); // to center
          ctx.lineTo(px, py + center); // to west edge
          break;
        
        case 'cross':
          // Crossroads - both lines
          ctx.moveTo(px + center, py);
          ctx.lineTo(px + center, py + GRID.TILE_SIZE);
          ctx.moveTo(px, py + center);
          ctx.lineTo(px + GRID.TILE_SIZE, py + center);
          break;
        
        default:
          // Default to vertical
          ctx.moveTo(px + center, py);
          ctx.lineTo(px + center, py + GRID.TILE_SIZE);
      }

      ctx.stroke();
      ctx.setLineDash([]);
      
      // Restore context if we applied scale
      if (popAnim) {
        ctx.restore();
      }
    }
  }
}

/**
 * Render building layer - uses tileset if available
 */
function renderBuildingLayer(ctx, gridManager, popAnimations = []) {
  const tilesetImage = gridManager.tilesetImage;
  const tilesPerRow = tilesetImage ? Math.floor(tilesetImage.width / 32) : 0;
  const sourceTileSize = 32;
  
  const renderedBuildings = new Set(); // Track which buildings we've already rendered
  
  for (let y = 0; y < GRID.HEIGHT; y++) {
    for (let x = 0; x < GRID.WIDTH; x++) {
      const building = gridManager.getBuildingAt(x, y);
      if (!building) continue;

      // Skip if we've already rendered this building (multi-tile buildings)
      const buildingKey = `${building.startX},${building.startY}`;
      if (renderedBuildings.has(buildingKey)) continue;
      renderedBuildings.add(buildingKey);

      const px = building.startX * GRID.TILE_SIZE;
      const py = building.startY * GRID.TILE_SIZE;
      const size = building.size || 1;
      
      // Check if this building has a pop animation
      const popAnim = popAnimations.find(anim => anim.x === building.startX && anim.y === building.startY);
      const center = GRID.TILE_SIZE / 2;
      
      if (popAnim) {
        // Apply scale transformation centered on the building
        ctx.save();
        ctx.translate(px + center, py + center);
        ctx.scale(popAnim.scale, popAnim.scale);
        ctx.translate(-(px + center), -(py + center));
      }

      // If we have tileset and building has tileId, render from tileset
      if (tilesetImage && building.tileId !== undefined && building.tileId !== null) {
        const tileId = building.tileId === 0 ? 0 : building.tileId - 1; // Tiled uses 1-based indexing
        
        // For multi-tile buildings, render each tile from the tileset
        for (let dy = 0; dy < size; dy++) {
          for (let dx = 0; dx < size; dx++) {
            const tilePx = (building.startX + dx) * GRID.TILE_SIZE;
            const tilePy = (building.startY + dy) * GRID.TILE_SIZE;
            
            // Calculate which tile in the tileset to use for this part of the building
            const offsetTileId = tileId + (dy * tilesPerRow) + dx;
            const sx = (offsetTileId % tilesPerRow) * sourceTileSize;
            const sy = Math.floor(offsetTileId / tilesPerRow) * sourceTileSize;
            
            ctx.drawImage(
              tilesetImage,
              sx, sy, sourceTileSize, sourceTileSize,
              tilePx, tilePy, GRID.TILE_SIZE, GRID.TILE_SIZE
            );
          }
        }
      } else {
        // Fallback to color rendering if no tileset
        let color;
        switch (building.building_type) {
          case 'residential':
            color = COLORS.RESIDENTIAL;
            break;
          case 'commercial':
            color = COLORS.COMMERCIAL;
            break;
          case 'industrial':
            color = COLORS.INDUSTRIAL;
            break;
          case 'agricultural':
            color = COLORS.AGRICULTURAL;
            break;
          case 'ranch':
            color = COLORS.RANCH;
            break;
          case 'amenity':
            color = COLORS.AMENITY;
            break;
          default:
            color = '#888888';
        }

        ctx.fillStyle = color;
        ctx.fillRect(px, py, GRID.TILE_SIZE * size, GRID.TILE_SIZE * size);

        // Building outline
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 2;
        ctx.strokeRect(px, py, GRID.TILE_SIZE * size, GRID.TILE_SIZE * size);
      }
      
      // Draw repair indicator if needed (on top of building)
      if (building.needs_repair) {
        ctx.fillStyle = 'rgba(255, 193, 7, 0.4)'; // Yellow overlay
        ctx.fillRect(px, py, GRID.TILE_SIZE * size, GRID.TILE_SIZE * size);
        
        // Draw floating repair cost (animated bounce) - moved up one tile
        const time = Date.now() / 1000;
        const bounce = Math.sin(time * 2 + building.startX + building.startY) * 3; // Slow bounce effect
        const cost = building.repair_cost || Math.round((building.revenue_base || 10000) * 0.01);
        
        // White text with black stroke
        ctx.font = 'bold 14px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        
        // Black stroke
        ctx.strokeStyle = '#000000';
        ctx.lineWidth = 3;
        ctx.strokeText(`$${cost.toLocaleString()}`, px + (GRID.TILE_SIZE * size) / 2, py - GRID.TILE_SIZE / 2 + bounce);
        
        // White fill
        ctx.fillStyle = '#FFFFFF';
        ctx.fillText(`$${cost.toLocaleString()}`, px + (GRID.TILE_SIZE * size) / 2, py - GRID.TILE_SIZE / 2 + bounce);
      }
      
      // Restore context if we applied scale
      if (popAnim) {
        ctx.restore();
      }
    }
  }
}

/**
 * Render construction effects layer (construction tiles + cloud particles)
 */
function renderConstructionLayer(ctx, gridManager, constructionEffects) {
  const tilesetImage = gridManager.tilesetImage;
  const tilesPerRow = tilesetImage ? Math.floor(tilesetImage.width / 32) : 0;
  const sourceTileSize = 32;
  
  // Find construction tile ID by scanning tile properties for building_type "construction"
  let constructionTileId = null;
  if (gridManager.tileProperties) {
    for (const [tileId, props] of Object.entries(gridManager.tileProperties)) {
      if (props.building_type === 'construction') {
        constructionTileId = parseInt(tileId);
        break;
      }
    }
  }
  
  // Render construction tiles
  const activeConstructions = constructionEffects.getActiveConstructions();
  for (const construction of activeConstructions) {
    const px = construction.x * GRID.TILE_SIZE;
    const py = construction.y * GRID.TILE_SIZE;
    
    // Render construction tile from tileset
    if (tilesetImage && constructionTileId !== null) {
      const tileId = constructionTileId - 1; // Tiled uses 1-based indexing
      const sx = (tileId % tilesPerRow) * sourceTileSize;
      const sy = Math.floor(tileId / tilesPerRow) * sourceTileSize;
      
      ctx.drawImage(
        tilesetImage,
        sx, sy, sourceTileSize, sourceTileSize,
        px, py, GRID.TILE_SIZE, GRID.TILE_SIZE
      );
    } else {
      // Fallback: Orange construction indicator
      ctx.fillStyle = '#FF9800';
      ctx.fillRect(px, py, GRID.TILE_SIZE, GRID.TILE_SIZE);
      ctx.strokeStyle = '#000000';
      ctx.lineWidth = 2;
      ctx.strokeRect(px, py, GRID.TILE_SIZE, GRID.TILE_SIZE);
    }
  }
  
  // Render cloud particles
  const particles = constructionEffects.getParticles();
  for (const particle of particles) {
    const px = particle.x * GRID.TILE_SIZE + GRID.TILE_SIZE / 2;
    const py = particle.y * GRID.TILE_SIZE + GRID.TILE_SIZE / 2;
    
    ctx.fillStyle = `rgba(200, 200, 200, ${particle.opacity})`;
    ctx.beginPath();
    ctx.arc(px, py, particle.radius, 0, Math.PI * 2);
    ctx.fill();
  }
}

/**
 * Render UI overlays
 */
function renderUI(ctx, camera) {
  // Zoom indicator
  ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
  ctx.fillRect(10, 10, 150, 40);
  
  ctx.fillStyle = '#FFFFFF';
  ctx.font = '12px Arial';
  ctx.fillText(`Zoom: ${(camera.zoom * 100).toFixed(0)}%`, 20, 30);
  ctx.fillText(`Controls: WASD, Mouse Drag`, 20, 45);
}

// Memoize to prevent re-renders when managers array reference changes
// Only re-render if gridManager or managerCoordinator actually change
export const GameCanvas = memo(GameCanvasComponent, (prevProps, nextProps) => {
  return prevProps.gridManager === nextProps.gridManager && 
         prevProps.managerCoordinator === nextProps.managerCoordinator &&
         prevProps.onCameraChange === nextProps.onCameraChange &&
         prevProps.onTileClick === nextProps.onTileClick;
  // Ignore managers array - we read it directly in render loop
});

const styles = {
  canvas: {
    display: 'block',
    backgroundColor: '#000000'
    // cursor managed dynamically via canvas.style.cursor in event handlers
  }
};
