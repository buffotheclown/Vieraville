/**
 * EntityLayer.js
 * Renders manager entities ("little men") on the canvas
 */

import { GRID } from '../../constants/gameConfig.js';
import { COLORS } from '../../constants/uiConstants.js';

/**
 * Render all manager entities on the canvas
 */
export function renderEntities(ctx, managers) {
  for (const manager of managers) {
    if (manager.position) {
      renderEntity(ctx, manager);
    }
  }
}

/**
 * Render a single manager entity
 */
function renderEntity(ctx, manager) {
  const px = manager.position.x * GRID.TILE_SIZE;
  const py = manager.position.y * GRID.TILE_SIZE;
  const size = GRID.TILE_SIZE;

  // Draw a colorful "person" representation
  ctx.save();

  // Shadow
  ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
  ctx.beginPath();
  ctx.ellipse(px + size / 2, py + size - 2, size / 3, size / 6, 0, 0, Math.PI * 2);
  ctx.fill();

  // Body
  ctx.fillStyle = COLORS.PRIMARY;
  ctx.fillRect(px + size / 4, py + size / 3, size / 2, size / 2);

  // Head
  ctx.fillStyle = '#FFD700'; // Gold
  ctx.beginPath();
  ctx.arc(px + size / 2, py + size / 4, size / 4, 0, Math.PI * 2);
  ctx.fill();

  // Outline
  ctx.strokeStyle = '#000000';
  ctx.lineWidth = 2;
  ctx.stroke();

  // Status indicator (if building)
  if (manager.state === 'building') {
    // Construction hat (yellow triangle)
    ctx.fillStyle = '#FFC107';
    ctx.beginPath();
    ctx.moveTo(px + size / 2, py);
    ctx.lineTo(px + size / 4, py + size / 6);
    ctx.lineTo(px + size * 0.75, py + size / 6);
    ctx.closePath();
    ctx.fill();
    ctx.stroke();
  }

  // Name label
  ctx.fillStyle = 'rgba(0, 0, 0, 0.7)';
  ctx.fillRect(px - 10, py - 15, size + 20, 12);
  
  ctx.fillStyle = '#FFFFFF';
  ctx.font = '8px Arial';
  ctx.textAlign = 'center';
  ctx.fillText(manager.name.split(' ')[0], px + size / 2, py - 6);

  ctx.restore();
}
