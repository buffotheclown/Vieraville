/**
 * ManagerSelection.js
 * Manager selection screen - displays all 10 managers
 * Shows hired managers as grayed out, available managers as selectable
 */

import React, { useState } from 'react';
import { MANAGERS } from '../../constants/managerData.js';
import { COLORS, FONTS, SPACING, BORDER_RADIUS } from '../../constants/uiConstants.js';
import { useGameState } from '../../state/StateManager.js';
import { RelationshipService } from '../../services/RelationshipService.js';

export function ManagerSelection({ onComplete, soundManager }) {
  const gameState = useGameState();
  const [selectedManagerId, setSelectedManagerId] = useState(null);
  const [conflictWarning, setConflictWarning] = useState(null);

  const isFirstHire = gameState.hiredManagers.length === 0;
  const headerText = isFirstHire 
    ? `Year ${gameState.year} - Select Your First Manager`
    : `Year ${gameState.year} - Hire Additional Manager`;

  const handleManagerClick = (managerId) => {
    console.log('🟠 [ManagerSelection] Manager card clicked:', managerId);
    console.log('🟠 [ManagerSelection] Is already hired?', gameState.isManagerHired(managerId));
    
    // Can't select already hired managers
    if (gameState.isManagerHired(managerId)) {
      console.log('🟠 [ManagerSelection] Manager already hired, ignoring click');
      return;
    }
    
    // Play button sound
    if (soundManager) {
      soundManager.playButton();
    }
    
    console.log('🟠 [ManagerSelection] Setting selected manager to:', managerId);
    setSelectedManagerId(managerId);
    
    // Check for relationship conflicts
    if (!isFirstHire) {
      const warning = RelationshipService.getConflictWarning(managerId, gameState.managers);
      setConflictWarning(warning);
    } else {
      setConflictWarning(null);
    }
  };

  const handleBeginConstruction = () => {
    console.log('🟣 [ManagerSelection] BEGIN/HIRE BUTTON CLICKED');
    console.log('🟣 [ManagerSelection] Selected manager ID:', selectedManagerId);
    
    if (!selectedManagerId) {
      console.log('🟣 [ManagerSelection] No manager selected, aborting');
      return;
    }
    
    // Play button sound
    if (soundManager) {
      soundManager.playButton();
    }
    
    console.log('🟣 [ManagerSelection] Before hire - hiredManagers:', gameState.hiredManagers);
    
    // Hire the manager
    gameState.hireManager(selectedManagerId);
    
    console.log('🟣 [ManagerSelection] After hire - hiredManagers:', gameState.hiredManagers);
    console.log('🟣 [ManagerSelection] Calling onComplete to return to game...');
    
    // If first hire, transition to game
    // If additional hire, return to game
    onComplete();
  };

  const canBegin = selectedManagerId !== null;

  return React.createElement('div', { style: styles.container },
    React.createElement('div', { style: styles.header },
      React.createElement('h1', { style: styles.headerText }, headerText)
    ),

    React.createElement('div', { style: styles.gridContainer },
      React.createElement('div', { style: styles.grid },
        MANAGERS.map(manager => {
          const isHired = gameState.isManagerHired(manager.id);
          const isSelected = selectedManagerId === manager.id;
          const hasConflict = !isFirstHire && RelationshipService.wouldCauseConflict(manager.id, gameState.managers);
          
          return React.createElement(ManagerCard, {
            key: manager.id,
            manager: manager,
            isHired: isHired,
            isSelected: isSelected,
            hasConflict: hasConflict,
            onClick: () => handleManagerClick(manager.id),
            currentManagers: gameState.managers
          });
        })
      )
    ),

    // Conflict warning banner
    conflictWarning && React.createElement('div', { style: styles.warningBanner },
      React.createElement('span', { style: styles.warningIcon }, '⚠️'),
      React.createElement('span', { style: styles.warningText }, conflictWarning)
    ),

    React.createElement('div', { style: styles.footer },
      React.createElement('button', {
        style: canBegin ? styles.beginButton : styles.beginButtonDisabled,
        onClick: handleBeginConstruction,
        disabled: !canBegin,
        onMouseEnter: (e) => {
          if (canBegin) e.target.style.backgroundColor = '#388E3C';
        },
        onMouseLeave: (e) => {
          if (canBegin) e.target.style.backgroundColor = COLORS.PRIMARY;
        }
      }, isFirstHire ? 'BEGIN CONSTRUCTION' : 'HIRE MANAGER')
    )
  );
}

function ManagerCard({ manager, isHired, isSelected, hasConflict, onClick, currentManagers }) {
  const cardStyle = {
    ...styles.card,
    ...(isHired ? styles.cardHired : {}),
    ...(isSelected ? styles.cardSelected : {}),
    ...(hasConflict && !isHired ? styles.cardConflict : {}),
    cursor: isHired ? 'not-allowed' : 'pointer'
  };

  // Get relationship info for this manager
  const relationships = currentManagers ? RelationshipService.getManagerRelationships(manager.id, currentManagers) : [];

  return React.createElement('div', {
    style: cardStyle,
    onClick: onClick
  },
    // Portrait placeholder (colored square with initials)
    React.createElement('div', { style: styles.portrait },
      React.createElement('div', { style: styles.portraitInitials },
        manager.name.split(' ').map(n => n[0]).join('')
      )
    ),

    // Manager info
    React.createElement('div', { style: styles.cardContent },
      React.createElement('h3', { style: styles.managerName }, manager.name),
      React.createElement('p', { style: styles.specialty }, manager.specialty),
      React.createElement('p', { style: styles.flavorText }, manager.flavor_text),
      
      React.createElement('div', { style: styles.stats },
        React.createElement('span', { style: styles.stat }, `😊 ${manager.starting_happiness}`),
        React.createElement('span', { style: styles.stat }, `⚡ ${manager.starting_efficiency}`)
      ),

      // Relationship indicators
      relationships.length > 0 && React.createElement('div', { style: styles.relationships },
        relationships.map((rel, idx) => 
          React.createElement('div', { 
            key: idx, 
            style: rel.type === 'likes' ? styles.relationshipLike : styles.relationshipDislike 
          },
            React.createElement('span', null, 
              rel.type === 'likes' ? '💚' : '💔',
              ' ',
              rel.managerName
            )
          )
        )
      )
    ),

    // Hired overlay
    isHired && React.createElement('div', { style: styles.hiredOverlay },
      React.createElement('p', { style: styles.hiredText }, 'HIRED')
    )
  );
}

const styles = {
  container: {
    width: '100vw',
    height: '100vh',
    backgroundColor: '#1a1a1a',
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden'
  },
  header: {
    padding: SPACING.LARGE,
    backgroundColor: COLORS.PANEL_BG,
    borderBottom: `3px solid ${COLORS.PRIMARY}`,
    textAlign: 'center'
  },
  headerText: {
    fontFamily: FONTS.FAMILY,
    fontSize: FONTS.SIZE_LARGE,
    color: COLORS.PRIMARY,
    margin: 0
  },
  gridContainer: {
    flex: 1,
    overflow: 'auto',
    padding: SPACING.LARGE
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(350px, 1fr))',
    gap: SPACING.LARGE,
    maxWidth: '1800px',
    margin: '0 auto'
  },
  card: {
    backgroundColor: COLORS.MODAL_BG,
    borderRadius: BORDER_RADIUS.MEDIUM,
    padding: SPACING.MEDIUM,
    border: `2px solid ${COLORS.TEXT_DISABLED}`,
    transition: 'all 0.3s ease',
    position: 'relative',
    display: 'flex',
    gap: SPACING.MEDIUM
  },
  cardSelected: {
    border: `3px solid ${COLORS.PRIMARY}`,
    boxShadow: `0 0 20px ${COLORS.PRIMARY}`,
    transform: 'scale(1.02)'
  },
  cardHired: {
    opacity: 0.4,
    backgroundColor: '#1a1a1a'
  },
  cardConflict: {
    border: `2px solid ${COLORS.WARNING}`,
    backgroundColor: 'rgba(255, 152, 0, 0.1)'
  },
  portrait: {
    width: '80px',
    height: '80px',
    backgroundColor: COLORS.PRIMARY,
    borderRadius: BORDER_RADIUS.MEDIUM,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flexShrink: 0
  },
  portraitInitials: {
    fontFamily: FONTS.FAMILY,
    fontSize: '24px',
    color: COLORS.TEXT_PRIMARY,
    fontWeight: 'bold'
  },
  cardContent: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    gap: SPACING.SMALL
  },
  managerName: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '18px',
    color: COLORS.TEXT_PRIMARY,
    margin: 0,
    fontWeight: 'bold'
  },
  specialty: {
    fontFamily: FONTS.FAMILY,
    fontSize: '10px',
    color: COLORS.ACCENT,
    margin: 0
  },
  flavorText: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '12px',
    color: COLORS.TEXT_SECONDARY,
    margin: 0,
    lineHeight: '1.4',
    fontStyle: 'italic'
  },
  stats: {
    display: 'flex',
    gap: SPACING.MEDIUM,
    marginTop: 'auto'
  },
  stat: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '14px',
    color: COLORS.TEXT_PRIMARY
  },
  relationships: {
    display: 'flex',
    flexDirection: 'column',
    gap: '4px',
    marginTop: SPACING.SMALL,
    paddingTop: SPACING.SMALL,
    borderTop: `1px solid ${COLORS.TEXT_DISABLED}`
  },
  relationshipLike: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '11px',
    color: COLORS.SUCCESS,
    display: 'flex',
    alignItems: 'center',
    gap: '4px'
  },
  relationshipDislike: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '11px',
    color: COLORS.ERROR,
    display: 'flex',
    alignItems: 'center',
    gap: '4px'
  },
  warningBanner: {
    backgroundColor: COLORS.WARNING,
    color: '#000000',
    padding: `${SPACING.MEDIUM}px ${SPACING.LARGE}px`,
    display: 'flex',
    alignItems: 'center',
    gap: SPACING.MEDIUM,
    justifyContent: 'center',
    fontFamily: '"Arial", sans-serif',
    fontSize: '14px',
    fontWeight: 'bold',
    borderTop: `2px solid ${COLORS.ACCENT}`,
    borderBottom: `2px solid ${COLORS.ACCENT}`
  },
  warningIcon: {
    fontSize: '20px'
  },
  warningText: {
    flex: 1,
    maxWidth: '800px'
  },
  hiredOverlay: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    borderRadius: BORDER_RADIUS.MEDIUM
  },
  hiredText: {
    fontFamily: FONTS.FAMILY,
    fontSize: '24px',
    color: COLORS.TEXT_DISABLED,
    margin: 0,
    transform: 'rotate(-15deg)'
  },
  footer: {
    padding: SPACING.LARGE,
    backgroundColor: COLORS.PANEL_BG,
    borderTop: `3px solid ${COLORS.PRIMARY}`,
    display: 'flex',
    justifyContent: 'center'
  },
  beginButton: {
    fontFamily: FONTS.FAMILY,
    fontSize: FONTS.SIZE_MEDIUM,
    backgroundColor: COLORS.PRIMARY,
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    padding: `${SPACING.LARGE}px ${SPACING.XLARGE * 3}px`,
    cursor: 'pointer',
    borderRadius: BORDER_RADIUS.MEDIUM,
    boxShadow: '0 4px 8px rgba(0,0,0,0.3)',
    transition: 'all 0.3s ease',
    letterSpacing: '2px'
  },
  beginButtonDisabled: {
    fontFamily: FONTS.FAMILY,
    fontSize: FONTS.SIZE_MEDIUM,
    backgroundColor: COLORS.TEXT_DISABLED,
    color: COLORS.TEXT_SECONDARY,
    border: 'none',
    padding: `${SPACING.LARGE}px ${SPACING.XLARGE * 3}px`,
    cursor: 'not-allowed',
    borderRadius: BORDER_RADIUS.MEDIUM,
    letterSpacing: '2px',
    opacity: 0.5
  }
};
