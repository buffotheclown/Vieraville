/**
 * GameScene.js
 * Main gameplay scene - contains canvas and HUD elements
 */

import React, { useState, useEffect, useRef } from 'react';
import { useGameState } from '../../state/StateManager.js';
import { GridManager } from '../../managers/GridManager.js';
import { ManagerCoordinator } from '../../managers/ManagerCoordinator.js';
import { EventManager } from '../../managers/EventManager.js';
import { SaveManager } from '../../managers/SaveManager.js';
import { GameConditionChecker } from '../../managers/GameConditionChecker.js';

import { GameCanvas } from '../canvas/GameCanvas.js';
import { TopHUD } from '../hud/TopHUD.js';
import { ManagerPanel } from '../hud/ManagerPanel.js';
import { DashboardPanel } from '../hud/DashboardPanel.js';
import { OffScreenIndicators } from '../hud/OffScreenIndicators.js';
import { ManagerDetailModal } from '../modals/ManagerDetailModal.js';
import { EventModal } from '../modals/EventModal.js';
import { SaveLoadModal } from '../modals/SaveLoadModal.js';
import { VictoryModal } from '../modals/VictoryModal.js';
import { DefeatModal } from '../modals/DefeatModal.js';
import { OptionsModal } from '../modals/OptionsModal.js';
import { InspectionModal } from '../modals/InspectionModal.js';
import { GAME_STATES, COSTS } from '../../constants/gameConfig.js';

export function GameScene({ timeManager, soundManager, musicManager }) {
  const gameState = useGameState();
  const [gridManager, setGridManager] = useState(null);
  const [managerCoordinator, setManagerCoordinator] = useState(null);
  const [eventManager, setEventManager] = useState(null);
  const [conditionChecker, setConditionChecker] = useState(null);
  const [managersData, setManagersData] = useState([]);
  const [selectedManagerId, setSelectedManagerId] = useState(null);
  const [currentEvent, setCurrentEvent] = useState(null);
  const [showSaveModal, setShowSaveModal] = useState(false);
  const [showOptionsModal, setShowOptionsModal] = useState(false);
  const [gameEndState, setGameEndState] = useState(null); // { type: 'victory'/'defeat', reason: '...' }
  const [isLoadedGame, setIsLoadedGame] = useState(false);
  const [isFirstPlan, setIsFirstPlan] = useState(true); // Track if this is the first plan ever
  const [camera, setCamera] = useState(null); // Camera state for off-screen indicators
  const [isLeftPanelExpanded, setIsLeftPanelExpanded] = useState(true); // ManagerPanel collapse state
  const [isRightPanelExpanded, setIsRightPanelExpanded] = useState(true); // DashboardPanel collapse state
  const [inspectionInfo, setInspectionInfo] = useState(null); // { info: {...}, type: 'building'|'road' }
  const [isPreloading, setIsPreloading] = useState(true); // NEW: Track preloading state
  const [loadingProgress, setLoadingProgress] = useState(0); // Loading bar progress (0-100)
  const [loadingMessage, setLoadingMessage] = useState('Surveying swampland...'); // Random loading message
  const animationFrameRef = useRef(null);
  const autoSaveIntervalRef = useRef(null);

  // Initialize grid manager and manager coordinator
  useEffect(() => {
    // Florida-themed loading messages (like The Sims!)
    const loadingMessages = [
      'Surveying swampland...',
      'Negotiating with alligators...',
      'Installing palm trees...',
      'Calculating humidity levels...',
      'Importing oranges...',
      'Setting up hurricane insurance...',
      'Attracting retirees...',
      'Building golf courses...',
      'Evicting pythons...',
      'Establishing HOA rules...',
      'Paving roads through wetlands...',
      'Recruiting managers...',
      'Stocking bait shops...',
      'Planting mangroves...',
      'Negotiating with Disney...'
    ];
    
    const initializeGame = async (loadedSaveData = null) => {
      const t0 = performance.now();
      console.log('🔷 [LOADING] START - Continue button clicked');
      
      setLoadingProgress(5);
      setLoadingMessage(loadingMessages[Math.floor(Math.random() * loadingMessages.length)]);
      
      // Load Tiled map
      const TiledLoader = (await import('../../services/TiledLoader.js')).TiledLoader;
      
      const mapUrl = 'https://rosebud.ai/assets/VieraVille.tmj?UVhN';
      const tilesetUrl = 'https://rosebud.ai/assets/graphics.png?hpyW';
      
      const t1 = performance.now();
      const mapData = await TiledLoader.loadMap(mapUrl);
      const tilesetImage = await TiledLoader.loadTileset(tilesetUrl);
      console.log(`🔷 [LOADING] Tiled map loaded: ${(performance.now() - t1).toFixed(0)}ms`);
      setLoadingProgress(20);
      setLoadingMessage(loadingMessages[Math.floor(Math.random() * loadingMessages.length)]);
      
      // Create grid manager
      const t2 = performance.now();
      const gm = new GridManager(gameState);
      
      if (!mapData || !tilesetImage) {
        gm.generateFloridaTerrain();
        gm.generateEntryPoints();
      } else {
        await gm.loadTiledMap(mapData, tilesetImage);
      }
      console.log(`🔷 [LOADING] GridManager created: ${(performance.now() - t2).toFixed(0)}ms`);
      setLoadingProgress(35);
      setLoadingMessage(loadingMessages[Math.floor(Math.random() * loadingMessages.length)]);
      
      const t3 = performance.now();
      setGridManager(gm);
      gameState.setGridManager(gm);
      
      // Create manager coordinator
      const mc = new ManagerCoordinator(gameState, gm, soundManager);
      setManagerCoordinator(mc);
      
      // Create event manager
      const em = new EventManager(gameState);
      setEventManager(em);
      
      // Create condition checker
      const cc = new GameConditionChecker(gameState);
      setConditionChecker(cc);
      console.log(`🔷 [LOADING] Managers created: ${(performance.now() - t3).toFixed(0)}ms`);
      setLoadingProgress(45);
      setLoadingMessage(loadingMessages[Math.floor(Math.random() * loadingMessages.length)]);
      
      // Check if we should load a save
      if (loadedSaveData) {
        const t4 = performance.now();
        SaveManager.restoreGameState(loadedSaveData, gameState);
        SaveManager.restoreGrid(loadedSaveData, gm, gameState);
        SaveManager.restoreEvents(loadedSaveData, em);
        console.log(`🔷 [LOADING] Save restored: ${(performance.now() - t4).toFixed(0)}ms`);
      }
      
      // Add managers
      const t5 = performance.now();
      for (const managerId of gameState.hiredManagers) {
        const managerAI = mc.addManager(managerId);
      }
      
      if (loadedSaveData) {
        SaveManager.restoreManagers(loadedSaveData, mc);
        setIsLoadedGame(true);
      }
      console.log(`🔷 [LOADING] Managers added: ${(performance.now() - t5).toFixed(0)}ms`);
      setLoadingProgress(55);
      setLoadingMessage(loadingMessages[Math.floor(Math.random() * loadingMessages.length)]);
      
      // PRELOAD stats
      const t6 = performance.now();
      await gameState.recalculateStats();
      console.log(`🔷 [LOADING] Stats calculated: ${(performance.now() - t6).toFixed(0)}ms`);
      setLoadingProgress(70);
      setLoadingMessage(loadingMessages[Math.floor(Math.random() * loadingMessages.length)]);
      
      const t7 = performance.now();
      const { EmploymentManager } = await import('../../managers/EmploymentManager.js');
      const employmentManager = new EmploymentManager(gameState);
      employmentManager.distributeEmployment();
      console.log(`🔷 [LOADING] Employment distributed: ${(performance.now() - t7).toFixed(0)}ms`);
      setLoadingProgress(80);
      setLoadingMessage(loadingMessages[Math.floor(Math.random() * loadingMessages.length)]);
      
      const t8 = performance.now();
      const { RevenueManager } = await import('../../managers/RevenueManager.js');
      const revenueManager = new RevenueManager(gameState);
      revenueManager.calculateMonthlyRevenue();
      console.log(`🔷 [LOADING] Revenue calculated: ${(performance.now() - t8).toFixed(0)}ms`);
      setLoadingProgress(90);
      setLoadingMessage(loadingMessages[Math.floor(Math.random() * loadingMessages.length)]);
      
      const t9 = performance.now();
      const { MaintenanceManager } = await import('../../managers/MaintenanceManager.js');
      const maintenanceManager = new MaintenanceManager(gameState);
      maintenanceManager.getDisrepairCount();
      console.log(`🔷 [LOADING] Maintenance counted: ${(performance.now() - t9).toFixed(0)}ms`);
      setLoadingProgress(95);
      setLoadingMessage('Ready to build!');
      
      gameState.resume();
      
      if (!loadedSaveData) {
        setTimeout(() => {
          mc.triggerInitialPlans();
        }, 3000);
      }
      
      console.log(`🔷 [LOADING] COMPLETE - Total time: ${(performance.now() - t0).toFixed(0)}ms`);
      console.log('🔷 [LOADING] Game will render NOW');
      
      setLoadingProgress(100);
      
      // Small delay so user sees 100% before game appears
      setTimeout(() => {
        setIsPreloading(false);
      }, 200);
    };
    
    const saveData = SaveManager.loadGame();
    if (saveData && !isLoadedGame) {
      initializeGame(saveData);
      setIsFirstPlan(false);
    } else {
      initializeGame();
      setIsFirstPlan(true);
    }
  }, []);

  // Watch for newly hired managers and add them to coordinator
  useEffect(() => {
    if (!managerCoordinator || !gridManager) {
      return;
    }
    
    // Add any managers in gameState.hiredManagers that aren't in coordinator yet
    for (const managerId of gameState.hiredManagers) {
      const existingManager = managerCoordinator.getManager(managerId);
      
      if (!existingManager) {
        const managerAI = managerCoordinator.addManager(managerId);
        
        if (managerAI) {
          // Don't set position - manager will appear when building starts
          
          // Trigger initial plans for newly hired manager
          setTimeout(() => {
            managerAI.generateInitialPlans();
          }, 1000);
        }
        setManagersData(managerCoordinator.getManagersData());
      }
    }
  }, [gameState.hiredManagers.length, managerCoordinator, gridManager]);

  // Update camera reference in all managers when camera changes
  useEffect(() => {
    if (!managerCoordinator || !camera) return;
    
    // Update camera reference in all managers
    const managers = managerCoordinator.getAllManagers();
    for (const manager of managers) {
      manager.setCamera(camera);
    }
  }, [managerCoordinator, camera]);

  // Update loop for manager AI, events, and win/lose conditions
  useEffect(() => {
    if (!managerCoordinator || !eventManager || !conditionChecker) return;

    const update = () => {
      // Don't update if game has ended
      if (gameEndState) {
        return;
      }

      // Pause game when modals are open
      const isGamePaused = selectedManagerId !== null || currentEvent !== null || showSaveModal;
      
      // ALWAYS update managers data to keep positions fresh for off-screen indicators (even when paused)
      setManagersData(managerCoordinator.getManagersData());
      
      if (!isGamePaused) {
        managerCoordinator.update();
        
        // Check for events
        eventManager.update();
        
        // Check win/lose conditions
        const conditionResult = conditionChecker.check();
        if (conditionResult) {
          setGameEndState(conditionResult);
          return; // Stop update loop
        }
      }
      
      animationFrameRef.current = requestAnimationFrame(update);
    };

    animationFrameRef.current = requestAnimationFrame(update);

    return () => {
      if (animationFrameRef.current) {
        cancelAnimationFrame(animationFrameRef.current);
      }
    };
  }, [managerCoordinator, eventManager, conditionChecker, gameEndState, selectedManagerId, currentEvent, showSaveModal]);

  // Pause/Resume game when modals open/close
  useEffect(() => {
    const isModalOpen = selectedManagerId !== null || currentEvent !== null || showSaveModal || showOptionsModal || inspectionInfo !== null;
    
    console.log('🔍 Modal state check:', {
      selectedManagerId,
      currentEvent: !!currentEvent,
      showSaveModal,
      showOptionsModal,
      inspectionInfo: !!inspectionInfo,
      isModalOpen
    });
    
    if (isModalOpen) {
      gameState.pause();
    } else {
      gameState.resume();
    }
  }, [selectedManagerId, currentEvent, showSaveModal, showOptionsModal, inspectionInfo, gameState]);

  // Listen for events and milestones
  useEffect(() => {
    const handleRandomEvent = (eventData) => {
      setCurrentEvent({
        type: 'event',
        name: eventData.name,
        message: eventData.message,
        result: eventData.result
      });
    };

    const handleMilestone = (milestoneData) => {
      setCurrentEvent({
        type: 'milestone',
        name: milestoneData.name,
        message: 'Congratulations!',
        description: milestoneData.description,
        reward: milestoneData.reward
      });
    };

    gameState.on('random-event', handleRandomEvent);
    gameState.on('milestone-achieved', handleMilestone);

    return () => {
      gameState.off('random-event', handleRandomEvent);
      gameState.off('milestone-achieved', handleMilestone);
    };
  }, [gameState]);

  // Listen for manager plan proposals
  useEffect(() => {
    const handlePlanProposed = (data) => {
      // Show notification when manager proposes plans
      if (data.action === 'plan-proposed' || data.action === 'initial-plans-proposed') {
        // Check if this manager has auto-approve enabled
        const manager = managerCoordinator?.getManager(data.managerId);
        
        if (manager && manager.autoApprove) {
          // Manager has auto-approve - skip modal, they'll handle it themselves
          console.log(`🤖 [${manager.name}] Plan proposed but AUTO mode enabled - skipping modal`);
          
          // Still mark first plan as handled
          if (isFirstPlan) {
            setIsFirstPlan(false);
            gameState.resume(); // Resume game time after first plan (auto-approved)
          }
          return;
        }
        
        // Always open the manager modal directly (no intermediate notification)
        // Small delay to ensure manager state is updated
        setTimeout(() => {
          setSelectedManagerId(data.managerId);
          setIsFirstPlan(false); // Mark that first plan has been handled
        }, 100);
      }
    };

    gameState.on('manager-action', handlePlanProposed);

    return () => {
      gameState.off('manager-action', handlePlanProposed);
    };
  }, [gameState, isFirstPlan, managerCoordinator]);

  // Auto-save at end of each month and when population changes
  useEffect(() => {
    if (!gridManager || !managerCoordinator || !eventManager) return;

    const handleMonthChanged = () => {
      SaveManager.saveGame(gameState, gridManager, managerCoordinator, eventManager);
    };

    const handlePopulationUpdated = () => {
      // Save whenever population changes (new residents move in)
      SaveManager.saveGame(gameState, gridManager, managerCoordinator, eventManager);
    };

    gameState.on('month-changed', handleMonthChanged);
    gameState.on('population-updated', handlePopulationUpdated);

    return () => {
      gameState.off('month-changed', handleMonthChanged);
      gameState.off('population-updated', handlePopulationUpdated);
    };
  }, [gameState, gridManager, managerCoordinator, eventManager]);

  // Keyboard shortcuts (Ctrl+S for save, ESC for options)
  useEffect(() => {
    if (!gridManager || !managerCoordinator || !eventManager) return;

    const handleKeyDown = (e) => {
      // ESC: Open options menu
      if (e.key === 'Escape') {
        e.preventDefault();
        setShowOptionsModal(prev => !prev);
      }
      
      // Ctrl+S / Cmd+S: Quick save
      if ((e.ctrlKey || e.metaKey) && e.key === 's') {
        e.preventDefault();
        const success = SaveManager.saveGame(gameState, gridManager, managerCoordinator, eventManager);
        if (success) {
          gameState.emit('manager-action', {
            action: 'manual-save',
            managerName: 'System',
            managerId: 'system'
          });
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameState, gridManager, managerCoordinator, eventManager]);

  // Handlers
  const handleManagerClick = (managerId) => {
    const manager = managerCoordinator.getManager(managerId);
    
    // Don't open modal if manager has auto-approve enabled
    if (manager && manager.autoApprove) {
      console.log(`🤖 [${manager.name}] AUTO mode enabled - modal skipped`);
      return;
    }
    
    setSelectedManagerId(managerId);
  };

  const handleToggleAuto = (managerId) => {
    const manager = managerCoordinator.getManager(managerId);
    if (manager) {
      const newAutoState = manager.toggleAutoApprove();
      if (soundManager) soundManager.playButton();
      
      if (newAutoState) {
        gameState.addNotification(`${manager.name}: AUTO mode ON`, 'success');
        console.log(`🤖 [${manager.name}] AUTO mode enabled`);
      } else {
        gameState.addNotification(`${manager.name}: AUTO mode OFF`, 'info');
        console.log(`🤖 [${manager.name}] AUTO mode disabled`);
      }
      
      // Force UI update
      setManagersData(managerCoordinator.getManagersData());
    }
  };

  const handleCloseModal = () => {
    setSelectedManagerId(null);
  };

  const handleApprovePlan = (managerId, planIndex = 0) => {
    const manager = managerCoordinator.getManager(managerId);
    if (manager) {
      const success = manager.approvePlan(planIndex);
      if (success) {
        if (soundManager) soundManager.playButton(); // Button: approved plan
        gameState.addNotification(`Approved ${manager.name}'s plan!`, 'success');
        
        // Mark first plan as completed
        if (isFirstPlan) {
          setIsFirstPlan(false);
          gameState.resume(); // Resume game time after first plan is approved
        }
      }
    }
  };

  const handleDenyPlan = (managerId) => {
    const manager = managerCoordinator.getManager(managerId);
    if (manager) {
      if (soundManager) soundManager.playButton(); // Button: denied plan
      manager.denyPlan();
      gameState.addNotification(`Denied ${manager.name}'s plan`, 'info');
    }
  };

  const handleRaise = (managerId) => {
    console.log('=== HANDLE RAISE START ===');
    console.log('1. Manager ID:', managerId);
    console.log('2. Can afford?', gameState.canAfford(COSTS.MANAGER_RAISE));
    console.log('3. Current budget:', gameState.budget);
    
    if (!gameState.canAfford(COSTS.MANAGER_RAISE)) {
      if (soundManager) soundManager.playNegative();
      gameState.addNotification('Cannot afford raise!', 'error');
      console.log('ERROR: Cannot afford raise');
      return;
    }

    const manager = managerCoordinator.getManager(managerId);
    console.log('4. Manager found?', !!manager);
    
    if (manager) {
      console.log('5. Manager before raise:', {
        name: manager.name,
        raises: manager.raises,
        happiness: manager.happiness
      });
      
      if (soundManager) soundManager.playButton();
      gameState.subtractBudget(COSTS.MANAGER_RAISE);
      console.log('6. Budget after deduction:', gameState.budget);
      
      manager.giveRaise(COSTS.MANAGER_RAISE);
      console.log('7. Manager after raise:', {
        raises: manager.raises,
        happiness: manager.happiness
      });
      
      gameState.addNotification(`Gave ${manager.name} a raise!`, 'success');
      
      console.log('8. Triggering re-render with fresh data from coordinator...');
      setManagersData(managerCoordinator.getManagersData());
      console.log('9. Re-render triggered');
    }
    console.log('=== HANDLE RAISE END ===');
  };

  const handleFire = (managerId) => {
    const manager = managerCoordinator.getManager(managerId);
    if (manager) {
      if (soundManager) soundManager.playNegative(); // Negative: fired manager
      managerCoordinator.removeManager(managerId);
      gameState.hiredManagers = gameState.hiredManagers.filter(id => id !== managerId);
      gameState.addNotification(`Fired ${manager.name}`, 'info');
    }
  };

  const lastClickTimeRef = useRef(0);
  const CLICK_THROTTLE = 300; // 300ms between clicks

  const handleTileClick = async (x, y) => {
    if (!gridManager) return;

    // Throttle clicks to prevent duplicate sounds
    const now = Date.now();
    if (now - lastClickTimeRef.current < CLICK_THROTTLE) {
      return;
    }
    lastClickTimeRef.current = now;

    const { MaintenanceManager } = await import('../../managers/MaintenanceManager.js');
    const maintenanceManager = new MaintenanceManager(gameState);

    // Check for road FIRST (roads are single tiles, easier to click)
    const road = gridManager.getRoadAt(x, y);
    if (road && road.is_road) {
      if (road.needs_repair) {
        // Repair damaged road
        const cost = maintenanceManager.repairRoad(x, y);
        if (cost !== null) {
          if (soundManager) soundManager.playPositive();
          gameState.addNotification(`Repaired road for $${cost.toLocaleString()}`, 'success');
        } else {
          if (soundManager) soundManager.playNegative();
          gameState.addNotification('Cannot afford repair!', 'error');
        }
        return;
      } else {
        // Show road info modal
        const roadInfo = maintenanceManager.getRoadInfo(x, y);
        if (roadInfo) {
          if (soundManager) soundManager.playButton();
          setInspectionInfo({ info: roadInfo, type: 'road' });
        }
        return;
      }
    }

    // Check for building - search through all buildings in gameState
    for (const building of gameState.buildings) {
      const size = building.size || 1;
      const inBounds = x >= building.startX && x < building.startX + size &&
                       y >= building.startY && y < building.startY + size;
      
      if (inBounds) {
        if (building.needs_repair) {
          // Repair damaged building
          const cost = building.repair_cost || 0;
          
          if (gameState.canAfford(cost)) {
            gameState.subtractBudget(cost);
            building.needs_repair = false;
            building.repair_cost = 0;
            
            // ALSO clear needs_repair from ALL grid tiles for this building
            for (let by = building.startY; by < building.startY + size; by++) {
              for (let bx = building.startX; bx < building.startX + size; bx++) {
                const gridBuilding = gridManager.getBuildingAt(bx, by);
                if (gridBuilding && gridBuilding.building_id === building.building_id) {
                  gridBuilding.needs_repair = false;
                  gridBuilding.repair_cost = 0;
                }
              }
            }
            
            if (soundManager) soundManager.playPositive();
            gameState.addNotification(`Repaired ${building.name} for $${cost.toLocaleString()}`, 'success');
          } else {
            if (soundManager) soundManager.playNegative();
            gameState.addNotification('Cannot afford repair!', 'error');
          }
          return;
        } else {
          // Show building info modal
          const buildingInfo = maintenanceManager.getBuildingInfo(x, y);
          if (buildingInfo) {
            if (soundManager) soundManager.playButton();
            setInspectionInfo({ info: buildingInfo, type: 'building' });
          }
          return;
        }
      }
    }
  };

  const handleRepair = async (x, y, buildingId) => {
    const { MaintenanceManager } = await import('../../managers/MaintenanceManager.js');
    const maintenanceManager = new MaintenanceManager(gameState);

    let cost = null;
    if (inspectionInfo.type === 'building') {
      cost = maintenanceManager.repairBuilding(x, y);
    } else if (inspectionInfo.type === 'road') {
      cost = maintenanceManager.repairRoad(x, y);
    }

    if (cost !== null) {
      if (soundManager) soundManager.playPositive();
      gameState.addNotification(`Repaired for $${cost.toLocaleString()}`, 'success');
      setInspectionInfo(null); // Close modal
    } else {
      if (soundManager) soundManager.playNegative();
      gameState.addNotification('Cannot afford repair!', 'error');
    }
  };

  const handleDemolish = async (buildingId) => {
    console.log('🟢 [GameScene] handleDemolish called');
    console.log('  buildingId:', buildingId);
    console.log('  gridManager exists?', !!gridManager);
    console.log('  gameState exists?', !!gameState);
    
    const { MaintenanceManager } = await import('../../managers/MaintenanceManager.js');
    console.log('  MaintenanceManager imported');
    
    const maintenanceManager = new MaintenanceManager(gameState);
    console.log('  MaintenanceManager instance created');
    
    console.log('  Calling demolishBuilding...');
    const result = maintenanceManager.demolishBuilding(buildingId);
    console.log('  demolishBuilding returned:', result);
    
    if (result) {
      console.log('  ✅ Demolition successful!');
      console.log('    Building name:', result.name);
      console.log('    Refund amount:', result.refund);
      
      if (soundManager) soundManager.playButton();
      gameState.addNotification(`Demolished ${result.name} for $${result.refund.toLocaleString()}`, 'info');
      setInspectionInfo(null); // Close modal
      
      // Force recalculation of stats
      gameState.recalculateStats();
      console.log('  Stats recalculated');
    } else {
      console.error('  ❌ Demolition failed - result is null/false');
    }
  };

  const handleReset = (managerId) => {
    console.log('=== RESET MANAGER DEBUG START ===');
    console.log('1. handleReset called with managerId:', managerId);
    console.log('2. managerCoordinator exists?', !!managerCoordinator);
    
    const manager = managerCoordinator.getManager(managerId);
    console.log('3. Manager found?', !!manager);
    
    if (manager) {
      console.log('4. Manager details:', {
        name: manager.name,
        id: manager.managerId,
        state: manager.currentState,
        position: manager.position,
        targetPosition: manager.targetPosition,
        originalEntryPoint: manager.originalEntryPoint
      });
      
      if (soundManager) soundManager.playButton();
      
      console.log('5. Calling manager.resetToStart()...');
      manager.resetToStart();
      
      console.log('6. After reset:', {
        state: manager.currentState,
        position: manager.position,
        targetPosition: manager.targetPosition
      });
      
      gameState.addNotification(`Reset ${manager.name} to starting position`, 'info');
      
      console.log('7. Triggering re-render with fresh data...');
      setManagersData(managerCoordinator.getManagersData());
      console.log('8. Re-render triggered');
    } else {
      console.log('ERROR: Manager not found!');
    }
    console.log('=== RESET MANAGER DEBUG END ===');
  };

  const handleHireClick = () => {
    if (soundManager) soundManager.playButton(); // Button: opening manager selection
    console.log('🟢 [GameScene] handleHireClick called');
    console.log('🟢 [GameScene] Current scene:', gameState.currentScene);
    console.log('🟢 [GameScene] Hired managers:', gameState.hiredManagers);
    console.log('🟢 [GameScene] Changing scene to MANAGER_SELECTION...');
    gameState.setScene(GAME_STATES.MANAGER_SELECTION);
    console.log('🟢 [GameScene] Scene changed to:', gameState.currentScene);
  };

  const handleCloseEvent = () => {
    setCurrentEvent(null);
  };

  const handleSaveLoad = () => {
    setShowSaveModal(true);
  };

  const handleCloseSaveModal = () => {
    setShowSaveModal(false);
  };

  const handleLoadGame = async (saveData) => {
    // Reload the page to properly reset everything
    window.location.reload();
  };

  const handleVictoryContinue = () => {
    // Close modal but allow continued play
    setGameEndState(null);
    if (conditionChecker) {
      conditionChecker.victoryAchieved = false; // Allow player to keep playing
    }
  };

  const handleRestart = () => {
    // Delete save and reload
    SaveManager.deleteSave();
    window.location.reload();
  };

  const handleQuitToMenu = () => {
    // Return to title screen
    gameState.setScene(GAME_STATES.TITLE);
  };

  // Show loading screen while preloading OR while managers aren't ready
  if (isPreloading || !gridManager || !managerCoordinator || !eventManager || !conditionChecker) {
    return React.createElement('div', { style: styles.loading },
      React.createElement('div', { style: styles.loadingContent },
        React.createElement('h1', { style: styles.loadingTitle }, 'VIERAVILLE'),
        React.createElement('h2', { style: styles.loadingSubtitle }, 'Private Town Tycoon'),
        
        // Loading bar container
        React.createElement('div', { style: styles.loadingBarContainer },
          React.createElement('div', { 
            style: { 
              ...styles.loadingBarFill, 
              width: `${loadingProgress}%` 
            } 
          })
        ),
        
        // Progress percentage
        React.createElement('p', { style: styles.loadingPercent }, `${loadingProgress}%`),
        
        // Random loading message
        React.createElement('p', { style: styles.loadingMessage }, loadingMessage)
      )
    );
  }

  const selectedManager = selectedManagerId 
    ? managersData.find(m => m.id === selectedManagerId)
    : null;

  return React.createElement('div', { style: styles.container },
    // Canvas layer
    React.createElement(GameCanvas, { 
      gridManager: gridManager,
      managers: managersData,
      managerCoordinator: managerCoordinator,
      onCameraChange: setCamera,
      onTileClick: handleTileClick
    }),
    
    // Off-screen indicators for managers
    camera && managersData && managersData.length > 0
      ? React.createElement(OffScreenIndicators, {
          camera: camera,
          managers: managersData,
          // Pass UI panel information for boundary calculation
          hasLeftPanel: isLeftPanelExpanded, // ManagerPanel collapse state
          hasRightPanel: isRightPanelExpanded, // DashboardPanel collapse state
          hasTopPanel: true // TopHUD is always present
        })
      : null,
    
    // Top HUD
    React.createElement(TopHUD),

    // Manager Panel
    React.createElement(ManagerPanel, {
      managers: managersData,
      onManagerClick: handleManagerClick,
      onHireClick: handleHireClick,
      onToggleAuto: handleToggleAuto,
      onExpandedChange: setIsLeftPanelExpanded
    }),

    // Dashboard Panel
    React.createElement(DashboardPanel, {
      managerCoordinator: managerCoordinator,
      onExpandedChange: setIsRightPanelExpanded
    }),

    // Manager Detail Modal
    selectedManager && React.createElement(ManagerDetailModal, {
      manager: selectedManager,
      onClose: handleCloseModal,
      onApprove: handleApprovePlan,
      onDeny: handleDenyPlan,
      onRaise: handleRaise,
      onFire: handleFire,
      onReset: handleReset,
      isFirstPlan: isFirstPlan
    }),

    // Event/Milestone Modal
    currentEvent && React.createElement(EventModal, {
      event: currentEvent,
      onClose: handleCloseEvent
    }),

    // Save/Load Modal
    showSaveModal && React.createElement(SaveLoadModal, {
      onClose: handleCloseSaveModal,
      onLoad: handleLoadGame,
      gameState: gameState,
      gridManager: gridManager,
      managerCoordinator: managerCoordinator,
      eventManager: eventManager
    }),

    // Options Modal
    showOptionsModal && React.createElement(OptionsModal, {
      onClose: () => setShowOptionsModal(false),
      timeManager: timeManager,
      musicManager: musicManager
    }),

    // Inspection Modal
    inspectionInfo && React.createElement(InspectionModal, {
      info: inspectionInfo.info,
      type: inspectionInfo.type,
      onClose: () => setInspectionInfo(null),
      onRepair: handleRepair,
      onDemolish: handleDemolish
    }),

    // Victory Modal
    gameEndState && gameEndState.type === 'victory' && React.createElement(VictoryModal, {
      gameState: gameState,
      onContinue: handleVictoryContinue,
      onRestart: handleRestart
    }),

    // Defeat Modal
    gameEndState && gameEndState.type === 'defeat' && React.createElement(DefeatModal, {
      gameState: gameState,
      reason: gameEndState.reason,
      onRestart: handleRestart,
      onQuit: handleQuitToMenu
    }),

    // Save button (floating)
    React.createElement('button', {
      style: styles.saveButton,
      onClick: handleSaveLoad,
      onMouseEnter: (e) => {
        e.target.style.transform = 'scale(1.1)';
        e.target.style.boxShadow = '0 6px 16px rgba(0, 0, 0, 0.6)';
      },
      onMouseLeave: (e) => {
        e.target.style.transform = 'scale(1)';
        e.target.style.boxShadow = '0 4px 12px rgba(0, 0, 0, 0.4)';
      },
      title: 'Save/Load Game'
    }, '💾')
  );
}

const styles = {
  container: {
    width: '100vw',
    height: '100vh',
    position: 'relative',
    overflow: 'hidden'
  },
  loading: {
    width: '100vw',
    height: '100vh',
    backgroundColor: '#1a1a1a',
    backgroundImage: 'linear-gradient(135deg, #1a1a1a 0%, #2d4a2b 100%)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center'
  },
  loadingContent: {
    textAlign: 'center',
    maxWidth: '600px',
    width: '90%'
  },
  loadingTitle: {
    fontFamily: '"Courier New", monospace',
    fontSize: '48px',
    color: '#4CAF50',
    margin: '0 0 10px 0',
    textShadow: '4px 4px 0px rgba(0,0,0,0.5)',
    letterSpacing: '4px'
  },
  loadingSubtitle: {
    fontFamily: '"Courier New", monospace',
    fontSize: '20px',
    color: '#81C784',
    margin: '0 0 40px 0',
    letterSpacing: '2px'
  },
  loadingBarContainer: {
    width: '100%',
    height: '30px',
    backgroundColor: 'rgba(0, 0, 0, 0.5)',
    borderRadius: '15px',
    overflow: 'hidden',
    border: '2px solid #4CAF50',
    marginBottom: '15px'
  },
  loadingBarFill: {
    height: '100%',
    backgroundColor: '#4CAF50',
    transition: 'width 0.3s ease',
    boxShadow: '0 0 10px rgba(76, 175, 80, 0.5)'
  },
  loadingPercent: {
    fontFamily: '"Courier New", monospace',
    fontSize: '18px',
    color: '#4CAF50',
    margin: '0 0 20px 0',
    fontWeight: 'bold'
  },
  loadingMessage: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '16px',
    color: '#FFFFFF',
    margin: 0,
    fontStyle: 'italic',
    opacity: 0.9,
    minHeight: '24px'
  },
  loadingText: {
    color: '#FFFFFF',
    fontSize: '24px'
  },
  debugOverlay: {
    position: 'absolute',
    top: '80px',
    right: '20px',
    zIndex: 100,
    pointerEvents: 'none'
  },
  debugPanel: {
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    color: '#FFFFFF',
    padding: '15px',
    borderRadius: '8px',
    fontSize: '12px',
    fontFamily: 'Arial, sans-serif',
    minWidth: '200px'
  },
  saveButton: {
    position: 'fixed',
    bottom: '20px',
    right: '20px',
    width: '60px',
    height: '60px',
    borderRadius: '50%',
    backgroundColor: '#2E7D32',
    color: '#FFFFFF',
    border: 'none',
    fontSize: '28px',
    cursor: 'pointer',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.4)',
    zIndex: 100,
    transition: 'transform 0.2s, box-shadow 0.2s',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  }
};
