/**
 * SplashScreen.js
 * Displays logo with fade in/out animation and plays audio
 */

import React, { useEffect, useState, useRef } from 'react';

export function SplashScreen({ onComplete }) {
  const [opacity, setOpacity] = useState(0);
  const startTimeRef = useRef(Date.now());
  const completedRef = useRef(false);
  const audioRef = useRef(null);

  useEffect(() => {
    // Play audio IMMEDIATELY - use ref to ensure it persists
    audioRef.current = new Audio('https://rosebud.ai/assets/GiveMeMoney.mp3?nOfB');
    audioRef.current.volume = 0.7;
    
    // Try to play - if blocked, play on first click
    const playAudio = () => {
      if (audioRef.current) {
        audioRef.current.play().catch(err => {
          console.log('Audio autoplay blocked, will play on user interaction');
          // Play on first click anywhere
          const clickHandler = () => {
            if (audioRef.current) {
              audioRef.current.play();
            }
            document.removeEventListener('click', clickHandler);
          };
          document.addEventListener('click', clickHandler);
        });
      }
    };
    
    playAudio();

    // Fade in over 1 second
    const fadeInTimer = setTimeout(() => {
      setOpacity(1);
    }, 100);

    // Start fade out at 3 seconds
    const fadeOutTimer = setTimeout(() => {
      setOpacity(0);
    }, 3000);

    // FORCE complete at exactly 4 seconds - ignore any race conditions
    const completeTimer = setTimeout(() => {
      if (!completedRef.current) {
        completedRef.current = true;
        onComplete();
      }
    }, 4000);

    return () => {
      clearTimeout(fadeInTimer);
      clearTimeout(fadeOutTimer);
      clearTimeout(completeTimer);
      // Stop audio if still playing
      if (audioRef.current) {
        audioRef.current.pause();
        audioRef.current = null;
      }
    };
  }, [onComplete]);

  return React.createElement('div', { style: styles.container },
    React.createElement('img', {
      src: 'https://rosebud.ai/assets/TSGCLogo.png?VfaS',
      alt: 'TSGC Logo',
      style: {
        ...styles.logo,
        opacity: opacity,
        transition: 'opacity 1s ease-in-out'
      }
    })
  );
}

const styles = {
  container: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100vw',
    height: '100vh',
    backgroundColor: '#000000',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 10000
  },
  logo: {
    width: '100vw',
    height: '100vh',
    objectFit: 'contain'
  }
};
