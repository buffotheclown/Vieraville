/**
 * SplashScreen.js
 * Displays logo with fade in/out animation and plays audio
 */

import React, { useEffect, useState, useRef } from 'react';

export function SplashScreen({ onComplete }) {
  const [opacity, setOpacity] = useState(0);
  const startTimeRef = useRef(Date.now());
  const completedRef = useRef(false);

  useEffect(() => {
    // Play audio IMMEDIATELY
    const audio = new Audio('https://rosebud.ai/assets/GiveMeMoney.mp3?nOfB');
    audio.volume = 0.7;
    audio.play().catch(err => console.log('Audio play blocked:', err));

    // Fade in over 1 second
    const fadeInTimer = setTimeout(() => {
      setOpacity(1);
    }, 100);

    // Start fade out at 3 seconds
    const fadeOutTimer = setTimeout(() => {
      setOpacity(0);
    }, 3000);

    // FORCE complete at exactly 4 seconds - ignore any race conditions
    const completeTimer = setTimeout(() => {
      if (!completedRef.current) {
        completedRef.current = true;
        onComplete();
      }
    }, 4000);

    return () => {
      clearTimeout(fadeInTimer);
      clearTimeout(fadeOutTimer);
      clearTimeout(completeTimer);
    };
  }, [onComplete]);

  return React.createElement('div', { style: styles.container },
    React.createElement('img', {
      src: 'https://rosebud.ai/assets/TSGCLogo.png?VfaS',
      alt: 'TSGC Logo',
      style: {
        ...styles.logo,
        opacity: opacity,
        transition: 'opacity 1s ease-in-out'
      }
    })
  );
}

const styles = {
  container: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100vw',
    height: '100vh',
    backgroundColor: '#000000',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    zIndex: 10000
  },
  logo: {
    width: '100vw',
    height: '100vh',
    objectFit: 'contain'
  }
};
