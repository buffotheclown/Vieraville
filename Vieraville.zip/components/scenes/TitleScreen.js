/**
 * TitleScreen.js
 * Initial scene - game title and start button
 */

import React, { useState, useEffect } from 'react';
import { SaveManager } from '../../managers/SaveManager.js';
import { ConfirmModal } from '../modals/ConfirmModal.js';
import { COLORS, FONTS, SPACING } from '../../constants/uiConstants.js';

export function TitleScreen({ onStart, soundManager }) {
  const [hasSave, setHasSave] = useState(false);
  const [saveMetadata, setSaveMetadata] = useState(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);

  useEffect(() => {
    const saveExists = SaveManager.hasSave();
    setHasSave(saveExists);
    if (saveExists) {
      const metadata = SaveManager.getSaveMetadata();
      setSaveMetadata(metadata);
    }
  }, []);

  const handleContinue = () => {
    if (soundManager) soundManager.playButton(); // Button: continuing game
    onStart(true); // Pass true to indicate we want to load save
  };

  const handleNewGame = () => {
    if (soundManager) soundManager.playButton();
    if (hasSave) {
      setShowDeleteConfirm(true);
    } else {
      onStart(false);
    }
  };

  const handleConfirmDelete = () => {
    if (soundManager) soundManager.playButton(); // Button: confirmed new game
    SaveManager.deleteSave();
    setHasSave(false);
    setSaveMetadata(null);
    setShowDeleteConfirm(false);
  };

  const handleCancelDelete = () => {
    if (soundManager) soundManager.playButton();
    setShowDeleteConfirm(false);
  };
  return React.createElement('div', { style: styles.container },
    React.createElement('div', { style: styles.content },
      React.createElement('h1', { style: styles.title }, 'VIERAVILLE'),
      React.createElement('h2', { style: styles.subtitle }, 'Private Town Tycoon'),
      React.createElement('p', { style: styles.tagline }, 'Build Florida\'s Premier Master-Planned Community'),
      
      // Save info (if exists)
      hasSave && saveMetadata && React.createElement('div', { style: styles.saveInfo },
        React.createElement('p', { style: styles.saveInfoText }, 
          `Last Saved: Year ${saveMetadata.year} • ${saveMetadata.population} Population`
        )
      ),

      // Buttons container
      React.createElement('div', { style: styles.buttonContainer },
        // Continue button (if save exists)
        hasSave && React.createElement('button', {
          style: styles.continueButton,
          onClick: handleContinue,
          onMouseEnter: (e) => {
            e.target.style.backgroundColor = '#388E3C';
          },
          onMouseLeave: (e) => e.target.style.backgroundColor = COLORS.PRIMARY
        }, 'CONTINUE'),

        // New game button
        React.createElement('button', {
          style: hasSave ? styles.newGameButton : styles.startButton,
          onClick: handleNewGame,
          onMouseEnter: (e) => {
            e.target.style.backgroundColor = hasSave ? '#d32f2f' : '#388E3C';
          },
          onMouseLeave: (e) => {
            e.target.style.backgroundColor = hasSave ? COLORS.ERROR : COLORS.PRIMARY;
          }
        }, hasSave ? 'NEW GAME' : 'START NEW TOWN')
      ),

      // Instructions
      React.createElement('div', { style: styles.instructions },
        React.createElement('p', { style: styles.instructionText }, 
          'Hire up to 10 managers • Start residential plans to increase your population'
        ),
        React.createElement('p', { style: styles.instructionText }, 
          'Build commercial, industrial, agricultural and amenities to create jobs'
        ),
        React.createElement('p', { style: styles.instructionText }, 
          'Make money and be happy!'
        )
      ),

      React.createElement('div', { style: styles.credits },
        React.createElement('p', { style: styles.creditText }, 'A 3-Day Game Jam Project'),
        React.createElement('p', { style: styles.creditText }, 'Inspired by Viera, Florida')
      )
    ),

    // Delete confirmation modal
    showDeleteConfirm && React.createElement(ConfirmModal, {
      message: 'DELETE current save and start new game?\n\nThis cannot be undone.',
      onConfirm: handleConfirmDelete,
      onCancel: handleCancelDelete,
      soundManager: soundManager
    })
  );
}

const styles = {
  container: {
    width: '100vw',
    height: '100vh',
    backgroundColor: '#1a1a1a',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    backgroundImage: 'linear-gradient(135deg, #1a1a1a 0%, #2d4a2b 100%)'
  },
  content: {
    textAlign: 'center',
    padding: SPACING.XLARGE
  },
  title: {
    fontFamily: FONTS.FAMILY,
    fontSize: '48px',
    color: COLORS.PRIMARY,
    margin: 0,
    marginBottom: SPACING.MEDIUM,
    textShadow: '4px 4px 0px rgba(0,0,0,0.5)',
    letterSpacing: '4px'
  },
  subtitle: {
    fontFamily: FONTS.FAMILY,
    fontSize: '20px',
    color: COLORS.ACCENT,
    margin: 0,
    marginBottom: SPACING.LARGE,
    letterSpacing: '2px'
  },
  tagline: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '16px',
    color: COLORS.TEXT_SECONDARY,
    marginBottom: SPACING.LARGE,
    maxWidth: '500px',
    margin: '0 auto',
    marginBottom: SPACING.LARGE
  },
  saveInfo: {
    marginBottom: SPACING.LARGE,
    padding: SPACING.MEDIUM,
    backgroundColor: 'rgba(46, 125, 50, 0.2)',
    borderRadius: '8px',
    border: `2px solid ${COLORS.PRIMARY}`
  },
  saveInfoText: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '14px',
    color: COLORS.TEXT_PRIMARY,
    margin: 0
  },
  buttonContainer: {
    display: 'flex',
    flexDirection: 'column',
    gap: SPACING.MEDIUM,
    alignItems: 'center'
  },
  continueButton: {
    fontFamily: FONTS.FAMILY,
    fontSize: FONTS.SIZE_MEDIUM,
    backgroundColor: COLORS.PRIMARY,
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    padding: `${SPACING.LARGE}px ${SPACING.XLARGE * 2}px`,
    cursor: 'pointer',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0,0,0,0.3)',
    transition: 'all 0.3s ease',
    letterSpacing: '2px',
    minWidth: '300px'
  },
  newGameButton: {
    fontFamily: FONTS.FAMILY,
    fontSize: FONTS.SIZE_SMALL,
    backgroundColor: COLORS.ERROR,
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    padding: `${SPACING.MEDIUM}px ${SPACING.LARGE}px`,
    cursor: 'pointer',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0,0,0,0.3)',
    transition: 'all 0.3s ease',
    letterSpacing: '2px',
    minWidth: '300px'
  },
  startButton: {
    fontFamily: FONTS.FAMILY,
    fontSize: FONTS.SIZE_MEDIUM,
    backgroundColor: COLORS.PRIMARY,
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    padding: `${SPACING.LARGE}px ${SPACING.XLARGE * 2}px`,
    cursor: 'pointer',
    borderRadius: '8px',
    boxShadow: '0 4px 8px rgba(0,0,0,0.3)',
    transition: 'all 0.3s ease',
    letterSpacing: '2px',
    minWidth: '300px'
  },
  instructions: {
    marginTop: SPACING.XLARGE * 2,
    padding: SPACING.LARGE,
    backgroundColor: 'rgba(76, 175, 80, 0.1)',
    borderRadius: '12px',
    border: `2px solid ${COLORS.PRIMARY}`,
    maxWidth: '600px',
    margin: `${SPACING.XLARGE * 2}px auto 0`
  },
  instructionText: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '14px',
    color: COLORS.TEXT_PRIMARY,
    margin: `${SPACING.SMALL}px 0`,
    lineHeight: '1.6'
  },
  credits: {
    marginTop: SPACING.XLARGE * 2,
    opacity: 0.6
  },
  creditText: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '12px',
    color: COLORS.TEXT_SECONDARY,
    margin: `${SPACING.SMALL}px 0`
  }
};