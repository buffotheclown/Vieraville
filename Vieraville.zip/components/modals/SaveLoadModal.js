/**
 * SaveLoadModal.js
 * Modal for save/load/export/import operations
 */

import React, { useState, useEffect } from 'react';
import { SaveManager } from '../../managers/SaveManager.js';
import { COLORS, SPACING, BORDER_RADIUS } from '../../constants/uiConstants.js';

export function SaveLoadModal({ onClose, onLoad, gameState, gridManager, managerCoordinator, eventManager }) {
  const [saveMetadata, setSaveMetadata] = useState(null);
  const [message, setMessage] = useState(null);

  useEffect(() => {
    const metadata = SaveManager.getSaveMetadata();
    setSaveMetadata(metadata);
  }, []);

  const handleSave = () => {
    const success = SaveManager.saveGame(gameState, gridManager, managerCoordinator, eventManager);
    if (success) {
      setMessage({ type: 'success', text: 'Game saved successfully!' });
      // Refresh metadata
      const metadata = SaveManager.getSaveMetadata();
      setSaveMetadata(metadata);
    } else {
      setMessage({ type: 'error', text: 'Failed to save game.' });
    }
  };

  const handleLoad = () => {
    const saveData = SaveManager.loadGame();
    if (saveData) {
      onLoad(saveData);
      setMessage({ type: 'success', text: 'Game loaded successfully!' });
      setTimeout(() => onClose(), 1000);
    } else {
      setMessage({ type: 'error', text: 'Failed to load game.' });
    }
  };

  const handleExport = () => {
    const success = SaveManager.exportSave();
    if (success) {
      setMessage({ type: 'success', text: 'Save exported as file!' });
    } else {
      setMessage({ type: 'error', text: 'Failed to export save.' });
    }
  };

  const handleImport = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.json';
    input.onchange = async (e) => {
      const file = e.target.files[0];
      if (file) {
        const success = await SaveManager.importSave(file);
        if (success) {
          setMessage({ type: 'success', text: 'Save imported! Reload to use.' });
          // Refresh metadata
          const metadata = SaveManager.getSaveMetadata();
          setSaveMetadata(metadata);
        } else {
          setMessage({ type: 'error', text: 'Failed to import save.' });
        }
      }
    };
    input.click();
  };

  const handleDelete = () => {
    if (confirm('Are you sure you want to delete your save? This cannot be undone!')) {
      const success = SaveManager.deleteSave();
      if (success) {
        setMessage({ type: 'success', text: 'Save deleted.' });
        setSaveMetadata(null);
      } else {
        setMessage({ type: 'error', text: 'Failed to delete save.' });
      }
    }
  };

  return React.createElement('div', { style: styles.overlay, onClick: onClose },
    React.createElement('div', { 
      style: styles.modal,
      onClick: (e) => e.stopPropagation()
    },
      // Header
      React.createElement('div', { style: styles.header },
        React.createElement('h2', { style: styles.title }, '💾 SAVE / LOAD'),
        React.createElement('button', {
          style: styles.closeButton,
          onClick: onClose
        }, '✕')
      ),

      // Content
      React.createElement('div', { style: styles.content },
        // Save info
        saveMetadata && React.createElement('div', { style: styles.saveInfo },
          React.createElement('h3', { style: styles.saveInfoTitle }, 'Current Save'),
          React.createElement('div', { style: styles.saveInfoGrid },
            React.createElement('div', { style: styles.saveInfoItem },
              React.createElement('span', { style: styles.label }, 'Saved:'),
              React.createElement('span', { style: styles.value }, 
                new Date(saveMetadata.savedAt).toLocaleString()
              )
            ),
            React.createElement('div', { style: styles.saveInfoItem },
              React.createElement('span', { style: styles.label }, 'Year:'),
              React.createElement('span', { style: styles.value }, saveMetadata.year)
            ),
            React.createElement('div', { style: styles.saveInfoItem },
              React.createElement('span', { style: styles.label }, 'Population:'),
              React.createElement('span', { style: styles.value }, 
                saveMetadata.population.toLocaleString()
              )
            ),
            React.createElement('div', { style: styles.saveInfoItem },
              React.createElement('span', { style: styles.label }, 'Budget:'),
              React.createElement('span', { style: styles.value }, 
                `$${(saveMetadata.budget / 1000000).toFixed(2)}M`
              )
            ),
            React.createElement('div', { style: styles.saveInfoItem },
              React.createElement('span', { style: styles.label }, 'Managers:'),
              React.createElement('span', { style: styles.value }, saveMetadata.managerCount)
            )
          )
        ),

        !saveMetadata && React.createElement('div', { style: styles.noSave },
          React.createElement('p', null, 'No save file found.')
        ),

        // Message
        message && React.createElement('div', { 
          style: {
            ...styles.message,
            backgroundColor: message.type === 'success' ? COLORS.SUCCESS : COLORS.ERROR
          }
        }, message.text),

        // Actions
        React.createElement('div', { style: styles.actions },
          React.createElement('button', {
            style: styles.button,
            onClick: handleSave
          }, '💾 Save Game'),

          React.createElement('button', {
            style: { ...styles.button, ...styles.loadButton },
            onClick: handleLoad,
            disabled: !saveMetadata
          }, '📂 Load Game'),

          React.createElement('button', {
            style: { ...styles.button, ...styles.secondaryButton },
            onClick: handleExport,
            disabled: !saveMetadata
          }, '📤 Export Save'),

          React.createElement('button', {
            style: { ...styles.button, ...styles.secondaryButton },
            onClick: handleImport
          }, '📥 Import Save'),

          React.createElement('button', {
            style: { ...styles.button, ...styles.deleteButton },
            onClick: handleDelete,
            disabled: !saveMetadata
          }, '🗑️ Delete Save')
        ),

        // Auto-save info
        React.createElement('div', { style: styles.autoSaveInfo },
          React.createElement('span', { style: styles.autoSaveIcon }, '⚙️'),
          React.createElement('span', { style: styles.autoSaveText }, 
            'Game auto-saves every 30 seconds'
          )
        )
      )
    )
  );
}

const styles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: COLORS.OVERLAY,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000
  },
  modal: {
    backgroundColor: COLORS.PANEL_BG,
    borderRadius: BORDER_RADIUS.LARGE,
    width: '600px',
    maxWidth: '90vw',
    maxHeight: '90vh',
    display: 'flex',
    flexDirection: 'column',
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.6)'
  },
  header: {
    padding: SPACING.LARGE,
    borderBottom: `2px solid ${COLORS.SECONDARY}`,
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  title: {
    margin: 0,
    color: COLORS.PRIMARY,
    fontSize: '20px',
    fontFamily: '"Arial", sans-serif',
    letterSpacing: '1px'
  },
  closeButton: {
    backgroundColor: 'transparent',
    color: COLORS.TEXT_SECONDARY,
    border: 'none',
    cursor: 'pointer',
    fontSize: '24px',
    padding: SPACING.SMALL,
    lineHeight: 1
  },
  content: {
    padding: SPACING.LARGE,
    flex: 1,
    overflowY: 'auto'
  },
  saveInfo: {
    backgroundColor: COLORS.MODAL_BG,
    borderRadius: BORDER_RADIUS.MEDIUM,
    padding: SPACING.MEDIUM,
    marginBottom: SPACING.LARGE
  },
  saveInfoTitle: {
    margin: `0 0 ${SPACING.MEDIUM}px 0`,
    color: COLORS.TEXT_PRIMARY,
    fontSize: '16px',
    fontFamily: '"Arial", sans-serif'
  },
  saveInfoGrid: {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: SPACING.SMALL
  },
  saveInfoItem: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: SPACING.SMALL,
    fontSize: '14px'
  },
  label: {
    color: COLORS.TEXT_SECONDARY,
    fontFamily: '"Arial", sans-serif'
  },
  value: {
    color: COLORS.TEXT_PRIMARY,
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold'
  },
  noSave: {
    textAlign: 'center',
    padding: SPACING.XLARGE,
    color: COLORS.TEXT_SECONDARY,
    fontFamily: '"Arial", sans-serif',
    fontSize: '14px'
  },
  message: {
    padding: SPACING.MEDIUM,
    borderRadius: BORDER_RADIUS.MEDIUM,
    marginBottom: SPACING.LARGE,
    color: COLORS.TEXT_PRIMARY,
    fontFamily: '"Arial", sans-serif',
    textAlign: 'center',
    fontWeight: 'bold'
  },
  actions: {
    display: 'flex',
    flexDirection: 'column',
    gap: SPACING.MEDIUM
  },
  button: {
    padding: `${SPACING.MEDIUM}px ${SPACING.LARGE}px`,
    backgroundColor: COLORS.PRIMARY,
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    borderRadius: BORDER_RADIUS.MEDIUM,
    fontSize: '16px',
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'background-color 0.2s',
    disabled: {
      backgroundColor: COLORS.TEXT_DISABLED,
      cursor: 'not-allowed'
    }
  },
  loadButton: {
    backgroundColor: COLORS.SECONDARY
  },
  secondaryButton: {
    backgroundColor: COLORS.MODAL_BG,
    border: `2px solid ${COLORS.SECONDARY}`
  },
  deleteButton: {
    backgroundColor: COLORS.ERROR
  },
  autoSaveInfo: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: SPACING.SMALL,
    marginTop: SPACING.LARGE,
    padding: SPACING.MEDIUM,
    backgroundColor: COLORS.MODAL_BG,
    borderRadius: BORDER_RADIUS.MEDIUM
  },
  autoSaveIcon: {
    fontSize: '16px'
  },
  autoSaveText: {
    color: COLORS.TEXT_SECONDARY,
    fontFamily: '"Arial", sans-serif',
    fontSize: '12px'
  }
};
