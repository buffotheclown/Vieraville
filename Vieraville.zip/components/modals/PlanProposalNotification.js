/**
 * PlanProposalNotification.js
 * Modal notification that appears when a manager proposes plans
 * Asks player if they want to view the plans
 */

import React from 'react';
import { COLORS, SPACING, BORDER_RADIUS } from '../../constants/uiConstants.js';

export function PlanProposalNotification({ managerName, managerId, onViewPlans, onDismiss }) {
  if (!managerName) return null;

  return React.createElement('div', { style: styles.overlay, onClick: onDismiss },
    React.createElement('div', { 
      style: styles.modal,
      onClick: (e) => e.stopPropagation()
    },
      // Header
      React.createElement('div', { 
        style: styles.header
      },
        React.createElement('h2', { style: styles.title }, 
          '📋 NEW PROPOSAL'
        )
      ),

      // Content
      React.createElement('div', { style: styles.content },
        React.createElement('div', { style: styles.managerName }, 
          managerName
        ),
        
        React.createElement('div', { style: styles.message }, 
          'has prepared construction plans for your review.'
        ),

        React.createElement('div', { style: styles.description }, 
          'Would you like to view their proposals?'
        )
      ),

      // Footer with two buttons
      React.createElement('div', { style: styles.footer },
        React.createElement('button', {
          style: styles.dismissButton,
          onClick: onDismiss
        }, 'Not Now'),
        
        React.createElement('button', {
          style: styles.viewButton,
          onClick: onViewPlans
        }, 'View Plans')
      )
    )
  );
}

const styles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: COLORS.OVERLAY,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
    animation: 'fadeIn 0.3s ease-out'
  },
  modal: {
    backgroundColor: COLORS.PANEL_BG,
    borderRadius: BORDER_RADIUS.LARGE,
    width: '500px',
    maxWidth: '90vw',
    maxHeight: '80vh',
    display: 'flex',
    flexDirection: 'column',
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.6)',
    animation: 'slideDown 0.3s ease-out'
  },
  header: {
    padding: SPACING.LARGE,
    backgroundColor: COLORS.INFO,
    borderRadius: `${BORDER_RADIUS.LARGE}px ${BORDER_RADIUS.LARGE}px 0 0`,
    textAlign: 'center'
  },
  title: {
    margin: 0,
    color: COLORS.TEXT_PRIMARY,
    fontSize: '20px',
    fontFamily: '"Arial", sans-serif',
    letterSpacing: '1px',
    textTransform: 'uppercase'
  },
  content: {
    padding: SPACING.LARGE,
    flex: 1,
    overflowY: 'auto',
    textAlign: 'center'
  },
  managerName: {
    fontSize: '28px',
    color: COLORS.ACCENT,
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold',
    marginBottom: SPACING.SMALL
  },
  message: {
    fontSize: '18px',
    color: COLORS.TEXT_PRIMARY,
    fontFamily: '"Arial", sans-serif',
    marginBottom: SPACING.LARGE,
    lineHeight: 1.5
  },
  description: {
    fontSize: '16px',
    color: COLORS.TEXT_SECONDARY,
    fontFamily: '"Arial", sans-serif',
    marginTop: SPACING.MEDIUM,
    fontStyle: 'italic'
  },
  footer: {
    padding: SPACING.LARGE,
    borderTop: `2px solid ${COLORS.SECONDARY}`,
    display: 'flex',
    justifyContent: 'center',
    gap: SPACING.MEDIUM
  },
  dismissButton: {
    padding: `${SPACING.MEDIUM}px ${SPACING.LARGE}px`,
    backgroundColor: COLORS.SECONDARY,
    color: COLORS.TEXT_SECONDARY,
    border: 'none',
    borderRadius: BORDER_RADIUS.MEDIUM,
    fontSize: '16px',
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold',
    cursor: 'pointer',
    minWidth: '120px',
    transition: 'background-color 0.2s'
  },
  viewButton: {
    padding: `${SPACING.MEDIUM}px ${SPACING.LARGE}px`,
    backgroundColor: COLORS.SUCCESS,
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    borderRadius: BORDER_RADIUS.MEDIUM,
    fontSize: '16px',
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold',
    cursor: 'pointer',
    minWidth: '120px',
    transition: 'background-color 0.2s'
  }
};
