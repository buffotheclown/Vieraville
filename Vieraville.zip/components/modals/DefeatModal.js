/**
 * DefeatModal.js
 * Defeat screen when player loses (happiness drops to 0 or bankruptcy)
 */

import React from 'react';
import { COLORS, SPACING, BORDER_RADIUS } from '../../constants/uiConstants.js';

export function DefeatModal({ gameState, reason, onRestart, onQuit }) {
  const yearsPlayed = gameState.year - 1;
  const finalPopulation = gameState.population;
  const finalHappiness = gameState.happiness;
  const finalBudget = gameState.budget;

  const defeatReasons = {
    unhappiness: {
      title: 'Town Rebellion',
      icon: '😢',
      message: 'Your residents have completely lost faith in your leadership. With happiness at 0%, the town council has voted to remove you from office.',
      advice: 'Remember to build amenities, maintain employment, and manage manager relationships to keep residents happy.'
    },
    bankruptcy: {
      title: 'Financial Collapse',
      icon: '💸',
      message: 'VieraVille has run out of money. Unable to pay for essential services, the town has been dissolved by the state.',
      advice: 'Focus on revenue-generating buildings and watch your expenses. Balance growth with profitability.'
    }
  };

  const defeatInfo = defeatReasons[reason] || defeatReasons.unhappiness;

  return React.createElement('div', { style: styles.overlay },
    React.createElement('div', { style: styles.modal },
      // Defeat header
      React.createElement('div', { style: styles.header },
        React.createElement('div', { style: styles.icon }, defeatInfo.icon),
        React.createElement('h1', { style: styles.title }, defeatInfo.title),
        React.createElement('h2', { style: styles.subtitle }, 'Game Over')
      ),

      // Content
      React.createElement('div', { style: styles.content },
        // Defeat message
        React.createElement('div', { style: styles.messageBox },
          React.createElement('p', { style: styles.message }, defeatInfo.message)
        ),

        // Final stats
        React.createElement('div', { style: styles.statsSection },
          React.createElement('h3', { style: styles.statsTitle }, 'Final Statistics'),
          
          React.createElement('div', { style: styles.statsGrid },
            React.createElement('div', { style: styles.statItem },
              React.createElement('span', { style: styles.statLabel }, 'Years Survived:'),
              React.createElement('span', { style: styles.statValue }, 
                `${yearsPlayed} year${yearsPlayed !== 1 ? 's' : ''}`
              )
            ),
            
            React.createElement('div', { style: styles.statItem },
              React.createElement('span', { style: styles.statLabel }, 'Population:'),
              React.createElement('span', { style: styles.statValue }, 
                finalPopulation.toLocaleString()
              )
            ),

            React.createElement('div', { style: styles.statItem },
              React.createElement('span', { style: styles.statLabel }, 'Happiness:'),
              React.createElement('span', { 
                style: { ...styles.statValue, color: finalHappiness < 30 ? COLORS.ERROR : COLORS.TEXT_PRIMARY }
              }, 
                `${finalHappiness}%`
              )
            ),

            React.createElement('div', { style: styles.statItem },
              React.createElement('span', { style: styles.statLabel }, 'Budget:'),
              React.createElement('span', { 
                style: { ...styles.statValue, color: finalBudget < 0 ? COLORS.ERROR : COLORS.TEXT_PRIMARY }
              }, 
                `$${(finalBudget / 1000000).toFixed(2)}M`
              )
            )
          )
        ),

        // Advice box
        React.createElement('div', { style: styles.adviceBox },
          React.createElement('h4', { style: styles.adviceTitle }, '💡 Tip for Next Time:'),
          React.createElement('p', { style: styles.adviceText }, defeatInfo.advice)
        ),

        // Manager info if any
        gameState.managers && gameState.managers.length > 0 && 
          React.createElement('div', { style: styles.managerSection },
            React.createElement('p', { style: styles.managerText },
              `You worked with ${gameState.managers.length} manager${gameState.managers.length !== 1 ? 's' : ''}: `,
              gameState.managers.map(m => m.name).join(', ')
            )
          )
      ),

      // Action buttons
      React.createElement('div', { style: styles.footer },
        React.createElement('button', {
          style: styles.restartButton,
          onClick: onRestart,
          onMouseEnter: (e) => e.target.style.backgroundColor = '#388E3C',
          onMouseLeave: (e) => e.target.style.backgroundColor = COLORS.PRIMARY
        }, 'TRY AGAIN'),

        React.createElement('button', {
          style: styles.quitButton,
          onClick: onQuit,
          onMouseEnter: (e) => e.target.style.backgroundColor = '#d32f2f',
          onMouseLeave: (e) => e.target.style.backgroundColor = COLORS.ERROR
        }, 'MAIN MENU')
      )
    )
  );
}

const styles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.95)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 2000,
    animation: 'fadeIn 0.5s ease-out'
  },
  modal: {
    backgroundColor: COLORS.PANEL_BG,
    borderRadius: BORDER_RADIUS.LARGE,
    width: '700px',
    maxWidth: '95vw',
    maxHeight: '90vh',
    display: 'flex',
    flexDirection: 'column',
    boxShadow: '0 16px 48px rgba(0, 0, 0, 0.9)',
    border: `4px solid ${COLORS.ERROR}`,
    overflow: 'hidden'
  },
  header: {
    padding: `${SPACING.XLARGE}px`,
    background: `linear-gradient(135deg, ${COLORS.ERROR} 0%, #c62828 100%)`,
    textAlign: 'center'
  },
  icon: {
    fontSize: '80px',
    marginBottom: SPACING.MEDIUM,
    filter: 'grayscale(50%)'
  },
  title: {
    margin: 0,
    color: COLORS.TEXT_PRIMARY,
    fontSize: '42px',
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold',
    textShadow: '2px 2px 4px rgba(0, 0, 0, 0.5)'
  },
  subtitle: {
    margin: `${SPACING.SMALL}px 0 0 0`,
    color: 'rgba(255, 255, 255, 0.8)',
    fontSize: '18px',
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'normal'
  },
  content: {
    padding: SPACING.XLARGE,
    flex: 1,
    overflowY: 'auto'
  },
  messageBox: {
    backgroundColor: COLORS.MODAL_BG,
    padding: SPACING.LARGE,
    borderRadius: BORDER_RADIUS.MEDIUM,
    border: `2px solid ${COLORS.ERROR}`,
    marginBottom: SPACING.LARGE
  },
  message: {
    fontSize: '16px',
    color: COLORS.TEXT_PRIMARY,
    fontFamily: '"Arial", sans-serif',
    lineHeight: '1.6',
    margin: 0,
    textAlign: 'center'
  },
  statsSection: {
    marginBottom: SPACING.LARGE
  },
  statsTitle: {
    fontSize: '16px',
    color: COLORS.TEXT_SECONDARY,
    fontFamily: '"Arial", sans-serif',
    marginBottom: SPACING.MEDIUM,
    textAlign: 'center',
    textTransform: 'uppercase',
    letterSpacing: '1px'
  },
  statsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(2, 1fr)',
    gap: SPACING.MEDIUM,
    backgroundColor: COLORS.MODAL_BG,
    padding: SPACING.MEDIUM,
    borderRadius: BORDER_RADIUS.MEDIUM
  },
  statItem: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: SPACING.SMALL,
    fontSize: '14px'
  },
  statLabel: {
    color: COLORS.TEXT_SECONDARY,
    fontFamily: '"Arial", sans-serif'
  },
  statValue: {
    color: COLORS.TEXT_PRIMARY,
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold'
  },
  adviceBox: {
    backgroundColor: 'rgba(33, 150, 243, 0.2)',
    padding: SPACING.LARGE,
    borderRadius: BORDER_RADIUS.MEDIUM,
    border: `2px solid ${COLORS.INFO}`,
    marginBottom: SPACING.LARGE
  },
  adviceTitle: {
    fontSize: '16px',
    color: COLORS.INFO,
    fontFamily: '"Arial", sans-serif',
    margin: `0 0 ${SPACING.SMALL}px 0`,
    fontWeight: 'bold'
  },
  adviceText: {
    fontSize: '14px',
    color: COLORS.TEXT_PRIMARY,
    fontFamily: '"Arial", sans-serif',
    lineHeight: '1.5',
    margin: 0
  },
  managerSection: {
    textAlign: 'center',
    marginTop: SPACING.MEDIUM
  },
  managerText: {
    fontSize: '13px',
    color: COLORS.TEXT_SECONDARY,
    fontFamily: '"Arial", sans-serif',
    fontStyle: 'italic',
    margin: 0
  },
  footer: {
    padding: SPACING.LARGE,
    borderTop: `2px solid ${COLORS.ERROR}`,
    display: 'flex',
    gap: SPACING.MEDIUM,
    justifyContent: 'center'
  },
  restartButton: {
    padding: `${SPACING.MEDIUM}px ${SPACING.XLARGE}px`,
    backgroundColor: COLORS.PRIMARY,
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    borderRadius: BORDER_RADIUS.MEDIUM,
    fontSize: '18px',
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'background-color 0.2s',
    minWidth: '160px',
    letterSpacing: '1px'
  },
  quitButton: {
    padding: `${SPACING.MEDIUM}px ${SPACING.XLARGE}px`,
    backgroundColor: COLORS.ERROR,
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    borderRadius: BORDER_RADIUS.MEDIUM,
    fontSize: '18px',
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'background-color 0.2s',
    minWidth: '160px',
    letterSpacing: '1px'
  }
};
