/**
 * EventModal.js
 * Modal for displaying random events and milestone achievements
 */

import React, { useEffect } from 'react';
import { COLORS, SPACING, BORDER_RADIUS } from '../../constants/uiConstants.js';

export function EventModal({ event, onClose }) {
  if (!event) return null;

  const isMilestone = event.type === 'milestone';
  const backgroundColor = isMilestone ? COLORS.SUCCESS : COLORS.PRIMARY;

  // Auto-close after 7 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      if (onClose) {
        onClose();
      }
    }, 7000);

    return () => clearTimeout(timer);
  }, [event, onClose]);

  return React.createElement('div', { style: styles.overlay, onClick: onClose },
    React.createElement('div', { 
      style: styles.modal,
      onClick: (e) => e.stopPropagation()
    },
      // Header
      React.createElement('div', { 
        style: { ...styles.header, backgroundColor }
      },
        React.createElement('h2', { style: styles.title }, 
          isMilestone ? '🏆 MILESTONE ACHIEVED!' : '📰 NEWS FLASH!'
        )
      ),

      // Content
      React.createElement('div', { style: styles.content },
        React.createElement('div', { style: styles.eventName }, event.name),
        
        React.createElement('div', { style: styles.eventMessage }, event.message),

        event.description && React.createElement('div', { style: styles.eventDescription }, 
          event.description
        ),

        event.result && React.createElement('div', { style: styles.eventResult },
          React.createElement('strong', null, 'Effect: '),
          event.result
        ),

        event.reward && React.createElement('div', { style: styles.reward },
          React.createElement('span', { style: styles.rewardIcon }, '💰'),
          React.createElement('span', { style: styles.rewardText }, 
            `Reward: $${(event.reward / 1000).toFixed(0)}K`
          )
        )
      ),

      // Footer
      React.createElement('div', { style: styles.footer },
        React.createElement('button', {
          style: styles.closeButton,
          onClick: onClose
        }, 'Continue')
      )
    )
  );
}

const styles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: COLORS.OVERLAY,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000,
    animation: 'fadeIn 0.3s ease-out'
  },
  modal: {
    backgroundColor: COLORS.PANEL_BG,
    borderRadius: BORDER_RADIUS.LARGE,
    width: '500px',
    maxWidth: '90vw',
    maxHeight: '80vh',
    display: 'flex',
    flexDirection: 'column',
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.6)',
    animation: 'slideDown 0.3s ease-out'
  },
  header: {
    padding: SPACING.LARGE,
    borderRadius: `${BORDER_RADIUS.LARGE}px ${BORDER_RADIUS.LARGE}px 0 0`,
    textAlign: 'center'
  },
  title: {
    margin: 0,
    color: COLORS.TEXT_PRIMARY,
    fontSize: '20px',
    fontFamily: '"Arial", sans-serif',
    letterSpacing: '1px',
    textTransform: 'uppercase'
  },
  content: {
    padding: SPACING.LARGE,
    flex: 1,
    overflowY: 'auto',
    textAlign: 'center'
  },
  eventName: {
    fontSize: '24px',
    color: COLORS.TEXT_PRIMARY,
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold',
    marginBottom: SPACING.MEDIUM
  },
  eventMessage: {
    fontSize: '16px',
    color: COLORS.TEXT_SECONDARY,
    fontFamily: '"Arial", sans-serif',
    marginBottom: SPACING.LARGE,
    lineHeight: 1.5
  },
  eventDescription: {
    fontSize: '14px',
    color: COLORS.TEXT_SECONDARY,
    fontFamily: '"Arial", sans-serif',
    marginBottom: SPACING.MEDIUM,
    fontStyle: 'italic'
  },
  eventResult: {
    fontSize: '16px',
    color: COLORS.ACCENT,
    fontFamily: '"Arial", sans-serif',
    marginBottom: SPACING.MEDIUM,
    padding: SPACING.MEDIUM,
    backgroundColor: COLORS.MODAL_BG,
    borderRadius: BORDER_RADIUS.MEDIUM
  },
  reward: {
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    gap: SPACING.SMALL,
    padding: SPACING.MEDIUM,
    backgroundColor: 'rgba(46, 125, 50, 0.2)',
    borderRadius: BORDER_RADIUS.MEDIUM,
    marginTop: SPACING.MEDIUM
  },
  rewardIcon: {
    fontSize: '24px'
  },
  rewardText: {
    fontSize: '18px',
    color: COLORS.SUCCESS,
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold'
  },
  footer: {
    padding: SPACING.LARGE,
    borderTop: `2px solid ${COLORS.SECONDARY}`,
    display: 'flex',
    justifyContent: 'center'
  },
  closeButton: {
    padding: `${SPACING.MEDIUM}px ${SPACING.XLARGE}px`,
    backgroundColor: COLORS.PRIMARY,
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    borderRadius: BORDER_RADIUS.MEDIUM,
    fontSize: '16px',
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold',
    cursor: 'pointer',
    minWidth: '150px',
    transition: 'background-color 0.2s'
  }
};
