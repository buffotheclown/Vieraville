/**
 * ConfirmModal.js
 * Custom confirmation dialog
 */

import React from 'react';
import { COLORS, SPACING, BORDER_RADIUS } from '../../constants/uiConstants.js';

export function ConfirmModal({ message, onConfirm, onCancel, soundManager }) {
  const handleConfirm = () => {
    if (soundManager) soundManager.playButton();
    onConfirm();
  };
  
  const handleCancel = () => {
    if (soundManager) soundManager.playButton();
    onCancel();
  };
  
  return React.createElement('div', { style: styles.overlay, onClick: handleCancel },
    React.createElement('div', { 
      style: styles.modal,
      onClick: (e) => e.stopPropagation()
    },
      // Content
      React.createElement('div', { style: styles.content },
        React.createElement('div', { style: styles.icon }, '⚠️'),
        React.createElement('div', { style: styles.message }, message)
      ),

      // Buttons
      React.createElement('div', { style: styles.buttonContainer },
        React.createElement('button', {
          style: styles.cancelButton,
          onClick: handleCancel
        }, 'NO'),
        
        React.createElement('button', {
          style: styles.confirmButton,
          onClick: handleConfirm
        }, 'YES, DELETE SAVE')
      )
    )
  );
}

const styles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 10000,
    animation: 'fadeIn 0.2s ease-out'
  },
  modal: {
    backgroundColor: '#2a2a2a',
    borderRadius: BORDER_RADIUS.LARGE,
    width: '500px',
    maxWidth: '90vw',
    padding: SPACING.XLARGE,
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.8)',
    border: '3px solid #d32f2f'
  },
  content: {
    textAlign: 'center',
    marginBottom: SPACING.LARGE
  },
  icon: {
    fontSize: '48px',
    marginBottom: SPACING.MEDIUM
  },
  message: {
    fontSize: '18px',
    color: COLORS.TEXT_PRIMARY,
    fontFamily: '"Arial", sans-serif',
    lineHeight: 1.6,
    whiteSpace: 'pre-line'
  },
  buttonContainer: {
    display: 'flex',
    gap: SPACING.MEDIUM,
    justifyContent: 'center'
  },
  cancelButton: {
    padding: `${SPACING.MEDIUM}px ${SPACING.XLARGE}px`,
    backgroundColor: COLORS.SECONDARY,
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    borderRadius: BORDER_RADIUS.MEDIUM,
    fontSize: '16px',
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold',
    cursor: 'pointer',
    minWidth: '120px',
    transition: 'background-color 0.2s'
  },
  confirmButton: {
    padding: `${SPACING.MEDIUM}px ${SPACING.XLARGE}px`,
    backgroundColor: '#d32f2f',
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    borderRadius: BORDER_RADIUS.MEDIUM,
    fontSize: '16px',
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold',
    cursor: 'pointer',
    minWidth: '180px',
    transition: 'background-color 0.2s'
  }
};
