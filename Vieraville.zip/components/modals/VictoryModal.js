/**
 * VictoryModal.js
 * Victory screen when player achieves win conditions
 */

import React from 'react';
import { COLORS, SPACING, BORDER_RADIUS } from '../../constants/uiConstants.js';
import { WIN_CONDITIONS } from '../../constants/gameConfig.js';

export function VictoryModal({ gameState, onRestart, onContinue }) {
  const yearsPlayed = gameState.year - 1;
  const finalPopulation = gameState.population;
  const finalHappiness = gameState.happiness;
  const finalBudget = gameState.budget;

  return React.createElement('div', { style: styles.overlay },
    React.createElement('div', { style: styles.modal },
      // Victory header with animation
      React.createElement('div', { style: styles.header },
        React.createElement('div', { style: styles.trophy }, '🏆'),
        React.createElement('h1', { style: styles.title }, 'VICTORY!'),
        React.createElement('h2', { style: styles.subtitle }, 'VieraVille is a Thriving Success!')
      ),

      // Stats display
      React.createElement('div', { style: styles.content },
        React.createElement('div', { style: styles.statsGrid },
          React.createElement('div', { style: styles.statBox },
            React.createElement('div', { style: styles.statIcon }, '⏱️'),
            React.createElement('div', { style: styles.statLabel }, 'Time Played'),
            React.createElement('div', { style: styles.statValue }, 
              `${yearsPlayed} Year${yearsPlayed !== 1 ? 's' : ''}`
            )
          ),
          
          React.createElement('div', { style: styles.statBox },
            React.createElement('div', { style: styles.statIcon }, '👥'),
            React.createElement('div', { style: styles.statLabel }, 'Final Population'),
            React.createElement('div', { style: styles.statValue }, 
              finalPopulation.toLocaleString()
            ),
            React.createElement('div', { style: styles.statSubtext }, 
              `Target: ${WIN_CONDITIONS.TARGET_POPULATION.toLocaleString()}`
            )
          ),

          React.createElement('div', { style: styles.statBox },
            React.createElement('div', { style: styles.statIcon }, '😊'),
            React.createElement('div', { style: styles.statLabel }, 'Town Happiness'),
            React.createElement('div', { style: styles.statValue }, 
              `${finalHappiness}%`
            ),
            React.createElement('div', { style: styles.statSubtext }, 
              `Target: ${WIN_CONDITIONS.MIN_HAPPINESS}%`
            )
          ),

          React.createElement('div', { style: styles.statBox },
            React.createElement('div', { style: styles.statIcon }, '💰'),
            React.createElement('div', { style: styles.statLabel }, 'Final Budget'),
            React.createElement('div', { style: styles.statValue }, 
              `$${(finalBudget / 1000000).toFixed(2)}M`
            )
          )
        ),

        // Achievement message
        React.createElement('div', { style: styles.achievementBox },
          React.createElement('p', { style: styles.achievementText },
            'You have successfully built VieraVille into a prosperous master-planned community! ',
            'Your vision, leadership, and strategic planning have created a town where ',
            `${finalPopulation.toLocaleString()} residents live happily. Florida\'s newest jewel shines bright!`
          )
        ),

        // Manager credits
        gameState.managers && gameState.managers.length > 0 && 
          React.createElement('div', { style: styles.managerSection },
            React.createElement('h3', { style: styles.managerTitle }, 'Your Management Team:'),
            React.createElement('div', { style: styles.managerList },
              gameState.managers.map(manager =>
                React.createElement('div', { key: manager.id, style: styles.managerCredit },
                  React.createElement('span', { style: styles.managerName }, manager.name),
                  React.createElement('span', { style: styles.managerSpecialty }, manager.specialty)
                )
              )
            )
          )
      ),

      // Action buttons
      React.createElement('div', { style: styles.footer },
        React.createElement('button', {
          style: styles.continueButton,
          onClick: onContinue,
          onMouseEnter: (e) => e.target.style.backgroundColor = '#388E3C',
          onMouseLeave: (e) => e.target.style.backgroundColor = COLORS.SUCCESS
        }, 'KEEP PLAYING'),

        React.createElement('button', {
          style: styles.restartButton,
          onClick: onRestart,
          onMouseEnter: (e) => e.target.style.backgroundColor = '#1976D2',
          onMouseLeave: (e) => e.target.style.backgroundColor = COLORS.SECONDARY
        }, 'NEW TOWN')
      )
    )
  );
}

const styles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.9)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 2000,
    animation: 'fadeIn 0.5s ease-out'
  },
  modal: {
    backgroundColor: COLORS.PANEL_BG,
    borderRadius: BORDER_RADIUS.LARGE,
    width: '900px',
    maxWidth: '95vw',
    maxHeight: '90vh',
    display: 'flex',
    flexDirection: 'column',
    boxShadow: '0 16px 48px rgba(0, 0, 0, 0.8)',
    border: `4px solid ${COLORS.SUCCESS}`,
    overflow: 'hidden'
  },
  header: {
    padding: `${SPACING.XLARGE}px`,
    background: `linear-gradient(135deg, ${COLORS.SUCCESS} 0%, ${COLORS.PRIMARY} 100%)`,
    textAlign: 'center',
    position: 'relative',
    overflow: 'hidden'
  },
  trophy: {
    fontSize: '80px',
    marginBottom: SPACING.MEDIUM,
    animation: 'bounce 1s ease-in-out infinite'
  },
  title: {
    margin: 0,
    color: COLORS.TEXT_PRIMARY,
    fontSize: '48px',
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold',
    textShadow: '2px 2px 4px rgba(0, 0, 0, 0.5)',
    letterSpacing: '3px'
  },
  subtitle: {
    margin: `${SPACING.SMALL}px 0 0 0`,
    color: 'rgba(255, 255, 255, 0.9)',
    fontSize: '20px',
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'normal'
  },
  content: {
    padding: SPACING.XLARGE,
    flex: 1,
    overflowY: 'auto'
  },
  statsGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(200px, 1fr))',
    gap: SPACING.MEDIUM,
    marginBottom: SPACING.XLARGE
  },
  statBox: {
    backgroundColor: COLORS.MODAL_BG,
    padding: SPACING.MEDIUM,
    borderRadius: BORDER_RADIUS.MEDIUM,
    textAlign: 'center',
    border: `2px solid ${COLORS.SUCCESS}`
  },
  statIcon: {
    fontSize: '40px',
    marginBottom: SPACING.SMALL
  },
  statLabel: {
    fontSize: '12px',
    color: COLORS.TEXT_SECONDARY,
    fontFamily: '"Arial", sans-serif',
    marginBottom: SPACING.SMALL,
    textTransform: 'uppercase',
    letterSpacing: '1px'
  },
  statValue: {
    fontSize: '28px',
    color: COLORS.SUCCESS,
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold'
  },
  statSubtext: {
    fontSize: '11px',
    color: COLORS.TEXT_SECONDARY,
    fontFamily: '"Arial", sans-serif',
    marginTop: '4px'
  },
  achievementBox: {
    backgroundColor: 'rgba(46, 125, 50, 0.2)',
    padding: SPACING.LARGE,
    borderRadius: BORDER_RADIUS.MEDIUM,
    border: `2px solid ${COLORS.SUCCESS}`,
    marginBottom: SPACING.LARGE
  },
  achievementText: {
    fontSize: '16px',
    color: COLORS.TEXT_PRIMARY,
    fontFamily: '"Arial", sans-serif',
    lineHeight: '1.6',
    margin: 0,
    textAlign: 'center'
  },
  managerSection: {
    marginTop: SPACING.LARGE
  },
  managerTitle: {
    fontSize: '18px',
    color: COLORS.PRIMARY,
    fontFamily: '"Arial", sans-serif',
    marginBottom: SPACING.MEDIUM,
    textAlign: 'center'
  },
  managerList: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: SPACING.SMALL,
    justifyContent: 'center'
  },
  managerCredit: {
    backgroundColor: COLORS.MODAL_BG,
    padding: `${SPACING.SMALL}px ${SPACING.MEDIUM}px`,
    borderRadius: BORDER_RADIUS.SMALL,
    border: `1px solid ${COLORS.TEXT_DISABLED}`,
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center'
  },
  managerName: {
    fontSize: '14px',
    color: COLORS.TEXT_PRIMARY,
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold'
  },
  managerSpecialty: {
    fontSize: '11px',
    color: COLORS.TEXT_SECONDARY,
    fontFamily: '"Arial", sans-serif'
  },
  footer: {
    padding: SPACING.LARGE,
    borderTop: `2px solid ${COLORS.SUCCESS}`,
    display: 'flex',
    gap: SPACING.MEDIUM,
    justifyContent: 'center'
  },
  continueButton: {
    padding: `${SPACING.MEDIUM}px ${SPACING.XLARGE}px`,
    backgroundColor: COLORS.SUCCESS,
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    borderRadius: BORDER_RADIUS.MEDIUM,
    fontSize: '18px',
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'background-color 0.2s',
    minWidth: '180px',
    letterSpacing: '1px'
  },
  restartButton: {
    padding: `${SPACING.MEDIUM}px ${SPACING.XLARGE}px`,
    backgroundColor: COLORS.SECONDARY,
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    borderRadius: BORDER_RADIUS.MEDIUM,
    fontSize: '18px',
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold',
    cursor: 'pointer',
    transition: 'background-color 0.2s',
    minWidth: '180px',
    letterSpacing: '1px'
  }
};
