/**
 * ManagerDetailModal.js
 * Modal for reviewing manager plans and taking actions
 */

import React from 'react';
import { COLORS, FONTS, SPACING, BORDER_RADIUS, MODAL_SIZES } from '../../constants/uiConstants.js';
import { MANAGER_SALARY } from '../../constants/gameConfig.js';

export function ManagerDetailModal({ manager, onClose, onApprove, onDeny, onRaise, onFire, onReset, isFirstPlan = false }) {
  const hasActivePlan = manager.state === 'proposing' && (manager.currentPlan || (manager.currentPlans && manager.currentPlans.length > 0));
  const hasMultiplePlans = manager.currentPlans && manager.currentPlans.length > 0;

  // If this is the first plan, don't allow closing
  const handleOverlayClick = isFirstPlan ? undefined : onClose;

  return React.createElement('div', { style: styles.overlay, onClick: handleOverlayClick },
    React.createElement('div', {
      style: styles.modal,
      onClick: (e) => e.stopPropagation()
    },
      // Header
      React.createElement('div', { style: styles.header },
        React.createElement('h2', { style: styles.title }, 
          isFirstPlan ? '🏗️ SELECT YOUR FIRST PROJECT' : `${manager.name} - ${manager.specialty}`
        ),
        // Hide close button for first plan
        !isFirstPlan && React.createElement('button', {
          style: styles.closeButton,
          onClick: onClose
        }, '×')
      ),

      // Content
      React.createElement('div', { style: styles.content },
        // Portrait and stats
        React.createElement('div', { style: styles.topSection },
          React.createElement('div', { style: styles.portrait },
            React.createElement('span', { style: styles.initials },
              manager.name.split(' ').map(n => n[0]).join('')
            )
          ),
          React.createElement('div', { style: styles.statsSection },
            React.createElement('div', { style: styles.statRow },
              React.createElement('span', { style: styles.statLabel }, 'Happiness:'),
              React.createElement('span', { style: styles.statValue }, `😊 ${manager.happiness}`)
            ),
            React.createElement('div', { style: styles.statRow },
              React.createElement('span', { style: styles.statLabel }, 'Efficiency:'),
              React.createElement('span', { style: styles.statValue }, `⚡ ${manager.efficiency}`)
            ),
            React.createElement('div', { style: styles.statRow },
              React.createElement('span', { style: styles.statLabel }, 'Annual Salary:'),
              React.createElement('span', { style: styles.statValue }, 
                `$${(MANAGER_SALARY.BASE_ANNUAL + (manager.raises || 0) * MANAGER_SALARY.RAISE_INCREASE).toLocaleString()}`
              )
            ),
            React.createElement('div', { style: styles.statRow },
              React.createElement('span', { style: styles.statLabel }, 'Status:'),
              React.createElement('span', { style: styles.statValue }, manager.status)
            )
          )
        ),

        // Multiple plans or single plan
        hasActivePlan && React.createElement('div', { style: styles.planSection },
          React.createElement('h3', { style: styles.sectionTitle }, hasMultiplePlans ? 'CHOOSE A PLAN:' : 'CURRENT PLAN:'),
          
          // Show multiple plans side by side
          hasMultiplePlans ? React.createElement('div', { style: styles.plansGrid },
            ...manager.currentPlans.map((plan, index) => 
              React.createElement('div', { 
                key: index,
                style: styles.planCard 
              },
                React.createElement('h4', { style: styles.planCardTitle }, `Option ${index + 1}`),
                React.createElement('div', { style: styles.planCardContent },
                  React.createElement('p', { style: styles.planCardText }, 
                    `Build ${plan.buildingCount}x ${plan.buildingName}`
                  ),
                  React.createElement('p', { style: styles.planCardText }, 
                    `Total Cost: $${plan.totalCost.toLocaleString()}`
                  ),
                  React.createElement('p', { style: styles.planCardText }, 
                    `Expected Revenue: $${plan.expectedRevenue.toLocaleString()}/month`
                  ),
                  plan.expectedPopulation > 0 && React.createElement('p', { style: styles.planCardText }, 
                    `Population: +${plan.expectedPopulation} residents`
                  ),
                  plan.expectedJobs > 0 && React.createElement('p', { style: styles.planCardText }, 
                    `Jobs: +${plan.expectedJobs} positions`
                  ),
                  React.createElement('p', { style: styles.planCardText }, 
                    `Town Happiness: ${plan.expectedHappiness > 0 ? '+' : ''}${plan.expectedHappiness}%`
                  )
                ),
                React.createElement('button', {
                  style: styles.selectPlanButton,
                  onClick: () => {
                    onApprove(manager.id, index);
                    onClose();
                  },
                  onMouseEnter: (e) => e.target.style.backgroundColor = '#66BB6A',
                  onMouseLeave: (e) => e.target.style.backgroundColor = COLORS.SUCCESS
                }, '✓ SELECT THIS PLAN')
              )
            )
          ) : 
          // Show single plan
          React.createElement('div', { style: styles.planDetails },
            React.createElement('p', { style: styles.planText }, 
              `Build ${manager.currentPlan.buildingCount}x ${manager.currentPlan.buildingName}`
            ),
            React.createElement('p', { style: styles.planText }, 
              `Total Cost: $${manager.currentPlan.totalCost.toLocaleString()}`
            ),
            React.createElement('p', { style: styles.planText }, 
              `Expected Revenue: $${manager.currentPlan.expectedRevenue.toLocaleString()}/month`
            ),
            manager.currentPlan.expectedPopulation > 0 && React.createElement('p', { style: styles.planText }, 
              `Population: +${manager.currentPlan.expectedPopulation} residents`
            ),
            manager.currentPlan.expectedJobs > 0 && React.createElement('p', { style: styles.planText }, 
              `Jobs: +${manager.currentPlan.expectedJobs} positions`
            ),
            React.createElement('p', { style: styles.planText }, 
              `Town Happiness: ${manager.currentPlan.expectedHappiness > 0 ? '+' : ''}${manager.currentPlan.expectedHappiness}%`
            )
          ),

          // Approve/Deny buttons for single plan
          !hasMultiplePlans && React.createElement('div', { style: styles.buttonRow },
            React.createElement('button', {
              style: styles.approveButton,
              onClick: () => {
                onApprove(manager.id);
                onClose();
              },
              onMouseEnter: (e) => e.target.style.backgroundColor = '#66BB6A',
              onMouseLeave: (e) => e.target.style.backgroundColor = COLORS.SUCCESS
            }, '✓ APPROVE'),
            // Hide deny button for first plan
            !isFirstPlan && React.createElement('button', {
              style: styles.denyButton,
              onClick: () => {
                onDeny(manager.id);
                onClose();
              },
              onMouseEnter: (e) => e.target.style.backgroundColor = '#EF5350',
              onMouseLeave: (e) => e.target.style.backgroundColor = COLORS.ERROR
            }, '✗ DENY')
          ),

          // Deny button for multiple plans (hide for first plan)
          hasMultiplePlans && !isFirstPlan && React.createElement('div', { style: styles.buttonRow },
            React.createElement('button', {
              style: styles.denyButton,
              onClick: () => {
                onDeny(manager.id);
                onClose();
              },
              onMouseEnter: (e) => e.target.style.backgroundColor = '#EF5350',
              onMouseLeave: (e) => e.target.style.backgroundColor = COLORS.ERROR
            }, '✗ REJECT ALL PLANS')
          )
        ),

        // Actions (hide for first plan)
        !isFirstPlan && React.createElement('div', { style: styles.actionsSection },
          React.createElement('h3', { style: styles.sectionTitle }, 'ACTIONS:'),
          React.createElement('button', {
            style: styles.actionButton,
            onClick: () => {
              console.log('=== GIVE RAISE BUTTON CLICKED ===');
              console.log('Manager ID:', manager.id);
              console.log('Manager name:', manager.name);
              console.log('Current raises:', manager.raises);
              console.log('Current salary:', MANAGER_SALARY.BASE_ANNUAL + (manager.raises || 0) * MANAGER_SALARY.RAISE_INCREASE);
              onRaise(manager.id);
              console.log('After onRaise - raises:', manager.raises);
              console.log('After onRaise - new salary:', MANAGER_SALARY.BASE_ANNUAL + (manager.raises || 0) * MANAGER_SALARY.RAISE_INCREASE);
              // Don't close modal - let user see updated salary
            }
          }, 'GIVE RAISE ($50K - +5 Happiness)'),
          React.createElement('button', {
            style: styles.actionButton,
            onClick: () => {
              console.log('RESET BUTTON CLICKED - Manager:', manager.name, 'ID:', manager.id);
              onReset(manager.id);
              onClose();
            }
          }, 'RESET MANAGER'),
          React.createElement('button', {
            style: { ...styles.actionButton, ...styles.fireButton },
            onClick: () => {
              if (confirm(`Fire ${manager.name}? This cannot be undone.`)) {
                onFire(manager.id);
                onClose();
              }
            }
          }, 'FIRE MANAGER')
        )
      )
    )
  );
}

const styles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.8)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 1000
  },
  modal: {
    backgroundColor: COLORS.MODAL_BG,
    borderRadius: BORDER_RADIUS.LARGE,
    width: '1000px',
    maxWidth: '95vw',
    maxHeight: '90vh',
    overflow: 'auto',
    border: `3px solid ${COLORS.PRIMARY}`
  },
  header: {
    padding: SPACING.LARGE,
    borderBottom: `2px solid ${COLORS.TEXT_DISABLED}`,
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  title: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '20px',
    color: COLORS.TEXT_PRIMARY,
    margin: 0
  },
  closeButton: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '32px',
    backgroundColor: 'transparent',
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    cursor: 'pointer',
    padding: 0,
    width: '40px',
    height: '40px'
  },
  content: {
    padding: SPACING.LARGE
  },
  topSection: {
    display: 'flex',
    gap: SPACING.LARGE,
    marginBottom: SPACING.LARGE
  },
  portrait: {
    width: '100px',
    height: '100px',
    backgroundColor: COLORS.PRIMARY,
    borderRadius: BORDER_RADIUS.MEDIUM,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flexShrink: 0
  },
  initials: {
    fontFamily: FONTS.FAMILY,
    fontSize: '32px',
    color: COLORS.TEXT_PRIMARY
  },
  statsSection: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    gap: SPACING.SMALL
  },
  statRow: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  statLabel: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '16px',
    color: COLORS.TEXT_SECONDARY
  },
  statValue: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '18px',
    color: COLORS.TEXT_PRIMARY,
    fontWeight: 'bold'
  },
  planSection: {
    backgroundColor: COLORS.PANEL_BG,
    borderRadius: BORDER_RADIUS.MEDIUM,
    padding: SPACING.LARGE,
    marginBottom: SPACING.LARGE
  },
  sectionTitle: {
    fontFamily: FONTS.FAMILY,
    fontSize: FONTS.SIZE_SMALL,
    color: COLORS.ACCENT,
    margin: `0 0 ${SPACING.MEDIUM}px 0`
  },
  planDetails: {
    marginBottom: SPACING.LARGE
  },
  planText: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '14px',
    color: COLORS.TEXT_PRIMARY,
    margin: `${SPACING.SMALL}px 0`
  },
  plansGrid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(3, 1fr)',
    gap: SPACING.MEDIUM,
    marginBottom: SPACING.LARGE
  },
  planCard: {
    backgroundColor: COLORS.MODAL_BG,
    border: `2px solid ${COLORS.TEXT_DISABLED}`,
    borderRadius: BORDER_RADIUS.MEDIUM,
    padding: SPACING.MEDIUM,
    display: 'flex',
    flexDirection: 'column'
  },
  planCardTitle: {
    fontFamily: FONTS.FAMILY,
    fontSize: '14px',
    color: COLORS.ACCENT,
    margin: `0 0 ${SPACING.SMALL}px 0`,
    textAlign: 'center'
  },
  planCardContent: {
    flex: 1,
    marginBottom: SPACING.MEDIUM
  },
  planCardText: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '12px',
    color: COLORS.TEXT_PRIMARY,
    margin: `${SPACING.SMALL}px 0`,
    lineHeight: '1.4'
  },
  selectPlanButton: {
    width: '100%',
    fontFamily: FONTS.FAMILY,
    fontSize: '12px',
    backgroundColor: COLORS.SUCCESS,
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    padding: `${SPACING.SMALL}px`,
    cursor: 'pointer',
    borderRadius: BORDER_RADIUS.SMALL,
    transition: 'all 0.3s ease',
    letterSpacing: '1px'
  },
  buttonRow: {
    display: 'flex',
    gap: SPACING.MEDIUM
  },
  approveButton: {
    flex: 1,
    fontFamily: FONTS.FAMILY,
    fontSize: FONTS.SIZE_SMALL,
    backgroundColor: COLORS.SUCCESS,
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    padding: `${SPACING.MEDIUM}px`,
    cursor: 'pointer',
    borderRadius: BORDER_RADIUS.MEDIUM,
    transition: 'all 0.3s ease',
    letterSpacing: '1px'
  },
  denyButton: {
    flex: 1,
    fontFamily: FONTS.FAMILY,
    fontSize: FONTS.SIZE_SMALL,
    backgroundColor: COLORS.ERROR,
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    padding: `${SPACING.MEDIUM}px`,
    cursor: 'pointer',
    borderRadius: BORDER_RADIUS.MEDIUM,
    transition: 'all 0.3s ease',
    letterSpacing: '1px'
  },
  actionsSection: {
    borderTop: `2px solid ${COLORS.TEXT_DISABLED}`,
    paddingTop: SPACING.LARGE
  },
  actionButton: {
    width: '100%',
    fontFamily: '"Arial", sans-serif',
    fontSize: '14px',
    backgroundColor: COLORS.SECONDARY,
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    padding: `${SPACING.MEDIUM}px`,
    cursor: 'pointer',
    borderRadius: BORDER_RADIUS.MEDIUM,
    marginBottom: SPACING.SMALL,
    transition: 'all 0.2s ease'
  },
  fireButton: {
    backgroundColor: COLORS.ERROR
  }
};
