/**
 * InspectionModal.js
 * Modal for inspecting buildings and roads, with repair/demolish options
 */

import React from 'react';
import { COLORS, FONTS, SPACING, BORDER_RADIUS } from '../../constants/uiConstants.js';

export function InspectionModal({ info, type, onClose, onRepair, onDemolish }) {
  if (!info) return null;

  const isBuilding = type === 'building';
  const isRoad = type === 'road';

  const handleRepair = () => {
    if (onRepair) {
      onRepair(info.position.x, info.position.y, info.buildingId);
    }
  };

  const handleDemolish = () => {
    console.log('🔴 [InspectionModal] handleDemolish called - NO CONFIRMATION NEEDED');
    console.log('  info.buildingId:', info.buildingId);
    console.log('  info.name:', info.name);
    
    if (onDemolish) {
      console.log('  Calling onDemolish directly (no confirmation)');
      onDemolish(info.buildingId);
      console.log('  onDemolish called successfully');
    } else {
      console.error('  ❌ onDemolish is not defined!');
    }
  };

  return React.createElement('div', { style: styles.overlay, onClick: onClose },
    React.createElement('div', {
      style: styles.modal,
      onClick: (e) => e.stopPropagation()
    },
      // Header
      React.createElement('div', { style: styles.header },
        React.createElement('h2', { style: styles.title },
          isBuilding ? '🏢 Building Inspection' : '🛣️ Road Inspection'
        ),
        React.createElement('button', {
          style: styles.closeButton,
          onClick: onClose
        }, '✕')
      ),

      // Content
      React.createElement('div', { style: styles.content },
        // Building Info
        isBuilding && React.createElement('div', null,
          React.createElement('h3', { style: styles.buildingName }, info.name),
          React.createElement('div', { style: styles.infoGrid },
            // Location
            React.createElement('div', { style: styles.infoRow },
              React.createElement('span', { style: styles.label }, 'Location:'),
              React.createElement('span', { style: styles.value }, `(${info.position.x}, ${info.position.y})`)
            ),
            // Type
            React.createElement('div', { style: styles.infoRow },
              React.createElement('span', { style: styles.label }, 'Type:'),
              React.createElement('span', { style: styles.value }, info.type)
            ),
            // Year Built
            React.createElement('div', { style: styles.infoRow },
              React.createElement('span', { style: styles.label }, 'Built:'),
              React.createElement('span', { style: styles.value }, 
                `${info.yearBuilt} (${info.yearsSinceBuilt} years ago)`
              )
            ),
            // Owner Manager
            info.ownerManager && React.createElement('div', { style: styles.infoRow },
              React.createElement('span', { style: styles.label }, 'Built by:'),
              React.createElement('span', { style: styles.value }, info.ownerManager)
            ),
            // Divider
            React.createElement('div', { style: styles.divider }),
            // Population
            info.maxPopulation > 0 && React.createElement('div', { style: styles.infoRow },
              React.createElement('span', { style: styles.label }, 'Population:'),
              React.createElement('span', { style: styles.value }, 
                `${info.population} / ${info.maxPopulation} residents`
              )
            ),
            // Employment
            info.jobs > 0 && React.createElement('div', { style: styles.infoRow },
              React.createElement('span', { style: styles.label }, 'Employment:'),
              React.createElement('span', { 
                style: {
                  ...styles.value,
                  color: info.employmentRate >= 0.8 ? '#2ecc71' : 
                         info.employmentRate >= 0.5 ? '#f39c12' : '#e74c3c'
                }
              }, 
                `${info.employees} / ${info.jobs} workers (${Math.round(info.employmentRate * 100)}%)`
              )
            ),
            // Revenue
            info.revenue > 0 && React.createElement('div', { style: styles.infoRow },
              React.createElement('span', { style: styles.label }, 'Revenue:'),
              React.createElement('span', { style: { ...styles.value, color: '#2ecc71' } }, 
                `$${(info.revenue / 1000).toFixed(1)}K / season`
              )
            ),
            // Happiness
            info.happiness !== 0 && React.createElement('div', { style: styles.infoRow },
              React.createElement('span', { style: styles.label }, 'Happiness:'),
              React.createElement('span', { 
                style: {
                  ...styles.value,
                  color: info.happiness > 0 ? '#2ecc71' : '#e74c3c'
                }
              }, 
                `${info.happiness > 0 ? '+' : ''}${info.happiness}`
              )
            )
          )
        ),

        // Road Info
        isRoad && React.createElement('div', null,
          React.createElement('h3', { style: styles.buildingName }, 'Road Tile'),
          React.createElement('div', { style: styles.infoGrid },
            React.createElement('div', { style: styles.infoRow },
              React.createElement('span', { style: styles.label }, 'Location:'),
              React.createElement('span', { style: styles.value }, `(${info.position.x}, ${info.position.y})`)
            ),
            React.createElement('div', { style: styles.infoRow },
              React.createElement('span', { style: styles.label }, 'Quality:'),
              React.createElement('span', { style: styles.value }, `${Math.round(info.quality * 100)}%`)
            ),
            React.createElement('div', { style: styles.infoRow },
              React.createElement('span', { style: styles.label }, 'Orientation:'),
              React.createElement('span', { style: styles.value }, info.orientation)
            )
          )
        ),

        // Maintenance Warning
        info.needsRepair && React.createElement('div', { style: styles.warningBox },
          React.createElement('div', { style: styles.warningHeader }, '⚠️ NEEDS REPAIR'),
          React.createElement('div', { style: styles.warningText },
            `This ${isBuilding ? 'building' : 'road'} is in disrepair and needs maintenance.`
          ),
          React.createElement('div', { style: styles.warningCost },
            `Repair Cost: $${info.repairCost.toLocaleString()}`
          )
        )
      ),

      // Actions
      React.createElement('div', { style: styles.actions },
        // Repair Button
        info.needsRepair && React.createElement('button', {
          style: { ...styles.actionButton, ...styles.repairButton },
          onClick: handleRepair
        }, `🔧 Repair ($${info.repairCost.toLocaleString()})`),

        // Demolish Button (buildings only)
        isBuilding && React.createElement('button', {
          style: { ...styles.actionButton, ...styles.demolishButton },
          onClick: handleDemolish
        }, '🏚️ DEMOLISH - NO UNDO (50% refund)'),

        // Close Button
        React.createElement('button', {
          style: styles.actionButton,
          onClick: onClose
        }, 'Close')
      )
    )
  );
}

const styles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.7)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 9999
  },
  modal: {
    backgroundColor: COLORS.PANEL_BG,
    border: `2px solid ${COLORS.BORDER}`,
    borderRadius: BORDER_RADIUS.LARGE,
    padding: SPACING.LARGE,
    minWidth: '400px',
    maxWidth: '500px',
    maxHeight: '80vh',
    overflow: 'auto',
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.5)'
  },
  header: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: SPACING.MEDIUM,
    paddingBottom: SPACING.SMALL,
    borderBottom: `1px solid ${COLORS.BORDER}`
  },
  title: {
    margin: 0,
    fontSize: FONTS.SIZE_LARGE,
    fontFamily: FONTS.FAMILY_PRIMARY,
    color: COLORS.TEXT_PRIMARY
  },
  closeButton: {
    background: 'none',
    border: 'none',
    color: COLORS.TEXT_SECONDARY,
    fontSize: '24px',
    cursor: 'pointer',
    padding: '0 8px',
    ':hover': {
      color: COLORS.TEXT_PRIMARY
    }
  },
  content: {
    marginBottom: SPACING.MEDIUM
  },
  buildingName: {
    margin: `0 0 ${SPACING.MEDIUM}px 0`,
    fontSize: FONTS.SIZE_MEDIUM,
    fontFamily: FONTS.FAMILY_PRIMARY,
    color: COLORS.ACCENT,
    textAlign: 'center'
  },
  infoGrid: {
    display: 'flex',
    flexDirection: 'column',
    gap: SPACING.SMALL
  },
  infoRow: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: `${SPACING.SMALL}px 0`
  },
  label: {
    fontFamily: FONTS.FAMILY_PRIMARY,
    fontSize: FONTS.SIZE_SMALL,
    color: COLORS.TEXT_SECONDARY,
    fontWeight: 'bold'
  },
  value: {
    fontFamily: FONTS.FAMILY_SECONDARY,
    fontSize: FONTS.SIZE_SMALL,
    color: COLORS.TEXT_PRIMARY
  },
  divider: {
    height: '1px',
    backgroundColor: COLORS.BORDER,
    margin: `${SPACING.SMALL}px 0`
  },
  warningBox: {
    backgroundColor: 'rgba(255, 193, 7, 0.1)',
    border: '2px solid #ffc107',
    borderRadius: BORDER_RADIUS.MEDIUM,
    padding: SPACING.MEDIUM,
    marginTop: SPACING.MEDIUM
  },
  warningHeader: {
    fontFamily: FONTS.FAMILY_PRIMARY,
    fontSize: FONTS.SIZE_MEDIUM,
    fontWeight: 'bold',
    color: '#ffc107',
    marginBottom: SPACING.SMALL,
    textAlign: 'center'
  },
  warningText: {
    fontFamily: FONTS.FAMILY_SECONDARY,
    fontSize: FONTS.SIZE_SMALL,
    color: COLORS.TEXT_PRIMARY,
    marginBottom: SPACING.SMALL,
    textAlign: 'center'
  },
  warningCost: {
    fontFamily: FONTS.FAMILY_PRIMARY,
    fontSize: FONTS.SIZE_MEDIUM,
    fontWeight: 'bold',
    color: '#ffc107',
    textAlign: 'center'
  },
  actions: {
    display: 'flex',
    flexDirection: 'column',
    gap: SPACING.SMALL,
    marginTop: SPACING.MEDIUM
  },
  actionButton: {
    fontFamily: FONTS.FAMILY_PRIMARY,
    fontSize: FONTS.SIZE_SMALL,
    padding: `${SPACING.SMALL}px ${SPACING.MEDIUM}px`,
    backgroundColor: '#2563eb',
    color: '#ffffff',
    border: `2px solid #3b82f6`,
    borderRadius: BORDER_RADIUS.MEDIUM,
    cursor: 'pointer',
    transition: 'all 0.2s',
    textAlign: 'center',
    fontWeight: 'bold'
  },
  repairButton: {
    backgroundColor: '#27ae60',
    borderColor: '#2ecc71'
  },
  demolishButton: {
    backgroundColor: '#c0392b',
    borderColor: '#e74c3c'
  }
};
