/**
 * OptionsModal.js
 * Game options menu - accessible via ESC key
 * Controls: Sound on/off, Game speed (0.5x, 1x, 2x)
 */

import React from 'react';
import { useGameState } from '../../state/StateManager.js';
import { GAME_SPEED } from '../../constants/gameConfig.js';

export function OptionsModal({ onClose, timeManager, musicManager }) {
  const gameState = useGameState();

  const handleSpeedChange = (speed) => {
    gameState.gameSpeed = speed;
    
    // Update TimeManager interval if running
    if (timeManager && timeManager.isRunning) {
      timeManager.updateInterval();
    }
    
    gameState.notifyListeners('settings_changed');
  };

  const handleSoundToggle = () => {
    gameState.soundEnabled = !gameState.soundEnabled;
    
    // Update music playback based on new setting
    if (musicManager) {
      musicManager.updateSoundSettings();
    }
    
    gameState.notifyListeners('settings_changed');
  };

  const getSpeedLabel = (speed) => {
    if (speed === GAME_SPEED.HALF) return 'Half Speed (30s/month)';
    if (speed === GAME_SPEED.NORMAL) return 'Normal Speed (20s/month)';
    if (speed === GAME_SPEED.DOUBLE) return 'Double Speed (10s/month)';
    return 'Unknown';
  };

  return React.createElement('div', { 
    style: styles.overlay,
    onClick: onClose
  },
    React.createElement('div', { 
      style: styles.modal,
      onClick: (e) => e.stopPropagation()
    },
      // Header
      React.createElement('div', { style: styles.header },
        React.createElement('h2', { style: styles.title }, 'Options'),
        React.createElement('button', {
          style: styles.closeButton,
          onClick: onClose
        }, '×')
      ),

      // Content
      React.createElement('div', { style: styles.content },
        // Sound option
        React.createElement('div', { style: styles.section },
          React.createElement('h3', { style: styles.sectionTitle }, 'Sound'),
          React.createElement('button', {
            style: {
              ...styles.button,
              ...(gameState.soundEnabled ? styles.buttonActive : {})
            },
            onClick: handleSoundToggle
          }, gameState.soundEnabled ? '🔊 Sound On' : '🔇 Sound Off')
        ),

        // Game speed option
        React.createElement('div', { style: styles.section },
          React.createElement('h3', { style: styles.sectionTitle }, 'Game Speed'),
          React.createElement('div', { style: styles.buttonGroup },
            // Half speed
            React.createElement('button', {
              style: {
                ...styles.speedButton,
                ...(gameState.gameSpeed === GAME_SPEED.HALF ? styles.speedButtonActive : {})
              },
              onClick: () => handleSpeedChange(GAME_SPEED.HALF)
            }, '🐢 Half Speed'),
            
            // Normal speed
            React.createElement('button', {
              style: {
                ...styles.speedButton,
                ...(gameState.gameSpeed === GAME_SPEED.NORMAL ? styles.speedButtonActive : {})
              },
              onClick: () => handleSpeedChange(GAME_SPEED.NORMAL)
            }, '▶️ Normal'),
            
            // Double speed
            React.createElement('button', {
              style: {
                ...styles.speedButton,
                ...(gameState.gameSpeed === GAME_SPEED.DOUBLE ? styles.speedButtonActive : {})
              },
              onClick: () => handleSpeedChange(GAME_SPEED.DOUBLE)
            }, '⚡ Fast')
          )
        )
      ),

      // Footer
      React.createElement('div', { style: styles.footer },
        React.createElement('button', {
          style: styles.resumeButton,
          onClick: onClose,
          onMouseEnter: (e) => e.target.style.backgroundColor = '#2E7D32',
          onMouseLeave: (e) => e.target.style.backgroundColor = '#4CAF50'
        }, 'Resume Game')
      )
    )
  );
}

const styles = {
  overlay: {
    position: 'fixed',
    top: 0,
    left: 0,
    right: 0,
    bottom: 0,
    backgroundColor: 'rgba(0, 0, 0, 0.85)',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    zIndex: 2000
  },
  modal: {
    backgroundColor: '#1a1a1a',
    borderRadius: '16px',
    width: '90%',
    maxWidth: '600px',
    maxHeight: '80vh',
    overflow: 'auto',
    boxShadow: '0 8px 32px rgba(0, 0, 0, 0.8)',
    border: '2px solid #333'
  },
  header: {
    padding: '24px 32px',
    borderBottom: '2px solid #333',
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  title: {
    margin: 0,
    fontSize: '32px',
    color: '#FFFFFF',
    fontWeight: 'bold'
  },
  closeButton: {
    background: 'none',
    border: 'none',
    fontSize: '36px',
    color: '#888',
    cursor: 'pointer',
    padding: '0',
    width: '40px',
    height: '40px',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    borderRadius: '8px',
    transition: 'all 0.2s'
  },
  content: {
    padding: '32px'
  },
  section: {
    marginBottom: '32px'
  },
  sectionTitle: {
    fontSize: '20px',
    color: '#FFFFFF',
    marginBottom: '16px',
    fontWeight: 'bold'
  },
  button: {
    padding: '16px 32px',
    fontSize: '18px',
    backgroundColor: '#333',
    color: '#FFFFFF',
    border: '2px solid #555',
    borderRadius: '8px',
    cursor: 'pointer',
    transition: 'all 0.2s',
    fontWeight: 'bold'
  },
  buttonActive: {
    backgroundColor: '#4CAF50',
    borderColor: '#4CAF50'
  },
  buttonGroup: {
    display: 'flex',
    gap: '16px',
    flexWrap: 'wrap'
  },
  speedButton: {
    flex: '1',
    minWidth: '140px',
    padding: '20px',
    fontSize: '18px',
    fontWeight: 'bold',
    backgroundColor: '#333',
    color: '#FFFFFF',
    border: '2px solid #555',
    borderRadius: '12px',
    cursor: 'pointer',
    transition: 'all 0.2s'
  },
  speedButtonActive: {
    backgroundColor: '#4CAF50',
    borderColor: '#4CAF50',
    transform: 'scale(1.05)'
  },
  footer: {
    padding: '24px 32px',
    borderTop: '2px solid #333',
    display: 'flex',
    justifyContent: 'center'
  },
  resumeButton: {
    padding: '16px 48px',
    fontSize: '20px',
    backgroundColor: '#4CAF50',
    color: '#FFFFFF',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer',
    fontWeight: 'bold',
    transition: 'all 0.2s'
  }
};
