/**
 * NotificationToast.js
 * Toast notifications for important game events
 */

import React, { useState, useEffect } from 'react';
import { useGameState } from '../../state/StateManager.js';
import { COLORS, SPACING } from '../../constants/uiConstants.js';

export function NotificationToast() {
  const gameState = useGameState();
  const [notifications, setNotifications] = useState([]);

  useEffect(() => {
    let idCounter = 0;

    // REMOVED: Revenue and population notifications (no longer showing these)
    
    const handleManagerAction = (data) => {
      const messages = {
        'plan-proposed': `📋 ${data.managerName} proposed: ${data.planName}`,
        'plan-approved': `✅ ${data.managerName}'s plan approved`,
        'plan-denied': `❌ ${data.managerName}'s plan denied`,
        'construction-started': `🚧 Construction started: ${data.buildingName}`,
        'construction-complete': `✨ Construction complete: ${data.buildingName}`,
        'manager-fired': `👋 ${data.managerName} has been fired`,
        'manager-raise': `💵 ${data.managerName} received a raise`,
        'manual-save': `💾 Game saved successfully`
      };

      if (messages[data.action]) {
        addNotification(messages[data.action], data.action === 'manual-save' ? 'success' : 'info');
      }
    };

    const addNotification = (message, type) => {
      const id = idCounter++;
      const newNotif = { id, message, type };
      
      setNotifications(prev => [...prev, newNotif]);

      // Auto-remove after 5 seconds
      setTimeout(() => {
        setNotifications(prev => prev.filter(n => n.id !== id));
      }, 5000);
    };

    // Listen to game events (removed revenue-calculated and population-updated)
    gameState.on('manager-action', handleManagerAction);

    return () => {
      gameState.off('manager-action', handleManagerAction);
    };
  }, [gameState]);

  if (notifications.length === 0) return null;

  return React.createElement('div', { style: styles.container },
    notifications.map((notif, index) => 
      React.createElement('div', { 
        key: notif.id, 
        style: {
          ...styles.toast,
          ...styles[notif.type],
          bottom: `${20 + (index * 70)}px`
        }
      },
        React.createElement('span', { style: styles.message }, notif.message)
      )
    )
  );
}

const styles = {
  container: {
    position: 'fixed',
    right: SPACING.LARGE,
    bottom: SPACING.LARGE,
    zIndex: 1000,
    pointerEvents: 'none'
  },
  toast: {
    position: 'absolute',
    right: 0,
    padding: `${SPACING.MEDIUM}px ${SPACING.LARGE}px`,
    borderRadius: '8px',
    boxShadow: '0 4px 12px rgba(0, 0, 0, 0.4)',
    fontFamily: '"Arial", sans-serif',
    fontSize: '14px',
    fontWeight: 'bold',
    maxWidth: '300px',
    animation: 'slideIn 0.3s ease-out',
    pointerEvents: 'auto'
  },
  success: {
    backgroundColor: '#2ecc71',
    color: '#ffffff'
  },
  warning: {
    backgroundColor: '#f39c12',
    color: '#ffffff'
  },
  error: {
    backgroundColor: '#e74c3c',
    color: '#ffffff'
  },
  info: {
    backgroundColor: COLORS.PRIMARY,
    color: '#ffffff'
  },
  message: {
    display: 'block'
  }
};
