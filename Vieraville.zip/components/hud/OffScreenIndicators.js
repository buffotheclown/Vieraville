/**
 * OffScreenIndicators.js
 * Shows arrows pointing to managers that are off-screen
 * Each manager gets a unique color and displays their name
 */

import React, { useState, useEffect } from 'react';
import { useGameState } from '../../state/StateManager.js';
import { COLORS } from '../../constants/uiConstants.js';

// Unique colors for each manager
const MANAGER_COLORS = [
  '#FF6B6B', // Red
  '#4ECDC4', // Teal
  '#FFE66D', // Yellow
  '#A8E6CF', // Mint
  '#FF8B94', // Pink
  '#C7CEEA', // Lavender
  '#FFDAC1', // Peach
  '#B4F8C8', // Light Green
];

export function OffScreenIndicators({ camera, managers, hasLeftPanel = false, hasRightPanel = false, hasTopPanel = false }) {
  const [indicators, setIndicators] = useState([]);

  useEffect(() => {
    // FIXED PROBLEM #8: Don't clear immediately - wait for valid data
    if (!camera || !camera.canvas || !managers || !Array.isArray(managers)) {
      return; // Wait for valid data
    }

    // Calculate indicators continuously
    const calculateIndicators = () => {
      const newIndicators = [];

      // FIXED PROBLEM #3: Ensure camera has canvas reference
      if (!camera || !camera.canvas) {
        return;
      }

      // Get viewport bounds in world coordinates
      const viewportBounds = getViewportBounds(camera);

      // Process EVERY manager
      for (let index = 0; index < managers.length; index++) {
        const manager = managers[index];
        
        // FIXED PROBLEM #6: Accept ANY valid position, even far off-map
        if (!manager || !manager.position || 
            typeof manager.position.x !== 'number' || 
            typeof manager.position.y !== 'number') {
          continue;
        }
        
        // Skip managers at initialization position (-1000, -1000)
        if (manager.position.x === -1000 && manager.position.y === -1000) {
          continue;
        }

        // Calculate distance from viewport center for fade effect
        const tileSize = 32;
        const wx = manager.position.x * tileSize;
        const wy = manager.position.y * tileSize;
        const dx = wx - viewportBounds.centerX;
        const dy = wy - viewportBounds.centerY;
        const distanceFromCenter = Math.sqrt(dx * dx + dy * dy);

        // FIXED PROBLEM #10: Check if manager is in viewport with small padding
        const inViewportCore = isInViewport(manager.position.x, manager.position.y, viewportBounds, 50);

        // ALWAYS show arrow if manager is not in viewport core
        // No maximum distance check - arrows work at ANY distance
        if (!inViewportCore) {
          // FIXED PROBLEM #5: Always use opacity 1.0 - no fading
          // Arrows are ALWAYS fully visible when off-screen
          let opacity = 1.0;

          const indicator = calculateIndicator(
            manager.position.x,
            manager.position.y,
            viewportBounds,
            manager.id,
            manager.name || `Manager ${index + 1}`,
            index,
            opacity,
            hasLeftPanel,
            hasRightPanel,
            hasTopPanel
          );
          newIndicators.push(indicator);
        }
      }

      setIndicators(newIndicators);
    };

    // Calculate immediately
    calculateIndicators();

    // Update indicators continuously
    const intervalId = setInterval(calculateIndicators, 100); // 10 times per second

    return () => clearInterval(intervalId);
  }, [camera, managers, hasLeftPanel, hasRightPanel, hasTopPanel]);

  if (indicators.length === 0) {
    return null;
  }

  return React.createElement('div', { style: styles.container },
    indicators.map(indicator =>
      React.createElement('div', {
        key: indicator.managerId,
        style: {
          position: 'absolute',
          left: `${indicator.screenX}px`,
          top: `${indicator.screenY}px`,
          transform: 'translate(-50%, -50%)',
          pointerEvents: 'none',
          display: 'flex',
          flexDirection: 'row',
          alignItems: 'center',
          gap: '12px',
          opacity: indicator.opacity,
          transition: 'opacity 0.3s ease-out',
          zIndex: 1001
        }
      },
        // SVG Arrow pointing toward manager - LARGER AND MORE VISIBLE
        React.createElement('svg', {
          width: 60,
          height: 60,
          style: {
            transform: `rotate(${indicator.rotation}deg)`,
            filter: 'drop-shadow(0 4px 8px rgba(0, 0, 0, 1))'
          }
        },
          React.createElement('polygon', {
            points: '45,30 15,15 15,45',
            fill: indicator.color,
            stroke: '#FFFFFF',
            strokeWidth: 3
          })
        ),
        // Manager name label - LARGER AND MORE VISIBLE
        React.createElement('div', {
          style: {
            padding: '8px 16px',
            backgroundColor: 'rgba(0, 0, 0, 0.95)',
            color: '#FFFFFF',
            fontFamily: '"Arial", sans-serif',
            fontSize: '16px',
            fontWeight: 'bold',
            borderRadius: '8px',
            whiteSpace: 'nowrap',
            border: `3px solid ${indicator.color}`,
            boxShadow: `0 4px 12px rgba(0, 0, 0, 0.8), 0 0 20px ${indicator.color}`,
            textShadow: '0 2px 4px rgba(0, 0, 0, 1)'
          }
        }, indicator.name)
      )
    )
  );
}

/**
 * Get viewport bounds in world (pixel) coordinates
 * Camera uses screen-space translation: ctx.translate(camera.x, camera.y)
 */
function getViewportBounds(camera) {
  const canvas = camera.canvas || { width: window.innerWidth, height: window.innerHeight };
  
  // Calculate visible area in world coordinates
  // In screen space: screen point (sx, sy)
  // To world space: world = (screen - camera) / zoom
  // Top-left corner in world coords
  const worldLeft = (0 - camera.x) / camera.zoom;
  const worldTop = (0 - camera.y) / camera.zoom;
  
  // Bottom-right corner in world coords
  const worldRight = (canvas.width - camera.x) / camera.zoom;
  const worldBottom = (canvas.height - camera.y) / camera.zoom;
  
  // Center of viewport in world coords
  const worldCenterX = (canvas.width / 2 - camera.x) / camera.zoom;
  const worldCenterY = (canvas.height / 2 - camera.y) / camera.zoom;

  return {
    left: worldLeft,
    right: worldRight,
    top: worldTop,
    bottom: worldBottom,
    centerX: worldCenterX,
    centerY: worldCenterY
  };
}

/**
 * Check if a point is within the viewport
 * FIXED PROBLEM #4: Padding should be POSITIVE to shrink viewport check
 * FIXED PROBLEM #7: Use smaller padding (50px) so arrows appear sooner
 * @param {number} padding - Padding to shrink viewport (positive = smaller viewport)
 */
function isInViewport(tileX, tileY, bounds, padding = 50) {
  // Convert tile coordinates to world pixel coordinates
  const tileSize = 32;
  const worldX = tileX * tileSize;
  const worldY = tileY * tileSize;

  // FIXED: Positive padding shrinks the viewport check area
  return worldX >= (bounds.left + padding) && 
         worldX <= (bounds.right - padding) && 
         worldY >= (bounds.top + padding) && 
         worldY <= (bounds.bottom - padding);
}

/**
 * Calculate indicator position and rotation for off-screen entity
 * Respects UI panel boundaries to avoid overlapping with UI elements
 */
function calculateIndicator(entityX, entityY, bounds, managerId, managerName, colorIndex, opacity = 1, hasLeftPanel = false, hasRightPanel = false, hasTopPanel = false) {
  const tileSize = 32;
  const wx = entityX * tileSize;
  const wy = entityY * tileSize;

  // Calculate direction from viewport center to entity
  const dx = wx - bounds.centerX;
  const dy = wy - bounds.centerY;
  
  // Calculate angle (in degrees) - arrow points toward the manager
  const angle = Math.atan2(dy, dx) * (180 / Math.PI);

  // Base margin from screen edges
  const baseMargin = 60;
  
  // UI panel widths/heights (approximate)
  const LEFT_PANEL_WIDTH = 260; // ManagerPanel width
  const RIGHT_PANEL_WIDTH = 280; // DashboardPanel width
  const TOP_PANEL_HEIGHT = 90; // TopHUD height
  
  // Calculate effective margins based on which panels are open
  const leftMargin = hasLeftPanel ? LEFT_PANEL_WIDTH + baseMargin : baseMargin;
  const rightMargin = hasRightPanel ? RIGHT_PANEL_WIDTH + baseMargin : baseMargin;
  const topMargin = hasTopPanel ? TOP_PANEL_HEIGHT + baseMargin : baseMargin;
  const bottomMargin = baseMargin; // No bottom panel
  
  // Get screen dimensions
  const screenWidth = window.innerWidth;
  const screenHeight = window.innerHeight;
  
  // Simple approach: Position on the edge closest to the direction of the manager
  let screenX, screenY;
  
  // Normalize direction
  const distance = Math.sqrt(dx * dx + dy * dy);
  const normDx = dx / distance;
  const normDy = dy / distance;
  
  // Determine primary direction and position on that edge
  if (Math.abs(normDx) > Math.abs(normDy)) {
    // Manager is primarily left or right
    if (normDx > 0) {
      // Manager is to the right -> arrow on right edge
      screenX = screenWidth - rightMargin;
    } else {
      // Manager is to the left -> arrow on left edge
      screenX = leftMargin;
    }
    // Y position interpolates based on vertical component
    // Clamp Y to avoid top panel
    const centerY = (topMargin + (screenHeight - bottomMargin)) / 2;
    const rangeY = (screenHeight - topMargin - bottomMargin) / 3;
    screenY = centerY + (normDy * rangeY);
  } else {
    // Manager is primarily above or below
    if (normDy > 0) {
      // Manager is below -> arrow on bottom edge
      screenY = screenHeight - bottomMargin;
    } else {
      // Manager is above -> arrow on top edge
      screenY = topMargin;
    }
    // X position interpolates based on horizontal component
    // Clamp X to avoid side panels
    const centerX = (leftMargin + (screenWidth - rightMargin)) / 2;
    const rangeX = (screenWidth - leftMargin - rightMargin) / 3;
    screenX = centerX + (normDx * rangeX);
  }
  
  // Clamp to safe zone respecting UI panels
  screenX = Math.max(leftMargin, Math.min(screenWidth - rightMargin, screenX));
  screenY = Math.max(topMargin, Math.min(screenHeight - bottomMargin, screenY));

  const color = MANAGER_COLORS[colorIndex % MANAGER_COLORS.length];

  return {
    managerId,
    screenX,
    screenY,
    rotation: angle,
    name: managerName,
    color,
    opacity
  };
}

const styles = {
  container: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100vw',
    height: '100vh',
    pointerEvents: 'none',
    zIndex: 1000 // Above everything to ensure visibility
  }
};
