/**
 * OffScreenIndicators.js - WITH FULL DEBUG LOGGING
 * Shows arrows pointing to managers that are off-screen
 * Each manager gets a unique color and displays their name
 */

import React, { useState, useEffect } from 'react';
import { useGameState } from '../../state/StateManager.js';
import { COLORS } from '../../constants/uiConstants.js';

// Unique colors for each manager
const MANAGER_COLORS = [
  '#FF6B6B', // Red
  '#4ECDC4', // Teal
  '#FFE66D', // Yellow
  '#A8E6CF', // Mint
  '#FF8B94', // Pink
  '#C7CEEA', // Lavender
  '#FFDAC1', // Peach
  '#B4F8C8', // Light Green
];

export function OffScreenIndicators({ camera, managers }) {
  const [indicators, setIndicators] = useState([]);
  const [debugInfo, setDebugInfo] = useState(null);

  useEffect(() => {
    console.log('🔵 OffScreenIndicators useEffect triggered');
    console.log('🔵 camera:', camera);
    console.log('🔵 managers:', managers);
    
    // FIXED PROBLEM #8: Don't clear immediately - wait for valid data
    if (!camera || !camera.canvas || !managers || !Array.isArray(managers)) {
      console.log('🔴 Missing data - camera:', !!camera, 'canvas:', !!camera?.canvas, 'managers:', !!managers);
      return; // Wait for valid data
    }

    console.log('✅ Valid data - starting calculation');

    // Calculate indicators continuously
    const calculateIndicators = () => {
      const newIndicators = [];

      // FIXED PROBLEM #3: Ensure camera has canvas reference
      if (!camera || !camera.canvas) {
        console.log('🔴 Camera missing during calculation');
        return;
      }

      // Get viewport bounds in world coordinates
      const viewportBounds = getViewportBounds(camera);
      console.log('📐 Viewport bounds:', viewportBounds);

      // Process EVERY manager
      for (let index = 0; index < managers.length; index++) {
        const manager = managers[index];
        console.log(`\n🧑 Manager ${index}:`, manager.name);
        console.log('   Position:', manager.position);
        
        // FIXED PROBLEM #6: Accept ANY valid position, even far off-map
        if (!manager || !manager.position || 
            typeof manager.position.x !== 'number' || 
            typeof manager.position.y !== 'number') {
          console.log('   ❌ Invalid position data');
          continue;
        }
        
        // Skip managers at initialization position (-1000, -1000)
        if (manager.position.x === -1000 && manager.position.y === -1000) {
          console.log('   ⏸️ At initialization position (-1000, -1000)');
          continue;
        }

        console.log('   ✅ Valid position:', manager.position);

        // Calculate distance from viewport center for fade effect
        const tileSize = 32;
        const wx = manager.position.x * tileSize;
        const wy = manager.position.y * tileSize;
        console.log('   World coords:', { wx, wy });
        
        const dx = wx - viewportBounds.centerX;
        const dy = wy - viewportBounds.centerY;
        const distanceFromCenter = Math.sqrt(dx * dx + dy * dy);
        console.log('   Distance from center:', distanceFromCenter);

        // FIXED PROBLEM #10: Check if manager is in viewport with small padding
        const inViewportCore = isInViewport(manager.position.x, manager.position.y, viewportBounds, 50);
        console.log('   In viewport core?', inViewportCore);

        // ALWAYS show arrow if manager is not in viewport core
        // No maximum distance check - arrows work at ANY distance
        if (!inViewportCore) {
          console.log('   🎯 CREATING ARROW for', manager.name);
          
          // FIXED PROBLEM #5: Always use opacity 1.0 - no fading
          // Arrows are ALWAYS fully visible when off-screen
          let opacity = 1.0;

          const indicator = calculateIndicator(
            manager.position.x,
            manager.position.y,
            viewportBounds,
            manager.id,
            manager.name || `Manager ${index + 1}`,
            index,
            opacity
          );
          console.log('   Indicator:', indicator);
          newIndicators.push(indicator);
        } else {
          console.log('   👁️ Manager is in viewport - no arrow');
        }
      }

      console.log('\n📊 TOTAL INDICATORS:', newIndicators.length);
      console.log('📊 Indicators:', newIndicators);
      
      setDebugInfo({
        managersCount: managers.length,
        indicatorsCount: newIndicators.length,
        camera: { x: camera.x, y: camera.y, zoom: camera.zoom },
        viewport: viewportBounds
      });
      
      setIndicators(newIndicators);
    };

    // Calculate immediately
    calculateIndicators();

    // Update indicators continuously
    const intervalId = setInterval(calculateIndicators, 100); // 10 times per second

    return () => clearInterval(intervalId);
  }, [camera, managers]);

  console.log('🎨 RENDERING OffScreenIndicators - indicators.length:', indicators.length);

  if (indicators.length === 0) {
    return React.createElement('div', { 
      style: { 
        position: 'fixed', 
        top: 100, 
        left: 10, 
        zIndex: 1000,
        backgroundColor: 'rgba(0, 0, 0, 0.8)',
        color: 'white',
        padding: '10px',
        fontFamily: 'monospace',
        fontSize: '10px'
      } 
    }, 
      debugInfo ? [
        `Managers: ${debugInfo.managersCount}`,
        `Indicators: ${debugInfo.indicatorsCount}`,
        `Camera: ${Math.round(debugInfo.camera.x)}, ${Math.round(debugInfo.camera.y)}`,
        `Zoom: ${debugInfo.camera.zoom.toFixed(2)}`
      ].join(' | ') : 'Waiting for data...'
    );
  }

  return React.createElement('div', { style: styles.container },
    // Debug panel
    React.createElement('div', { 
      style: { 
        position: 'fixed', 
        top: 100, 
        left: 10, 
        zIndex: 1000,
        backgroundColor: 'rgba(0, 255, 0, 0.8)',
        color: 'black',
        padding: '10px',
        fontFamily: 'monospace',
        fontSize: '12px',
        fontWeight: 'bold'
      } 
    }, `🎯 ARROWS ACTIVE: ${indicators.length}`),
    
    // Arrows
    indicators.map(indicator =>
      React.createElement('div', {
        key: indicator.managerId,
        style: {
          position: 'absolute',
          left: `${indicator.screenX}px`,
          top: `${indicator.screenY}px`,
          transform: 'translate(-50%, -50%)',
          pointerEvents: 'none',
          display: 'flex',
          alignItems: 'center',
          gap: '8px',
          opacity: indicator.opacity,
          transition: 'opacity 0.3s ease-out'
        }
      },
        // SVG Arrow pointing toward manager
        React.createElement('svg', {
          width: 40,
          height: 40,
          style: {
            transform: `rotate(${indicator.rotation}deg)`,
            filter: 'drop-shadow(0 3px 6px rgba(0, 0, 0, 0.8))'
          }
        },
          React.createElement('polygon', {
            points: '30,20 10,10 10,30',
            fill: indicator.color,
            stroke: '#000000',
            strokeWidth: 2
          })
        ),
        // Manager name label
        React.createElement('div', {
          style: {
            padding: '6px 12px',
            backgroundColor: 'rgba(0, 0, 0, 0.9)',
            color: indicator.color,
            fontFamily: '"Arial", sans-serif',
            fontSize: '14px',
            fontWeight: 'bold',
            borderRadius: '6px',
            whiteSpace: 'nowrap',
            border: `2px solid ${indicator.color}`,
            boxShadow: '0 2px 8px rgba(0, 0, 0, 0.5)',
            textShadow: '0 1px 2px rgba(0, 0, 0, 0.8)'
          }
        }, indicator.name)
      )
    )
  );
}

/**
 * Get viewport bounds in world (pixel) coordinates
 * Camera uses screen-space translation: ctx.translate(camera.x, camera.y)
 */
function getViewportBounds(camera) {
  const canvas = camera.canvas || { width: window.innerWidth, height: window.innerHeight };
  
  // Calculate visible area in world coordinates
  // In screen space: screen point (sx, sy)
  // To world space: world = (screen - camera) / zoom
  // Top-left corner in world coords
  const worldLeft = (0 - camera.x) / camera.zoom;
  const worldTop = (0 - camera.y) / camera.zoom;
  
  // Bottom-right corner in world coords
  const worldRight = (canvas.width - camera.x) / camera.zoom;
  const worldBottom = (canvas.height - camera.y) / camera.zoom;
  
  // Center of viewport in world coords
  const worldCenterX = (canvas.width / 2 - camera.x) / camera.zoom;
  const worldCenterY = (canvas.height / 2 - camera.y) / camera.zoom;

  return {
    left: worldLeft,
    right: worldRight,
    top: worldTop,
    bottom: worldBottom,
    centerX: worldCenterX,
    centerY: worldCenterY
  };
}

/**
 * Check if a point is within the viewport
 * FIXED PROBLEM #4: Padding should be POSITIVE to shrink viewport check
 * FIXED PROBLEM #7: Use smaller padding (50px) so arrows appear sooner
 * @param {number} padding - Padding to shrink viewport (positive = smaller viewport)
 */
function isInViewport(tileX, tileY, bounds, padding = 50) {
  // Convert tile coordinates to world pixel coordinates
  const tileSize = 32;
  const worldX = tileX * tileSize;
  const worldY = tileY * tileSize;

  // FIXED: Positive padding shrinks the viewport check area
  return worldX >= (bounds.left + padding) && 
         worldX <= (bounds.right - padding) && 
         worldY >= (bounds.top + padding) && 
         worldY <= (bounds.bottom - padding);
}

/**
 * Calculate indicator position and rotation for off-screen entity
 * SIMPLIFIED: Just clamp to screen edges, always visible
 */
function calculateIndicator(entityX, entityY, bounds, managerId, managerName, colorIndex, opacity = 1) {
  const tileSize = 32;
  const wx = entityX * tileSize;
  const wy = entityY * tileSize;

  // Calculate direction from viewport center to entity
  const dx = wx - bounds.centerX;
  const dy = wy - bounds.centerY;
  
  // Calculate angle (in degrees) - arrow points toward the manager
  const angle = Math.atan2(dy, dx) * (180 / Math.PI);

  // Fixed margin from screen edges
  const margin = 60;
  
  // Get screen dimensions
  const screenWidth = window.innerWidth;
  const screenHeight = window.innerHeight;
  
  // Simple approach: Position on the edge closest to the direction of the manager
  let screenX, screenY;
  
  // Normalize direction
  const distance = Math.sqrt(dx * dx + dy * dy);
  const normDx = dx / distance;
  const normDy = dy / distance;
  
  // Determine primary direction and position on that edge
  if (Math.abs(normDx) > Math.abs(normDy)) {
    // Manager is primarily left or right
    if (normDx > 0) {
      // Manager is to the right -> arrow on right edge
      screenX = screenWidth - margin;
    } else {
      // Manager is to the left -> arrow on left edge
      screenX = margin;
    }
    // Y position interpolates based on vertical component
    screenY = screenHeight / 2 + (normDy * (screenHeight / 3));
  } else {
    // Manager is primarily above or below
    if (normDy > 0) {
      // Manager is below -> arrow on bottom edge
      screenY = screenHeight - margin;
    } else {
      // Manager is above -> arrow on top edge
      screenY = margin;
    }
    // X position interpolates based on horizontal component
    screenX = screenWidth / 2 + (normDx * (screenWidth / 3));
  }
  
  // ALWAYS clamp to safe zone on screen
  screenX = Math.max(margin, Math.min(screenWidth - margin, screenX));
  screenY = Math.max(margin, Math.min(screenHeight - margin, screenY));

  const color = MANAGER_COLORS[colorIndex % MANAGER_COLORS.length];

  return {
    managerId,
    screenX,
    screenY,
    rotation: angle,
    name: managerName,
    color,
    opacity
  };
}

const styles = {
  container: {
    position: 'fixed',
    top: 0,
    left: 0,
    width: '100vw',
    height: '100vh',
    pointerEvents: 'none',
    zIndex: 85 // Below HUD but above game
  }
};
