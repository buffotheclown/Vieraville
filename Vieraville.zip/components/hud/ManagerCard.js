/**
 * ManagerCard.js
 * Individual manager card in the left panel
 */

import React from 'react';
import { COLORS, FONTS, SPACING, BORDER_RADIUS } from '../../constants/uiConstants.js';

export function ManagerCard({ manager, onClick, onToggleAuto }) {
  const hasNewPlan = manager.state === 'proposing';
  const isBuilding = manager.state === 'building';

  const handleCardClick = (e) => {
    // Don't trigger card click if clicking the AUTO button
    if (e.target.closest('.auto-button')) {
      return;
    }
    onClick();
  };

  const handleAutoToggle = (e) => {
    e.stopPropagation(); // Prevent card click
    if (onToggleAuto) {
      onToggleAuto(manager.id);
    }
  };

  return React.createElement('div', {
    style: styles.card,
    onClick: handleCardClick
  },
    // Portrait
    React.createElement('div', { style: styles.portrait },
      React.createElement('span', { style: styles.initials },
        manager.name.split(' ').map(n => n[0]).join('')
      )
    ),

    // Info
    React.createElement('div', { style: styles.info },
      React.createElement('h4', { style: styles.name }, manager.name),
      React.createElement('p', { style: styles.specialty }, manager.specialty),
      
      React.createElement('div', { style: styles.stats },
        React.createElement('span', { style: styles.stat }, `😊 ${manager.happiness}`),
        React.createElement('span', { style: styles.stat }, `⚡ ${manager.efficiency}`)
      ),

      React.createElement('p', { style: styles.status }, `Status: ${manager.status}`)
    ),

    // AUTO toggle button (right side)
    React.createElement('button', {
      className: 'auto-button',
      style: manager.autoApprove ? styles.autoButtonActive : styles.autoButtonInactive,
      onClick: handleAutoToggle,
      title: manager.autoApprove ? 'Auto-approval ON' : 'Auto-approval OFF'
    }, 'AUTO'),

    // New plan notification badge
    hasNewPlan && !manager.autoApprove && React.createElement('div', { style: styles.badge },
      React.createElement('span', { style: styles.badgeText }, '!')
    )
  );
}

const styles = {
  card: {
    backgroundColor: COLORS.MODAL_BG,
    borderRadius: BORDER_RADIUS.MEDIUM,
    padding: SPACING.SMALL,
    marginBottom: SPACING.SMALL,
    display: 'flex',
    gap: SPACING.SMALL,
    cursor: 'pointer',
    border: `2px solid ${COLORS.TEXT_DISABLED}`,
    transition: 'all 0.2s ease',
    position: 'relative'
  },
  portrait: {
    width: '50px',
    height: '50px',
    backgroundColor: COLORS.PRIMARY,
    borderRadius: BORDER_RADIUS.SMALL,
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    flexShrink: 0
  },
  initials: {
    fontFamily: FONTS.FAMILY,
    fontSize: '14px',
    color: COLORS.TEXT_PRIMARY,
    fontWeight: 'bold'
  },
  info: {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    gap: '4px'
  },
  name: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '14px',
    color: COLORS.TEXT_PRIMARY,
    margin: 0,
    fontWeight: 'bold'
  },
  specialty: {
    fontFamily: FONTS.FAMILY,
    fontSize: '8px',
    color: COLORS.ACCENT,
    margin: 0
  },
  stats: {
    display: 'flex',
    gap: SPACING.SMALL,
    fontSize: '12px'
  },
  stat: {
    fontFamily: '"Arial", sans-serif',
    color: COLORS.TEXT_SECONDARY
  },
  status: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '11px',
    color: COLORS.TEXT_SECONDARY,
    margin: 0,
    fontStyle: 'italic'
  },
  badge: {
    position: 'absolute',
    top: '5px',
    right: '5px',
    width: '24px',
    height: '24px',
    backgroundColor: COLORS.ERROR,
    borderRadius: '50%',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    animation: 'pulse 1s infinite'
  },
  badgeText: {
    fontFamily: FONTS.FAMILY,
    fontSize: '14px',
    color: COLORS.TEXT_PRIMARY,
    fontWeight: 'bold'
  },
  autoButtonActive: {
    position: 'absolute',
    top: '8px',
    right: '8px',
    fontFamily: FONTS.FAMILY,
    fontSize: '10px',
    fontWeight: 'bold',
    backgroundColor: COLORS.PRIMARY,
    color: COLORS.TEXT_PRIMARY,
    border: `2px solid ${COLORS.PRIMARY}`,
    borderRadius: BORDER_RADIUS.SMALL,
    padding: '4px 8px',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    zIndex: 10
  },
  autoButtonInactive: {
    position: 'absolute',
    top: '8px',
    right: '8px',
    fontFamily: FONTS.FAMILY,
    fontSize: '10px',
    fontWeight: 'bold',
    backgroundColor: 'transparent',
    color: COLORS.TEXT_DISABLED,
    border: `2px solid ${COLORS.TEXT_DISABLED}`,
    borderRadius: BORDER_RADIUS.SMALL,
    padding: '4px 8px',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    zIndex: 10
  }
};
