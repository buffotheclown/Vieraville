/**
 * ManagerPanel.js
 * Left sidebar showing all active managers
 */

import React, { useState } from 'react';
import { ManagerCard } from './ManagerCard.js';
import { COLORS, FONTS, SPACING, PANEL_SIZES } from '../../constants/uiConstants.js';
import { MANAGER_LIMITS } from '../../constants/gameConfig.js';

export function ManagerPanel({ managers, onManagerClick, onHireClick, onToggleAuto, onExpandedChange }) {
  const [isExpanded, setIsExpanded] = useState(true);

  const handleHireClick = () => {
    console.log('🔵 [ManagerPanel] HIRE BUTTON CLICKED');
    console.log('🔵 [ManagerPanel] Current managers count:', managers.length);
    console.log('🔵 [ManagerPanel] Calling onHireClick callback...');
    onHireClick();
  };

  const toggleExpanded = () => {
    const newExpandedState = !isExpanded;
    setIsExpanded(newExpandedState);
    // Notify parent component of state change
    if (onExpandedChange) {
      onExpandedChange(newExpandedState);
    }
  };

  if (!isExpanded) {
    return React.createElement('div', { style: styles.collapsedContainer },
      React.createElement('button', {
        style: styles.expandButton,
        onClick: toggleExpanded
      }, '▶')
    );
  }

  return React.createElement('div', { style: styles.container },
    React.createElement('div', { style: styles.header },
      React.createElement('h3', { style: styles.title }, `MANAGERS (${managers.length})`),
      React.createElement('button', {
        style: styles.collapseButton,
        onClick: toggleExpanded
      }, '◀')
    ),

    React.createElement('div', { style: styles.managerList },
      managers.map(manager =>
        React.createElement(ManagerCard, {
          key: manager.id,
          manager: manager,
          onClick: () => onManagerClick(manager.id),
          onToggleAuto: onToggleAuto
        })
      )
    ),

    React.createElement('div', { style: styles.footer },
      React.createElement('button', {
        style: styles.hireButton,
        onClick: handleHireClick,
        onMouseEnter: (e) => e.target.style.backgroundColor = '#388E3C',
        onMouseLeave: (e) => e.target.style.backgroundColor = COLORS.PRIMARY
      }, '+ HIRE MANAGER')
    )
  );
}

const styles = {
  container: {
    position: 'absolute',
    top: `${PANEL_SIZES.TOP_HUD_HEIGHT}px`,
    left: 0,
    bottom: 0,
    width: `${PANEL_SIZES.MANAGER_PANEL_WIDTH}px`,
    backgroundColor: COLORS.PANEL_BG,
    borderRight: `2px solid ${COLORS.PRIMARY}`,
    display: 'flex',
    flexDirection: 'column',
    zIndex: 100
  },
  collapsedContainer: {
    position: 'absolute',
    left: 0,
    top: PANEL_SIZES.TOP_HUD_HEIGHT,
    zIndex: 100
  },
  expandButton: {
    backgroundColor: COLORS.PRIMARY,
    color: '#FFFFFF',
    border: 'none',
    padding: `${SPACING.LARGE}px ${SPACING.SMALL}px`,
    cursor: 'pointer',
    fontSize: '18px',
    borderRadius: '0 4px 4px 0',
    fontFamily: FONTS.FAMILY
  },
  header: {
    padding: SPACING.MEDIUM,
    borderBottom: `2px solid ${COLORS.TEXT_DISABLED}`,
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center'
  },
  title: {
    fontFamily: FONTS.FAMILY,
    fontSize: FONTS.SIZE_MEDIUM,
    color: COLORS.TEXT_PRIMARY,
    margin: 0
  },
  collapseButton: {
    backgroundColor: 'transparent',
    color: COLORS.TEXT_SECONDARY,
    border: 'none',
    cursor: 'pointer',
    fontSize: '16px',
    padding: SPACING.SMALL,
    fontFamily: FONTS.FAMILY
  },
  managerList: {
    flex: 1,
    overflowY: 'auto',
    padding: SPACING.SMALL
  },
  footer: {
    padding: SPACING.MEDIUM,
    borderTop: `2px solid ${COLORS.TEXT_DISABLED}`
  },
  hireButton: {
    width: '100%',
    fontFamily: FONTS.FAMILY,
    fontSize: FONTS.SIZE_SMALL,
    backgroundColor: COLORS.PRIMARY,
    color: COLORS.TEXT_PRIMARY,
    border: 'none',
    padding: `${SPACING.MEDIUM}px`,
    cursor: 'pointer',
    borderRadius: '8px',
    transition: 'all 0.3s ease',
    letterSpacing: '1px'
  }
};
