/**
 * DashboardPanel.js
 * Right sidebar showing detailed town statistics
 */

import React, { useState, useEffect } from 'react';
import { useGameState } from '../../state/StateManager.js';
import { COLORS, FONTS, SPACING, PANEL_SIZES } from '../../constants/uiConstants.js';

export function DashboardPanel({ managerCoordinator, onExpandedChange }) {
  const gameState = useGameState();
  const [stats, setStats] = useState({
    revenue: { total: 0, byType: {} },
    population: { total: 0, employed: 0, unemployed: 0 },
    happiness: { overall: 50, breakdown: {} },
    buildings: { byType: {} },
    upkeepCosts: 0,
    managerSalaries: 0
  });
  const [isExpanded, setIsExpanded] = useState(true);

  // Update stats when events fire
  useEffect(() => {
    const updateStats = async () => {
      // Dynamically import managers
      const { RevenueManager } = await import('../../managers/RevenueManager.js');
      const { PopulationManager } = await import('../../managers/PopulationManager.js');

      const revenueManager = new RevenueManager(gameState);
      const populationManager = new PopulationManager(gameState);

      const revenue = revenueManager.estimateMonthlyRevenue();
      const revenueByType = revenueManager.getRevenueByType();
      const upkeepCosts = revenueManager.calculateUpkeepCosts();
      const popStats = populationManager.calculatePopulation();
      const happiness = populationManager.calculateHappiness();
      const happinessBreakdown = populationManager.getHappinessBreakdown();
      const buildingsByType = populationManager.getPopulationByType();

      // Calculate total manager salaries from ManagerCoordinator
      const { MANAGER_SALARY } = await import('../../constants/gameConfig.js');
      const managers = managerCoordinator ? managerCoordinator.getManagersData() : [];
      const totalManagerSalaries = managers.reduce((sum, manager) => {
        const salary = MANAGER_SALARY.BASE_ANNUAL + (manager.raises || 0) * MANAGER_SALARY.RAISE_INCREASE;
        return sum + salary;
      }, 0);

      setStats({
        revenue: { total: revenue, byType: revenueByType },
        population: popStats,
        happiness: { overall: happiness, breakdown: happinessBreakdown },
        buildings: { byType: buildingsByType },
        upkeepCosts: upkeepCosts,
        managerSalaries: totalManagerSalaries
      });
    };

    updateStats();

    gameState.on('month-changed', updateStats);
    gameState.on('revenue-calculated', updateStats);
    gameState.on('population-updated', updateStats);
    gameState.on('building_added', updateStats); // Update when buildings are added
    gameState.on('manager-action', updateStats); // Update when managers get raises

    return () => {
      gameState.off('month-changed', updateStats);
      gameState.off('revenue-calculated', updateStats);
      gameState.off('population-updated', updateStats);
      gameState.off('building_added', updateStats);
      gameState.off('manager-action', updateStats);
    };
  }, [gameState, managerCoordinator]);

  const toggleExpanded = () => {
    const newExpandedState = !isExpanded;
    setIsExpanded(newExpandedState);
    // Notify parent component of state change
    if (onExpandedChange) {
      onExpandedChange(newExpandedState);
    }
  };

  if (!isExpanded) {
    return React.createElement('div', { style: styles.collapsedContainer },
      React.createElement('button', {
        style: styles.expandButton,
        onClick: toggleExpanded
      }, '◀')
    );
  }

  return React.createElement('div', { style: styles.container },
    // Header
    React.createElement('div', { style: styles.header },
      React.createElement('h3', { style: styles.title }, 'DASHBOARD'),
      React.createElement('button', {
        style: styles.collapseButton,
        onClick: toggleExpanded
      }, '▶')
    ),

    // Content
    React.createElement('div', { style: styles.content },
      // Financial Section
      React.createElement('div', { style: styles.section },
        React.createElement('h4', { style: styles.sectionTitle }, '💰 FINANCES'),
        React.createElement('div', { style: styles.statRow },
          React.createElement('span', { style: styles.label }, 'Current Budget:'),
          React.createElement('span', { style: styles.value }, 
            `$${(gameState.budget / 1000000).toFixed(2)}M`
          )
        ),
        React.createElement('div', { style: styles.statRow },
          React.createElement('span', { style: styles.label }, 'Monthly Revenue:'),
          React.createElement('span', { 
            style: { ...styles.value, color: (stats.revenue.total || 0) >= 0 ? '#2ecc71' : '#e74c3c' }
          }, 
            `$${((stats.revenue.total || 0) / 1000).toFixed(1)}K`
          )
        ),
        React.createElement('div', { style: styles.statRow },
          React.createElement('span', { style: styles.label }, 'Tax Rate:'),
          React.createElement('span', { 
            style: { ...styles.value, color: '#e67e22' }
          }, 
            `${(gameState.taxRate * 100).toFixed(0)}%`
          )
        ),
        React.createElement('div', { style: styles.statRow },
          React.createElement('span', { style: styles.label }, 'Upkeep (Unstaffed):'),
          React.createElement('span', { 
            style: { ...styles.value, color: stats.upkeepCosts > 0 ? '#e74c3c' : COLORS.TEXT_PRIMARY }
          }, 
            `$${((stats.upkeepCosts || 0) / 1000).toFixed(1)}K`
          )
        ),
        React.createElement('div', { style: styles.statRow },
          React.createElement('span', { style: styles.label }, 'Manager Salaries:'),
          React.createElement('span', { 
            style: { ...styles.value, color: '#f39c12' }
          }, 
            `$${((stats.managerSalaries || 0) / 1000).toFixed(1)}K/year`
          )
        ),
        
        // Revenue by type
        stats.revenue.byType && Object.keys(stats.revenue.byType).length > 0 && 
          React.createElement('div', { style: styles.breakdown },
            React.createElement('span', { style: styles.breakdownTitle }, 'By Type:'),
            ...Object.entries(stats.revenue.byType).map(([type, amount]) =>
              React.createElement('div', { 
                key: type, 
                style: styles.breakdownRow 
              },
                React.createElement('span', { style: styles.breakdownLabel }, 
                  type.charAt(0).toUpperCase() + type.slice(1) + ':'
                ),
                React.createElement('span', { style: styles.breakdownValue }, 
                  `$${(amount / 1000).toFixed(1)}K`
                )
              )
            )
          )
      ),

      // Population Section
      React.createElement('div', { style: styles.section },
        React.createElement('h4', { style: styles.sectionTitle }, '👥 POPULATION'),
        React.createElement('div', { style: styles.statRow },
          React.createElement('span', { style: styles.label }, 'Total:'),
          React.createElement('span', { style: styles.value }, 
            stats.population.total.toLocaleString()
          )
        ),
        React.createElement('div', { style: styles.statRow },
          React.createElement('span', { style: styles.label }, 'Employed:'),
          React.createElement('span', { style: styles.value }, 
            `${(stats.population.employed || 0).toLocaleString()} (${Math.round((stats.population.employmentRate || 0) * 100)}%)`
          )
        ),
        React.createElement('div', { style: styles.statRow },
          React.createElement('span', { style: styles.label }, 'Unemployed:'),
          React.createElement('span', { 
            style: { ...styles.value, color: (stats.population.unemployed || 0) > 0 ? '#f39c12' : COLORS.TEXT_PRIMARY }
          }, 
            (stats.population.unemployed || 0).toLocaleString()
          )
        ),
        React.createElement('div', { style: styles.statRow },
          React.createElement('span', { style: styles.label }, 'Available Jobs:'),
          React.createElement('span', { style: styles.value }, 
            (stats.population.jobs || 0).toLocaleString()
          )
        )
      ),

      // Happiness Section
      React.createElement('div', { style: styles.section },
        React.createElement('h4', { style: styles.sectionTitle }, '😊 HAPPINESS'),
        React.createElement('div', { style: styles.statRow },
          React.createElement('span', { style: styles.label }, 'Overall:'),
          React.createElement('span', { style: styles.value }, 
            `${stats.happiness.overall || 50}%`
          )
        ),
        
        // Happiness bar
        React.createElement('div', { style: styles.progressBarContainer },
          React.createElement('div', { 
            style: {
              ...styles.progressBarFill,
              width: `${stats.happiness.overall || 50}%`,
              backgroundColor: getHappinessColor(stats.happiness.overall || 50)
            }
          })
        ),

        // Happiness breakdown
        stats.happiness.breakdown && Object.keys(stats.happiness.breakdown).length > 0 &&
          React.createElement('div', { style: styles.breakdown },
            React.createElement('span', { style: styles.breakdownTitle }, 'Factors:'),
            Object.entries(stats.happiness.breakdown).map(([key, value]) => {
              if (key === 'overall') return null;
              return React.createElement('div', { 
                key: key, 
                style: styles.breakdownRow 
              },
                React.createElement('span', { style: styles.breakdownLabel }, 
                  key.charAt(0).toUpperCase() + key.slice(1) + ':'
                ),
                React.createElement('span', { style: styles.breakdownValue }, 
                  `${value}%`
                )
              );
            }).filter(Boolean)
          )
      ),

      // Buildings Section
      React.createElement('div', { style: styles.section },
        React.createElement('h4', { style: styles.sectionTitle }, '🏗️ BUILDINGS'),
        !stats.buildings.byType || Object.keys(stats.buildings.byType).length === 0 
          ? React.createElement('div', { style: styles.emptyState }, 'No buildings yet')
          : Object.entries(stats.buildings.byType).map(([type, data]) =>
              React.createElement('div', { 
                key: type, 
                style: styles.buildingRow 
              },
                React.createElement('div', { style: styles.buildingType },
                  type.charAt(0).toUpperCase() + type.slice(1)
                ),
                React.createElement('div', { style: styles.buildingStats },
                  React.createElement('span', { style: styles.buildingStat }, 
                    `${data.count} buildings`
                  ),
                  data.population > 0 && React.createElement('span', { style: styles.buildingStat }, 
                    `${data.population} residents`
                  ),
                  data.jobs > 0 && React.createElement('span', { style: styles.buildingStat }, 
                    `${data.jobs} jobs`
                  )
                )
              )
            )
      )
    )
  );
}

function getHappinessColor(happiness) {
  if (happiness >= 80) return '#2ecc71'; // Green
  if (happiness >= 60) return '#3498db'; // Blue
  if (happiness >= 40) return '#f39c12'; // Orange
  if (happiness >= 20) return '#e67e22'; // Dark orange
  return '#e74c3c'; // Red
}

const styles = {
  container: {
    position: 'absolute',
    right: 0,
    top: PANEL_SIZES.TOP_HUD_HEIGHT,
    bottom: 0,
    width: `${PANEL_SIZES.DASHBOARD_PANEL_WIDTH}px`,
    backgroundColor: COLORS.PANEL_BG,
    borderLeft: `3px solid ${COLORS.PRIMARY}`,
    overflowY: 'auto',
    zIndex: 90,
    display: 'flex',
    flexDirection: 'column'
  },
  collapsedContainer: {
    position: 'absolute',
    right: 0,
    top: PANEL_SIZES.TOP_HUD_HEIGHT,
    zIndex: 90
  },
  expandButton: {
    backgroundColor: COLORS.PRIMARY,
    color: '#FFFFFF',
    border: 'none',
    padding: `${SPACING.LARGE}px ${SPACING.SMALL}px`,
    cursor: 'pointer',
    fontSize: '18px',
    borderRadius: '4px 0 0 4px',
    fontFamily: FONTS.FAMILY
  },
  header: {
    padding: SPACING.MEDIUM,
    borderBottom: `2px solid ${COLORS.SECONDARY}`,
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    flexShrink: 0
  },
  title: {
    fontFamily: FONTS.FAMILY,
    fontSize: FONTS.SIZE_MEDIUM,
    color: COLORS.PRIMARY,
    margin: 0,
    letterSpacing: '1px'
  },
  collapseButton: {
    backgroundColor: 'transparent',
    color: COLORS.TEXT_SECONDARY,
    border: 'none',
    cursor: 'pointer',
    fontSize: '16px',
    padding: SPACING.SMALL,
    fontFamily: FONTS.FAMILY
  },
  content: {
    padding: SPACING.MEDIUM,
    overflowY: 'auto',
    flex: 1
  },
  section: {
    marginBottom: SPACING.LARGE,
    padding: SPACING.MEDIUM,
    backgroundColor: COLORS.MODAL_BG,
    borderRadius: '8px'
  },
  sectionTitle: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '14px',
    color: COLORS.PRIMARY,
    margin: `0 0 ${SPACING.MEDIUM}px 0`,
    fontWeight: 'bold',
    letterSpacing: '0.5px'
  },
  statRow: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: SPACING.SMALL,
    fontSize: '13px'
  },
  label: {
    color: COLORS.TEXT_SECONDARY,
    fontFamily: '"Arial", sans-serif'
  },
  value: {
    color: COLORS.TEXT_PRIMARY,
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold'
  },
  breakdown: {
    marginTop: SPACING.MEDIUM,
    paddingTop: SPACING.SMALL,
    borderTop: `1px solid ${COLORS.SECONDARY}`
  },
  breakdownTitle: {
    fontSize: '11px',
    color: COLORS.TEXT_SECONDARY,
    fontFamily: '"Arial", sans-serif',
    display: 'block',
    marginBottom: SPACING.SMALL
  },
  breakdownRow: {
    display: 'flex',
    justifyContent: 'space-between',
    marginBottom: '4px',
    fontSize: '12px',
    paddingLeft: SPACING.SMALL
  },
  breakdownLabel: {
    color: COLORS.TEXT_SECONDARY,
    fontFamily: '"Arial", sans-serif',
    fontSize: '11px'
  },
  breakdownValue: {
    color: COLORS.TEXT_PRIMARY,
    fontFamily: '"Arial", sans-serif',
    fontSize: '11px'
  },
  progressBarContainer: {
    width: '100%',
    height: '8px',
    backgroundColor: COLORS.SECONDARY,
    borderRadius: '4px',
    overflow: 'hidden',
    marginTop: SPACING.SMALL
  },
  progressBarFill: {
    height: '100%',
    transition: 'width 0.3s ease, background-color 0.3s ease'
  },
  buildingRow: {
    marginBottom: SPACING.MEDIUM,
    paddingBottom: SPACING.SMALL,
    borderBottom: `1px solid ${COLORS.SECONDARY}`
  },
  buildingType: {
    fontSize: '13px',
    color: COLORS.TEXT_PRIMARY,
    fontFamily: '"Arial", sans-serif',
    fontWeight: 'bold',
    marginBottom: '4px'
  },
  buildingStats: {
    display: 'flex',
    flexDirection: 'column',
    gap: '2px'
  },
  buildingStat: {
    fontSize: '11px',
    color: COLORS.TEXT_SECONDARY,
    fontFamily: '"Arial", sans-serif'
  },
  emptyState: {
    fontSize: '12px',
    color: COLORS.TEXT_SECONDARY,
    fontFamily: '"Arial", sans-serif',
    fontStyle: 'italic',
    textAlign: 'center',
    padding: SPACING.MEDIUM
  }
};
