/**
 * TopHUD.js
 * Top bar showing budget, date, population, and happiness
 */

import React, { useState, useEffect } from 'react';
import { useGameState } from '../../state/StateManager.js';
import { COLORS, FONTS, SPACING, PANEL_SIZES } from '../../constants/uiConstants.js';

export function TopHUD() {
  const gameState = useGameState();
  const [, forceUpdate] = useState({});

  // Listen for state changes to update UI
  useEffect(() => {
    const handleUpdate = () => {
      forceUpdate({});
    };

    gameState.on('month-changed', handleUpdate);
    gameState.on('revenue-calculated', handleUpdate);
    gameState.on('population-updated', handleUpdate);
    gameState.on('building_added', handleUpdate); // Update when buildings are added

    return () => {
      gameState.off('month-changed', handleUpdate);
      gameState.off('revenue-calculated', handleUpdate);
      gameState.off('population-updated', handleUpdate);
      gameState.off('building_added', handleUpdate);
    };
  }, [gameState]);

  return React.createElement('div', { style: styles.container },
    // Left section - Logo
    React.createElement('div', { style: styles.leftSection },
      React.createElement('h1', { style: styles.logo }, 'VIERAVILLE')
    ),

    // Center section - Date (will be truly centered)
    React.createElement('div', { style: styles.centerSection },
      React.createElement('div', { style: styles.dateContainer },
        React.createElement('span', { style: styles.dateLabel }, 
          `Year ${gameState.year} • ${gameState.getCurrentSeason()} • ${gameState.getCurrentMonth()}`
        )
      )
    ),
    
    // Right section - Empty spacer for balance
    React.createElement('div', { style: styles.rightSection })
  );
}

const styles = {
  container: {
    position: 'absolute',
    top: 0,
    left: 0,
    right: 0,
    height: `${PANEL_SIZES.TOP_HUD_HEIGHT}px`,
    backgroundColor: COLORS.PANEL_BG,
    borderBottom: `3px solid ${COLORS.PRIMARY}`,
    display: 'grid',
    gridTemplateColumns: '1fr auto 1fr', // Three columns: left, center (auto-width), right
    alignItems: 'center',
    padding: `0 ${SPACING.LARGE}px`,
    zIndex: 100
  },
  leftSection: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-start'
  },
  centerSection: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center'
  },
  rightSection: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'flex-end'
  },
  logo: {
    fontFamily: FONTS.FAMILY,
    fontSize: FONTS.SIZE_LARGE,
    color: COLORS.PRIMARY,
    margin: 0,
    letterSpacing: '2px'
  },
  dateContainer: {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center'
  },
  dateLabel: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '16px',
    color: COLORS.TEXT_PRIMARY,
    fontWeight: 'bold'
  },
  statsSection: {
    display: 'flex',
    gap: `${SPACING.LARGE}px`,
    alignItems: 'center'
  },
  stat: {
    display: 'flex',
    alignItems: 'center',
    gap: `${SPACING.SMALL}px`,
    backgroundColor: COLORS.MODAL_BG,
    padding: `${SPACING.SMALL}px ${SPACING.MEDIUM}px`,
    borderRadius: '8px'
  },
  statIcon: {
    fontSize: '24px'
  },
  statValue: {
    fontFamily: '"Arial", sans-serif',
    fontSize: '16px',
    color: COLORS.TEXT_PRIMARY,
    fontWeight: 'bold'
  },
  soundButton: {
    backgroundColor: COLORS.MODAL_BG,
    border: `2px solid ${COLORS.PRIMARY}`,
    borderRadius: '8px',
    padding: `${SPACING.SMALL}px ${SPACING.MEDIUM}px`,
    fontSize: '24px',
    cursor: 'pointer',
    transition: 'all 0.2s ease',
    ':hover': {
      backgroundColor: COLORS.PRIMARY,
      transform: 'scale(1.05)'
    },
    ':active': {
      transform: 'scale(0.95)'
    }
  }
};
