/**
 * TiledLoader.js
 * Loads and parses Tiled JSON map data
 */

import { GRID } from '../constants/gameConfig.js';

export class TiledLoader {
  /**
   * Load Tiled map from URL
   */
  static async loadMap(mapUrl) {
    try {
      const response = await fetch(mapUrl);
      const mapData = await response.json();
      
      return this.parseMapData(mapData);
    } catch (error) {
      console.error('Failed to load Tiled map:', error);
      return null;
    }
  }

  /**
   * Parse Tiled map data
   */
  static parseMapData(mapData) {
    // Parse tilesets first to get tile properties
    const tileProperties = this.parseTilesets(mapData.tilesets || []);
    
    const parsed = {
      width: mapData.width,
      height: mapData.height,
      tilewidth: mapData.tilewidth,
      tileheight: mapData.tileheight,
      layers: {},
      tilesets: mapData.tilesets || [],
      tileProperties: tileProperties, // Map of tileId -> custom properties
      properties: this.parseProperties(mapData.properties)
    };

    // Parse each layer
    for (const layer of mapData.layers) {
      if (layer.type === 'tilelayer') {
        parsed.layers[layer.name] = this.parseTileLayer(layer, mapData.width, mapData.height, tileProperties);
      }
    }

    return parsed;
  }

  /**
   * Parse a tile layer
   */
  static parseTileLayer(layer, width, height, tileProperties) {
    const grid = [];
    
    for (let y = 0; y < height; y++) {
      const row = [];
      for (let x = 0; x < width; x++) {
        const index = y * width + x;
        const tileId = layer.data[index];
        
        // Get custom properties for this tile from tileset
        const customProps = tileProperties[tileId] || {};
        
        row.push({
          tileId: tileId,
          x: x,
          y: y,
          properties: customProps // Include custom properties from tileset
        });
      }
      grid.push(row);
    }

    return {
      name: layer.name,
      visible: layer.visible !== false,
      opacity: layer.opacity || 1.0,
      grid: grid,
      properties: this.parseProperties(layer.properties)
    };
  }

  /**
   * Parse tilesets and extract tile properties
   * Returns a map of tileId -> custom properties
   */
  static parseTilesets(tilesets) {
    const tilePropsMap = {};
    
    for (const tileset of tilesets) {
      const firstGid = tileset.firstgid || 1;
      
      if (tileset.tiles) {
        for (const tile of tileset.tiles) {
          const globalTileId = firstGid + tile.id;
          const props = this.parseProperties(tile.properties);
          tilePropsMap[globalTileId] = props;
        }
      }
    }
    
    return tilePropsMap;
  }

  /**
   * Parse custom properties
   */
  static parseProperties(properties) {
    if (!properties) return {};
    
    const parsed = {};
    for (const prop of properties) {
      parsed[prop.name] = prop.value;
    }
    return parsed;
  }

  /**
   * Load tileset image
   */
  static async loadTileset(imageUrl) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = () => resolve(img);
      img.onerror = (error) => {
        console.error('Failed to load tileset:', error);
        reject(error);
      };
      img.src = imageUrl;
    });
  }
}
