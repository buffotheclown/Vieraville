/**
 * RoadBuilder.js
 * Snake-head pathfinding for road construction
 * Builds roads from entry points toward center of map
 */

import { getNeighbors4, isValidTile } from '../utils/GridUtils.js';

export class RoadBuilder {
  /**
   * Generate a road path from entry point
   * Returns array of tile coordinates for the road
   * Prefers straight roads, heavily penalizes turns and backtracking
   * 
   * @param {Object} entryPoint - Starting position {x, y}
   * @param {number} targetLength - Desired road length
   * @param {Object} gridManager - GridManager instance
   * @param {boolean} hasReachedCenter - Whether manager has reached center (changes pathfinding behavior)
   * @param {Object} buildPreferences - Manager's building type preferences for zone-seeking
   */
  static generateRoadPath(entryPoint, targetLength, gridManager, hasReachedCenter = false, buildPreferences = null) {
    
    const path = [];
    let current = { ...entryPoint };
    let currentDirection = null; // Track which direction we're going
    
    // Calculate target direction (toward center of map)
    const mapCenterX = 50;
    const mapCenterY = 50;
    
    let attempts = 0;
    const maxAttempts = targetLength * 3;
    
    // Check if starting point is buildable OR is an existing road
    const isStartBuildable = gridManager.isBuildable(entryPoint.x, entryPoint.y);
    const isStartRoad = gridManager.getRoadAt(entryPoint.x, entryPoint.y);
    
    if (!isStartBuildable && !isStartRoad) {
      console.warn(`Starting point (${entryPoint.x}, ${entryPoint.y}) is not buildable and has no road`);
      return [];
    }
    
    while (path.length < targetLength && attempts < maxAttempts) {
      attempts++;
      
      // Add current position to path
      if (!path.some(p => p.x === current.x && p.y === current.y)) {
        path.push({ ...current });
      }
      
      if (path.length >= targetLength) break;
      
      // Get valid neighbors
      const neighbors = this.getValidRoadNeighbors(current.x, current.y, gridManager, path);
      
      if (neighbors.length === 0) {
        break;
      }
      
      // Score neighbors based on multiple factors
      const scoredNeighbors = neighbors.map(n => {
        let score = 0;
        
        // Calculate direction of this move
        const dx = n.x - current.x;
        const dy = n.y - current.y;
        const direction = `${dx},${dy}`;
        
        // Prefer continuing in same direction for straighter roads
        if (currentDirection === direction) {
          score += 20; // Moderate bonus for straight continuation
        } else if (currentDirection !== null) {
          score -= 10; // Small penalty for turning
        }
        
        // Prevent backtracking
        if (path.length >= 2) {
          const prev = path[path.length - 1];
          const prevPrev = path[path.length - 2];
          const recentDx = prev.x - prevPrev.x;
          const recentDy = prev.y - prevPrev.y;
          
          if (dx === -recentDx && dy === -recentDy) {
            score -= 500; // Massive penalty for backtracking
          }
        }
        
        // CRITICAL: Prevent two consecutive turns (eliminates U-turns and parallel road issues)
        if (path.length >= 3) {
          const prev = path[path.length - 1];
          const prevPrev = path[path.length - 2];
          const prevPrevPrev = path[path.length - 3];
          
          // Get last two directions
          const lastDx = prev.x - prevPrev.x;
          const lastDy = prev.y - prevPrev.y;
          const beforeLastDx = prevPrev.x - prevPrevPrev.x;
          const beforeLastDy = prevPrevPrev.y - prevPrevPrev.y;
          
          // Check if last move was a turn
          const lastWasTurn = (lastDx !== beforeLastDx || lastDy !== beforeLastDy);
          
          // Check if this move would be another turn
          const thisWouldBeTurn = (dx !== lastDx || dy !== lastDy);
          
          // Block two consecutive turns
          if (lastWasTurn && thisWouldBeTurn) {
            score -= 1000; // Massive penalty for consecutive turns
          }
        }
        
        // PATHFINDING BEHAVIOR CHANGES BASED ON CENTER REACHED
        if (!hasReachedCenter) {
          // BEFORE CENTER: Attract toward center (50, 50)
          const currentDistToCenter = Math.sqrt(
            Math.pow(current.x - mapCenterX, 2) + 
            Math.pow(current.y - mapCenterY, 2)
          );
          const nextDistToCenter = Math.sqrt(
            Math.pow(n.x - mapCenterX, 2) + 
            Math.pow(n.y - mapCenterY, 2)
          );
          
          // Reward moves that get closer to center, punish moves away
          if (nextDistToCenter < currentDistToCenter) {
            score += 50; // Big bonus for moving toward center
          } else {
            score -= 30; // Penalty for moving away from center
          }
        } else {
          // AFTER CENTER: Seek preferred zone tiles
          const terrain = gridManager.getTerrainAt(n.x, n.y);
          if (terrain && terrain.zone_preference && buildPreferences) {
            // Check if this tile matches any of the manager's preferences
            const zones = terrain.zone_preference.split(',').map(z => z.trim());
            let zoneBonus = 0;
            
            for (const zone of zones) {
              const preference = buildPreferences[zone] || 0;
              if (preference > 0) {
                zoneBonus += preference * 100; // Convert 0.0-1.0 to 0-100 score
              }
            }
            
            score += zoneBonus; // Bonus for moving toward preferred zones
          }
        }
        
        // Small randomness to avoid getting stuck
        score += Math.random() * 2;
        
        return { ...n, score, direction };
      });
      
      // Sort by score (higher is better)
      scoredNeighbors.sort((a, b) => b.score - a.score);
      
      // Pick best neighbor
      const next = scoredNeighbors[0];
      current = next;
      currentDirection = next.direction;
    }
    
    return path;
  }

  /**
   * Get valid neighbors for road building
   * Roads can be built on any buildable terrain (mixed zones)
   * Can connect directly to existing roads for network joining
   */
  static getValidRoadNeighbors(x, y, gridManager, existingPath) {
    const neighbors = getNeighbors4(x, y);
    
    return neighbors.filter(n => {
      // Check if already in path
      if (existingPath.some(p => p.x === n.x && p.y === n.y)) {
        return false;
      }
      
      // Check if there's an existing road at this position
      const existingRoad = gridManager.getRoadAt(n.x, n.y);
      
      // ALLOW connecting directly to an existing road (for network joining)
      if (existingRoad && existingRoad.is_road) {
        return true;
      }
      
      // Check if buildable (no existing road/building, terrain is buildable)
      if (!gridManager.isBuildable(n.x, n.y)) {
        return false;
      }
      
      return true;
    });
  }

  /**
   * Find building positions along road
   * Places INDIVIDUAL tiles in 2 ROWS perpendicular to road direction
   * buildingSize is structure_size (tiles per structure)
   * buildingCount is how many structures the plan wants
   * 
   * WORKS FOR ALL BUILDING TYPES: residential, commercial, industrial, amenity, agricultural
   */
  static findBuildingPositions(roadPath, buildingSize, buildingCount, gridManager) {
    
    const positions = [];
    
    // buildingSize = structure_size from TMJ (e.g., 4, 16, 36)
    // buildingCount = number of structures in plan (e.g., 2-4)
    // TOTAL tiles to place = buildingSize * buildingCount
    const totalTilesToPlace = buildingSize * buildingCount;
    
    console.log(`🏢 findBuildingPositions: Need ${totalTilesToPlace} tiles (${buildingCount} structures × ${buildingSize} tiles each)`);
    
    // Skip only first 3 road tiles (too close to entry)
    const startIndex = 3;
    
    // Find ALL suitable perpendicular directions along the road
    // We'll use any valid direction we find as we go
    let tilesPlaced = 0;
    
    // Iterate along the road and place buildings continuously on both sides
    for (let i = startIndex; i < roadPath.length && tilesPlaced < totalTilesToPlace; i++) {
      const roadTile = roadPath[i];
      
      // Try all perpendicular directions at this road tile - PRIORITIZE INTERIOR (away from edges)
      const offsets = [
        { dx: 1, dy: 0 },   // Right
        { dx: -1, dy: 0 },  // Left
        { dx: 0, dy: 1 },   // Down
        { dx: 0, dy: -1 }   // Up
      ];
      
      // Sort to try interior directions first
      offsets.sort((a, b) => {
        const testXa = roadTile.x + a.dx;
        const testYa = roadTile.y + a.dy;
        const testXb = roadTile.x + b.dx;
        const testYb = roadTile.y + b.dy;
        
        // Distance from edges for this test position
        const edgeDistA = Math.min(testXa, 99 - testXa, testYa, 99 - testYa);
        const edgeDistB = Math.min(testXb, 99 - testXb, testYb, 99 - testYb);
        
        // Prefer directions with MORE distance from edges
        return edgeDistB - edgeDistA;
      });
      
      // Try both rows (1 and 2) in each valid direction
      for (const offset of offsets) {
        if (tilesPlaced >= totalTilesToPlace) break;
        
        // Try row 1 and row 2
        for (let row = 1; row <= 2 && tilesPlaced < totalTilesToPlace; row++) {
          const tileX = roadTile.x + offset.dx * row;
          const tileY = roadTile.y + offset.dy * row;
          
          // Check if position is valid
          if (tileX >= 0 && tileY >= 0 && tileX < 100 && tileY < 100) {
            // Check if this position is in the roadPath (not yet placed but planned)
            const isOnRoad = roadPath.some(r => r.x === tileX && r.y === tileY);
            
            // Check if we already placed a tile here
            const alreadyPlaced = positions.some(p => p.x === tileX && p.y === tileY);
            
            if (!isOnRoad && !alreadyPlaced && gridManager.canPlaceBuilding(tileX, tileY)) {
              positions.push({
                x: tileX,
                y: tileY,
                roadConnectionX: roadTile.x,
                roadConnectionY: roadTile.y,
                row: row
              });
              tilesPlaced++;
              
              // Once we place a tile in this direction, continue along the road in the SAME direction
              break;
            }
          }
        }
      }
    }
    
    console.log(`✓ findBuildingPositions: Placed ${positions.length} / ${totalTilesToPlace} tiles`);
    
    return positions;
  }

  /**
   * Check if building can be placed at position
   * Building must be within reasonable distance of a road
   * Distance scales with building size: larger buildings can be further from road
   * CRITICAL: Buildings must be fully within map bounds
   */
  static canPlaceBuilding(startX, startY, size, gridManager, roadPath) {
    // Max distance scales with building size:
    // 2x2 = 2 tiles, 3x3 = 3 tiles, 4x4 = 4 tiles, 6x6 = 6 tiles
    const MAX_ROAD_DISTANCE = Math.max(2, size);
    
    // CRITICAL: Check if entire building footprint is within bounds
    // Building extends from startX to startX+size-1, startY to startY+size-1
    if (startX < 0 || startY < 0 || 
        startX + size > 100 || startY + size > 100) {
      return false;
    }
    
    // Check all tiles the building would occupy
    for (let dy = 0; dy < size; dy++) {
      for (let dx = 0; dx < size; dx++) {
        const checkX = startX + dx;
        const checkY = startY + dy;
        
        if (!isValidTile(checkX, checkY)) {
          return false;
        }
        
        if (roadPath.some(p => p.x === checkX && p.y === checkY)) {
          return false;
        }
        
        if (!gridManager.canPlaceBuilding(checkX, checkY)) {
          return false;
        }
        
        const distanceToRoad = this.getDistanceToNearestRoad(checkX, checkY, roadPath);
        if (distanceToRoad > MAX_ROAD_DISTANCE) {
          return false;
        }
      }
    }
    
    return true;
  }
  
  /**
   * Get Manhattan distance from a tile to the nearest road tile
   */
  static getDistanceToNearestRoad(x, y, roadPath) {
    let minDistance = Infinity;
    
    for (const roadTile of roadPath) {
      const distance = Math.abs(x - roadTile.x) + Math.abs(y - roadTile.y);
      if (distance < minDistance) {
        minDistance = distance;
      }
    }
    
    return minDistance;
  }
}
