/**
 * ConstructionEffects.js
 * Manages construction tile display and cloud particle effects during building
 */

export class ConstructionEffects {
  constructor(gameState = null) {
    // Active construction sites: { x, y, startTime, duration, type: 'road'|'building' }
    this.activeConstructions = [];
    
    // Cloud particles: { x, y, radius, opacity, vx, vy, life, maxLife }
    this.particles = [];
    
    // Pop-in animations: { x, y, startTime, duration: 1000ms }
    // Scale animation: 0.8 -> 1.1 -> 1.0 over 1 second
    this.popAnimations = [];
    
    // Reference to game state for game speed
    this.gameState = gameState;
    
    // Construction tile ID from TMJ (building_type "construction")
    this.constructionTileId = 264;
  }

  /**
   * Start construction effect at a tile position
   * @param {number} x - Grid X coordinate
   * @param {number} y - Grid Y coordinate
   * @param {string} type - 'road' or 'building'
   * @param {number} duration - Duration in milliseconds (default 1000ms)
   */
  startConstruction(x, y, type = 'road', duration = 1000) {
    this.activeConstructions.push({
      x,
      y,
      startTime: Date.now(),
      duration,
      type
    });
    
    // Create initial burst of particles
    this.createParticleBurst(x, y);
  }

  /**
   * Create a burst of cloud particles at position
   */
  createParticleBurst(x, y, count = 3) {
    for (let i = 0; i < count; i++) {
      this.particles.push({
        x: x + Math.random() * 0.8 - 0.4, // Spread across tile
        y: y + Math.random() * 0.8 - 0.4,
        radius: Math.random() * 5 + 8, // 8-13 pixels
        opacity: Math.random() * 0.3 + 0.3, // 0.3-0.6
        vx: (Math.random() - 0.5) * 0.02, // Slow drift
        vy: (Math.random() - 0.5) * 0.02 - 0.01, // Slight upward drift
        life: 0,
        maxLife: Math.random() * 1000 + 1500 // 1.5-2.5 seconds
      });
    }
  }

  /**
   * End construction at a specific tile (called when final tile is placed)
   * This ensures construction tile disappears exactly when real tile appears
   * @param {number} x - Grid X coordinate
   * @param {number} y - Grid Y coordinate
   */
  endConstruction(x, y) {
    this.activeConstructions = this.activeConstructions.filter(
      construction => !(construction.x === x && construction.y === y)
    );
  }

  /**
   * Start pop-in animation for a newly built tile
   * @param {number} x - Grid X coordinate
   * @param {number} y - Grid Y coordinate
   */
  startPopAnimation(x, y) {
    // Apply game speed to pop animation duration
    const gameSpeed = this.gameState ? this.gameState.gameSpeed : 1.0;
    const duration = 1000 / gameSpeed; // 0.5x = 2000ms, 1.0x = 1000ms, 2.0x = 500ms
    
    this.popAnimations.push({
      x,
      y,
      startTime: Date.now(),
      duration: duration
    });
  }

  /**
   * Update construction effects and particles
   */
  update(deltaTime) {
    const now = Date.now();
    
    // Update active constructions and generate particles
    this.activeConstructions = this.activeConstructions.filter(construction => {
      const elapsed = now - construction.startTime;
      
      // Generate particles periodically during construction
      if (elapsed % 200 < deltaTime) { // Every ~200ms
        this.createParticleBurst(construction.x, construction.y, 1);
      }
      
      // Remove if duration expired
      return elapsed < construction.duration;
    });
    
    // Update particles
    this.particles = this.particles.filter(particle => {
      particle.life += deltaTime;
      particle.x += particle.vx;
      particle.y += particle.vy;
      
      // Fade out over lifetime
      const lifeRatio = particle.life / particle.maxLife;
      particle.opacity = (1 - lifeRatio) * 0.5; // Fade from 0.5 to 0
      
      // Remove if expired
      return particle.life < particle.maxLife;
    });
    
    // Update pop animations
    this.popAnimations = this.popAnimations.filter(anim => {
      const elapsed = now - anim.startTime;
      return elapsed < anim.duration;
    });
  }

  /**
   * Get active construction sites (for rendering construction tiles)
   */
  getActiveConstructions() {
    return this.activeConstructions;
  }

  /**
   * Get active particles (for rendering)
   */
  getParticles() {
    return this.particles;
  }

  /**
   * Get pop animations with calculated scale
   * Returns: [{ x, y, scale }]
   */
  getPopAnimations() {
    const now = Date.now();
    return this.popAnimations.map(anim => {
      const elapsed = now - anim.startTime;
      const progress = Math.min(1.0, elapsed / anim.duration); // 0 to 1, clamped at 1.0 max
      
      // Scale curve: 0.8 -> 1.1 -> 1.0
      // Use ease-out for smooth animation
      let scale;
      if (progress < 0.3) {
        // First 30%: 0.8 -> 1.1 (fast expansion)
        const t = progress / 0.3;
        scale = 0.8 + (1.1 - 0.8) * easeOut(t);
      } else if (progress < 1.0) {
        // Last 70%: 1.1 -> 1.0 (settle down)
        const t = (progress - 0.3) / 0.7;
        scale = 1.1 - (1.1 - 1.0) * easeOut(t);
      } else {
        // Animation complete - lock at scale 1.0
        scale = 1.0;
      }
      
      return {
        x: anim.x,
        y: anim.y,
        scale: scale
      };
    });
  }

  /**
   * Clear all effects (useful for scene transitions)
   */
  clear() {
    this.activeConstructions = [];
    this.particles = [];
    this.popAnimations = [];
  }

  /**
   * Check if a tile is currently under construction
   */
  isUnderConstruction(x, y) {
    return this.activeConstructions.some(c => c.x === x && c.y === y);
  }
}

/**
 * Ease-out function for smooth animation
 */
function easeOut(t) {
  return 1 - Math.pow(1 - t, 3);
}
