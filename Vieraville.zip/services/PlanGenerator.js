/**
 * PlanGenerator.js
 * Generates construction plans for managers based on their preferences
 * READS ALL BUILDING DATA FROM TMJ TILESET - NO HARDCODED BUILDINGS
 */

import { COSTS } from '../constants/gameConfig.js';

export class PlanGenerator {
  /**
   * Get all building definitions from TMJ tileset custom properties
   */
  static getBuildingsFromTileset(gridManager) {
    const tileProperties = gridManager.tileProperties || {};
    const buildings = [];
    
    for (const [tileId, props] of Object.entries(tileProperties)) {
      // Only include tiles that have building_type property
      if (props.building_type && props.structure_size) {
        buildings.push({
          tileId: parseInt(tileId),
          building_type: props.building_type,
          structure_size: props.structure_size,
          revenue_base: parseInt(props.revenue_base) || 0,
          happiness_effect: parseInt(props.happiness_effect) || 0,
          jobs_available: parseInt(props.jobs_available) || 0,
          population_min: parseInt(props.population_min) || 0,
          population_max: parseInt(props.population_max) || 0,
          building_subtype: props.building_subtype || null
        });
      }
    }
    
    return buildings;
  }

  /**
   * Generate a construction plan for a manager
   * @param {number} tierIndex - 0, 1, or 2 for Tier 1, 2, or 3
   * @param {boolean} forceResidential - Force this plan to be residential (for early game)
   */
  static generatePlan(manager, gameState, gridManager, tierIndex = 0, forceResidential = false) {
    // Get ALL buildings from TMJ tileset
    const allBuildings = this.getBuildingsFromTileset(gridManager);
    
    if (allBuildings.length === 0) {
      console.warn(`No buildings found in TMJ tileset!`);
      return null;
    }

    // EARLY GAME RULE: First 2 years, force residential if requested
    let availableBuildings;
    if (forceResidential) {
      // Only residential buildings
      availableBuildings = allBuildings.filter(building => {
        return building.building_type === 'residential';
      });
      
      if (availableBuildings.length === 0) {
        console.warn(`No residential buildings found in TMJ tileset!`);
        // Fallback to normal logic
        availableBuildings = allBuildings.filter(building => {
          const preference = manager.build_preferences[building.building_type] || 0;
          return preference > 0;
        });
      }
    } else {
      // Normal logic: Filter buildings manager can build based on their preferences
      availableBuildings = allBuildings.filter(building => {
        const preference = manager.build_preferences[building.building_type] || 0;
        return preference > 0;
      });
    }

    if (availableBuildings.length === 0) {
      console.warn(`No buildings available for ${manager.name} based on preferences`);
      return null;
    }

    // Select building type based on weighted preferences (or random if forced residential)
    const selectedBuilding = forceResidential 
      ? availableBuildings[Math.floor(Math.random() * availableBuildings.length)]
      : this.selectWeightedBuilding(availableBuildings, manager.build_preferences);
    
    if (!selectedBuilding) {
      return null;
    }

    // Determine how many to build (2-4 buildings per plan)
    const buildingCount = Math.floor(Math.random() * 3) + 2; // 2-4 buildings

    // Pick plan cost from discrete tier values (no rounding, no calculation)
    // Tier 1: $200K, $300K, $400K, $500K
    // Tier 2: $600K, $700K, $800K
    // Tier 3: $900K, $1.0M, $1.1M, $1.2M, $1.3M, $1.4M, $1.5M
    const tierCosts = [
      [200000, 300000, 400000, 500000],           // Tier 1
      [600000, 700000, 800000],                   // Tier 2
      [900000, 1000000, 1100000, 1200000, 1300000, 1400000, 1500000] // Tier 3
    ];
    
    const tierOptions = tierCosts[tierIndex] || tierCosts[0];
    const planCost = tierOptions[Math.floor(Math.random() * tierOptions.length)];
    
    // Parse structure_size - now a simple integer (not "NxN" format)
    const buildingSize = parseInt(selectedBuilding.structure_size) || 4;
    const buildingName = `${selectedBuilding.building_type} (${selectedBuilding.structure_size} tiles)`;
    
    // ROAD CONTINUATION SYSTEM:
    // If manager has a lastRoadEndpoint, use it as starting point
    // Otherwise, get an unused entry point (first plan only)
    let entryPoint;
    
    if (manager.lastRoadEndpoint) {
      entryPoint = { ...manager.lastRoadEndpoint };
    } else {
      // First plan - get unused entry point and reserve it
      entryPoint = gridManager.getUnusedEntryPoint(manager.originalEntryPoint);
      if (!entryPoint) {
        console.warn('No unused entry points available');
        return null;
      }
    }

    // Calculate expected outcomes FROM TMJ PROPERTIES
    const expectedRevenue = selectedBuilding.revenue_base * buildingCount;
    const expectedPopulation = buildingCount * (selectedBuilding.population_max || 0);
    const expectedJobs = buildingCount * selectedBuilding.jobs_available;
    const expectedHappiness = buildingCount * selectedBuilding.happiness_effect;

    const plan = {
      id: `plan_${Date.now()}_${Math.random()}`,
      managerId: manager.id,
      managerName: manager.name,
      buildingTileId: selectedBuilding.tileId, // TMJ tile ID
      buildingName: buildingName,
      buildingType: selectedBuilding.building_type,
      buildingSize: buildingSize, // Parsed from structure_size
      buildingCount: buildingCount,
      totalCost: planCost,
      entryPoint: entryPoint,
      expectedRevenue: expectedRevenue,
      expectedPopulation: expectedPopulation,
      expectedJobs: expectedJobs,
      expectedHappiness: expectedHappiness,
      tmjBuilding: selectedBuilding, // Store full TMJ building data
      status: 'proposed',
      createdAt: Date.now()
    };

    return plan;
  }

  /**
   * Select a building based on weighted preferences
   */
  static selectWeightedBuilding(buildings, preferences) {
    // Create weighted array
    const weighted = [];
    
    for (const building of buildings) {
      const weight = preferences[building.building_type] || 0;
      const weightCount = Math.floor(weight * 100); // Convert 0.0-1.0 to 0-100
      
      for (let i = 0; i < weightCount; i++) {
        weighted.push(building);
      }
    }

    if (weighted.length === 0) {
      // Fallback to random selection
      return buildings[Math.floor(Math.random() * buildings.length)];
    }

    // Random weighted selection
    return weighted[Math.floor(Math.random() * weighted.length)];
  }
}
