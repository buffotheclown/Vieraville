/**
 * SoundManager.js
 * Manages all game sound effects using uploaded audio files
 * - sound_button.wav: All UI clicks and buttons
 * - sound_positive.wav: Achievements, hires, victories, positive events
 * - sound_negative.wav: Negative events, fires, defeats, errors
 */

export class SoundManager {
  constructor(gameState) {
    this.gameState = gameState;
    this.sounds = {};
    this.initialized = false;
    
    // Audio file URLs
    this.soundFiles = {
      button: 'https://rosebud.ai/assets/sound_button.wav?tc5n',
      positive: 'https://rosebud.ai/assets/sound_positive.wav?rVTr',
      negative: 'https://rosebud.ai/assets/sound_negative.wav?hhKL',
      road: 'https://rosebud.ai/assets/sound_road.wav?5Otw',
      structure: 'https://rosebud.ai/assets/sound_structure.wav?BDUz'
    };
    
    this.loadSounds();
  }

  /**
   * Load all sound files
   */
  async loadSounds() {
    try {
      for (const [key, url] of Object.entries(this.soundFiles)) {
        const audio = new Audio(url);
        audio.preload = 'auto';
        audio.volume = 0.5; // Default volume
        this.sounds[key] = audio;
      }
      this.initialized = true;
      console.log('✅ Sound Manager initialized with 3 sounds');
    } catch (error) {
      console.error('Failed to load sounds:', error);
    }
  }

  /**
   * Check if sound is enabled
   */
  isSoundEnabled() {
    return this.gameState && this.gameState.soundEnabled;
  }

  /**
   * Play a sound effect
   * @param {string} soundType - Type of sound to play
   * @param {number} volumeMultiplier - Optional volume multiplier (0.0 to 1.0)
   */
  play(soundType, volumeMultiplier = 1.0) {
    if (!this.initialized || !this.isSoundEnabled()) {
      return;
    }

    const sound = this.sounds[soundType];
    if (!sound) {
      console.warn(`Sound type not found: ${soundType}`);
      return;
    }

    try {
      // Clone and play to allow overlapping sounds
      const clone = sound.cloneNode();
      clone.volume = sound.volume * volumeMultiplier;
      clone.play().catch(err => {
        // Silently fail if user hasn't interacted yet (browser autoplay policy)
        if (err.name !== 'NotAllowedError') {
          console.warn('Sound play failed:', err);
        }
      });
    } catch (error) {
      console.warn('Error playing sound:', error);
    }
  }

  /**
   * Button click sound - use for ALL UI interactions
   */
  playButton() {
    this.play('button');
  }

  /**
   * Positive sound - achievements, hires, victories, positive events
   */
  playPositive() {
    this.play('positive');
  }

  /**
   * Negative sound - fires, defeats, negative events, errors
   */
  playNegative() {
    this.play('negative');
  }

  /**
   * Road construction sound - when roads are being built
   * @param {number} volumeMultiplier - Optional volume multiplier (0.0 to 1.0)
   */
  playRoad(volumeMultiplier = 1.0) {
    this.play('road', volumeMultiplier);
  }

  /**
   * Structure construction sound - when buildings are being built
   * @param {number} volumeMultiplier - Optional volume multiplier (0.0 to 1.0)
   */
  playStructure(volumeMultiplier = 1.0) {
    this.play('structure', volumeMultiplier);
  }

  /**
   * Set master volume (0.0 to 1.0)
   */
  setVolume(volume) {
    const clampedVolume = Math.max(0, Math.min(1, volume));
    for (const sound of Object.values(this.sounds)) {
      sound.volume = clampedVolume;
    }
  }
}

// Singleton instance
let soundManagerInstance = null;

export function getSoundManager(gameState) {
  if (!soundManagerInstance && gameState) {
    soundManagerInstance = new SoundManager(gameState);
  }
  return soundManagerInstance;
}
