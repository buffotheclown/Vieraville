/**
 * BuildingPlacer.js
 * Places buildings on the grid with proper tile occupation
 * READS ALL BUILDING DATA FROM TMJ - NO HARDCODED BUILDINGS
 */

export class BuildingPlacer {
  /**
   * Place a SINGLE building tile on the grid using TMJ data from plan
   * structure_size is now just a number (total tiles to place), NOT grid dimensions
   * This method places ONE individual tile at the specified position
   */
  static placeBuilding(x, y, plan, managerId, gridManager, gameState) {
    // SAFETY CHECK: Verify tile can actually have a building placed
    if (!gridManager.canPlaceBuilding(x, y)) {
      console.warn(`⚠️ Cannot place building at (${x}, ${y}) - tile not available (may have road or building)`);
      return false;
    }
    
    const tmjBuilding = plan.tmjBuilding;
    if (!tmjBuilding) {
      console.error(`TMJ building data not found in plan!`);
      return false;
    }

    const structureSize = plan.buildingSize; // This is the total tile count, not grid dimensions
    const buildingType = plan.buildingType;
    
    // RANDOMIZE: Pick a random tile matching building_type and structure_size
    const randomTileId = this.findRandomTileForBuildingType(
      buildingType, 
      structureSize, 
      gridManager
    );
    
    if (!randomTileId) {
      console.error(`No tiles found for ${buildingType} with structure_size ${structureSize}`);
      return false;
    }
    
    // Get the properties of the randomly selected tile
    const tileProperties = gridManager.tileProperties[randomTileId];
    if (!tileProperties) {
      console.error(`No properties found for tileId ${randomTileId}`);
      return false;
    }
    
    console.log(`Placing individual ${buildingType} tile using tileId ${randomTileId} (subtype: ${tileProperties.building_subtype || 'none'})`);

    // Create building instance FROM RANDOMLY SELECTED TILE
    // This is a SINGLE TILE, not a grid structure
    const building = {
      building_id: `${buildingType}_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
      building_type: tileProperties.building_type,
      building_subtype: tileProperties.building_subtype || null,
      name: tileProperties.building_subtype 
        ? `${tileProperties.building_subtype}`
        : `${tileProperties.building_type}`,
      revenue_base: parseInt(tileProperties.revenue_base) || 0,
      happiness_effect: parseInt(tileProperties.happiness_effect) || 0,
      population_min: parseInt(tileProperties.population_min) || 0,
      population_max: parseInt(tileProperties.population_max) || 0,
      current_population: parseInt(tileProperties.population_min) || 0,
      jobs_available: parseInt(tileProperties.jobs_available) || 0,
      longevity_year_built: gameState.year,
      owner_manager: managerId,
      is_complete: true,
      startX: x,
      startY: y,
      size: 1, // ALWAYS 1 - single tile
      tileId: randomTileId
    };

    // Place single building tile on grid
    gridManager.placeBuilding(x, y, building);

    // Add to game state
    gameState.addBuilding(building);

    console.log(`✅ Placed ${building.name} at (${x}, ${y})`);
    console.log(`   - Type: ${building.building_type}${building.building_subtype ? ` (${building.building_subtype})` : ''}`);
    console.log(`   - Population: ${building.current_population} (${building.population_min}-${building.population_max})`);
    console.log(`   - Jobs: ${building.jobs_available}`);
    console.log(`   - Revenue: $${building.revenue_base}/month`);
    console.log(`   - Happiness: ${building.happiness_effect > 0 ? '+' : ''}${building.happiness_effect}`);
    return true;
  }

  /**
   * Find a RANDOM tile in the tileset that matches the building type and size
   * Reads from tileset custom properties: building_type, structure_size
   * Returns a random tileId from all matching tiles
   */
  static findRandomTileForBuildingType(buildingType, size, gridManager) {
    const tileProperties = gridManager.tileProperties || {};
    
    // Find all tiles that match this building type and size
    const matchingTiles = [];
    for (const [tileId, props] of Object.entries(tileProperties)) {
      // Parse structure_size - now a simple integer
      const tileSize = parseInt(props.structure_size);
      
      // Match on building_type and size
      if (props.building_type === buildingType && tileSize === size) {
        matchingTiles.push(parseInt(tileId));
      }
    }
    
    if (matchingTiles.length === 0) {
      console.warn(`NO MATCHES FOUND for type=${buildingType}, size=${size} tiles`);
      return null; // No matching tile found
    }
    
    // ALWAYS randomly pick one from ALL matching tiles
    const selectedTile = matchingTiles[Math.floor(Math.random() * matchingTiles.length)];
    return selectedTile;
  }
  
  /**
   * (DEPRECATED - kept for reference)
   * Find a tile in the tileset that matches the building type and size
   * Reads from tileset custom properties: building_type, structure_size
   */
  static findTileForBuildingType(buildingType, size, gridManager) {
    // Just call the random version
    return this.findRandomTileForBuildingType(buildingType, size, gridManager);
  }

  /**
   * Place multiple buildings from a construction plan
   */
  static placeBuildingsFromPlan(plan, roadPath, buildingPositions, gridManager, gameState) {
    const buildingDef = getBuildingById(plan.buildingId);
    if (!buildingDef) {
      console.error(`Building not found: ${plan.buildingId}`);
      return [];
    }

    const placedBuildings = [];

    for (let i = 0; i < buildingPositions.length && i < plan.buildingCount; i++) {
      const pos = buildingPositions[i];
      
      const success = this.placeBuilding(
        pos.x,
        pos.y,
        plan.buildingId,
        plan.managerId,
        gridManager,
        gameState
      );

      if (success) {
        placedBuildings.push({
          x: pos.x,
          y: pos.y,
          buildingId: plan.buildingId
        });
      }
    }

    console.log(`Placed ${placedBuildings.length} buildings for plan`);
    return placedBuildings;
  }
}
