/**
 * MusicManager.js
 * Manages background music playback
 * Plays 4 songs in sequence (song_1 -> song_2 -> song_3 -> song_4) and loops
 */

export class MusicManager {
  constructor(gameState) {
    this.gameState = gameState;
    this.tracks = [
      'https://rosebud.ai/assets/song_1.mp3?uhIW',
      'https://rosebud.ai/assets/song_2.mp3?MSBb',
      'https://rosebud.ai/assets/song_3.mp3?5J7t',
      'https://rosebud.ai/assets/song_4.mp3?e8Zv'
    ];
    this.currentTrackIndex = 0;
    this.audio = null;
    this.isPlaying = false;
    this.initialized = false;
    
    this.initializeAudio();
  }

  /**
   * Initialize audio element
   */
  initializeAudio() {
    try {
      this.audio = new Audio();
      this.audio.volume = 0.3; // Background music at 30% volume
      
      // When a track ends, play the next one
      this.audio.addEventListener('ended', () => {
        this.playNextTrack();
      });
      
      // Handle errors gracefully
      this.audio.addEventListener('error', (e) => {
        console.warn('Music playback error:', e);
        // Try next track on error
        this.playNextTrack();
      });
      
      this.initialized = true;
      console.log('✅ Music Manager initialized with 4 tracks');
    } catch (error) {
      console.error('Failed to initialize music:', error);
    }
  }

  /**
   * Check if sound is enabled
   */
  isSoundEnabled() {
    return this.gameState && this.gameState.soundEnabled;
  }

  /**
   * Start playing music from the first track
   */
  start() {
    if (!this.initialized || this.isPlaying) {
      return;
    }
    
    if (!this.isSoundEnabled()) {
      console.log('🔇 Music disabled by user settings');
      return;
    }
    
    this.currentTrackIndex = 0;
    this.playCurrentTrack();
  }

  /**
   * Play the current track
   */
  playCurrentTrack() {
    if (!this.initialized || !this.audio) {
      return;
    }
    
    if (!this.isSoundEnabled()) {
      this.stop();
      return;
    }
    
    try {
      this.audio.src = this.tracks[this.currentTrackIndex];
      
      // Skip first second of song_2 (track index 1)
      if (this.currentTrackIndex === 1) {
        this.audio.currentTime = 1.0;
      }
      
      this.audio.play().then(() => {
        this.isPlaying = true;
        console.log(`🎵 Now playing: Track ${this.currentTrackIndex + 1}/${this.tracks.length}`);
      }).catch(err => {
        // Silently fail if user hasn't interacted yet (browser autoplay policy)
        if (err.name !== 'NotAllowedError') {
          console.warn('Music play failed:', err);
        } else {
          console.log('🔇 Music autoplay blocked - will start on user interaction');
        }
      });
    } catch (error) {
      console.warn('Error playing track:', error);
    }
  }

  /**
   * Play the next track in sequence
   */
  playNextTrack() {
    this.currentTrackIndex = (this.currentTrackIndex + 1) % this.tracks.length;
    this.playCurrentTrack();
  }

  /**
   * Stop music playback
   */
  stop() {
    if (!this.audio || !this.isPlaying) {
      return;
    }
    
    try {
      this.audio.pause();
      this.audio.currentTime = 0;
      this.isPlaying = false;
      console.log('🔇 Music stopped');
    } catch (error) {
      console.warn('Error stopping music:', error);
    }
  }

  /**
   * Resume music if sound is enabled
   */
  resume() {
    if (!this.initialized || this.isPlaying) {
      return;
    }
    
    if (!this.isSoundEnabled()) {
      return;
    }
    
    if (this.audio && this.audio.src) {
      // Resume current track
      this.audio.play().catch(err => {
        console.warn('Failed to resume music:', err);
      });
      this.isPlaying = true;
    } else {
      // Start from beginning
      this.start();
    }
  }

  /**
   * Update music state based on sound settings
   * Call this when sound settings change
   */
  updateSoundSettings() {
    if (this.isSoundEnabled()) {
      if (!this.isPlaying) {
        this.resume();
      }
    } else {
      if (this.isPlaying) {
        this.stop();
      }
    }
  }

  /**
   * Set music volume (0.0 to 1.0)
   */
  setVolume(volume) {
    if (!this.audio) return;
    
    const clampedVolume = Math.max(0, Math.min(1, volume));
    this.audio.volume = clampedVolume;
  }
}

// Singleton instance
let musicManagerInstance = null;

export function getMusicManager(gameState) {
  if (!musicManagerInstance && gameState) {
    musicManagerInstance = new MusicManager(gameState);
  }
  return musicManagerInstance;
}
