/**
 * RelationshipService.js
 * Calculate manager relationship effects on happiness
 */

import { getManagerById } from '../constants/managerData.js';
import { MANAGER_STATS } from '../constants/gameConfig.js';

export class RelationshipService {
  /**
   * Calculate happiness impact from all manager relationships
   */
  static calculateRelationshipEffects(managers) {
    if (!managers || managers.length <= 1) {
      return { totalEffect: 0, relationships: [] };
    }

    const relationships = [];
    let totalEffect = 0;

    // Check all pairs of managers
    for (let i = 0; i < managers.length; i++) {
      for (let j = i + 1; j < managers.length; j++) {
        const manager1 = managers[i];
        const manager2 = managers[j];

        const effect = this.getRelationshipEffect(manager1.id, manager2.id);
        
        if (effect !== 0) {
          relationships.push({
            manager1Id: manager1.id,
            manager1Name: manager1.name,
            manager2Id: manager2.id,
            manager2Name: manager2.name,
            effect: effect,
            type: effect > 0 ? 'positive' : 'negative'
          });

          totalEffect += effect;
        }
      }
    }

    return {
      totalEffect,
      relationships
    };
  }

  /**
   * Get relationship effect between two managers
   */
  static getRelationshipEffect(managerId1, managerId2) {
    const manager1Data = getManagerById(managerId1);
    const manager2Data = getManagerById(managerId2);

    if (!manager1Data || !manager2Data) return 0;

    // Check if manager1 likes manager2
    if (manager1Data.likes && manager1Data.likes.includes(managerId2)) {
      return MANAGER_STATS.RELATIONSHIP_BONUS;
    }

    // Check if manager1 dislikes manager2
    if (manager1Data.dislikes && manager1Data.dislikes.includes(managerId2)) {
      return -MANAGER_STATS.RELATIONSHIP_PENALTY;
    }

    // Check reverse (manager2's feelings toward manager1)
    if (manager2Data.likes && manager2Data.likes.includes(managerId1)) {
      return MANAGER_STATS.RELATIONSHIP_BONUS;
    }

    if (manager2Data.dislikes && manager2Data.dislikes.includes(managerId1)) {
      return -MANAGER_STATS.RELATIONSHIP_PENALTY;
    }

    return 0; // Neutral relationship
  }

  /**
   * Get all relationships for a specific manager
   */
  static getManagerRelationships(managerId, allManagers) {
    const managerData = getManagerById(managerId);
    if (!managerData) return [];

    const relationships = [];

    // Check likes
    if (managerData.likes) {
      for (const likedId of managerData.likes) {
        const likedManager = allManagers.find(m => m.id === likedId);
        if (likedManager) {
          relationships.push({
            managerId: likedId,
            managerName: likedManager.name,
            type: 'likes',
            effect: MANAGER_STATS.RELATIONSHIP_BONUS
          });
        }
      }
    }

    // Check dislikes
    if (managerData.dislikes) {
      for (const dislikedId of managerData.dislikes) {
        const dislikedManager = allManagers.find(m => m.id === dislikedId);
        if (dislikedManager) {
          relationships.push({
            managerId: dislikedId,
            managerName: dislikedManager.name,
            type: 'dislikes',
            effect: -MANAGER_STATS.RELATIONSHIP_PENALTY
          });
        }
      }
    }

    return relationships;
  }

  /**
   * Check if hiring a new manager would cause relationship issues
   */
  static wouldCauseConflict(newManagerId, currentManagers) {
    const newManagerData = getManagerById(newManagerId);
    if (!newManagerData) return false;

    for (const manager of currentManagers) {
      // Check if new manager dislikes any current manager
      if (newManagerData.dislikes && newManagerData.dislikes.includes(manager.id)) {
        return true;
      }

      // Check if any current manager dislikes the new manager
      const currentManagerData = getManagerById(manager.id);
      if (currentManagerData.dislikes && currentManagerData.dislikes.includes(newManagerId)) {
        return true;
      }
    }

    return false;
  }

  /**
   * Get warning message for potential conflicts
   */
  static getConflictWarning(newManagerId, currentManagers) {
    const newManagerData = getManagerById(newManagerId);
    if (!newManagerData) return null;

    const conflicts = [];

    for (const manager of currentManagers) {
      // Check if new manager dislikes any current manager
      if (newManagerData.dislikes && newManagerData.dislikes.includes(manager.id)) {
        conflicts.push(`${newManagerData.name} dislikes ${manager.name}`);
      }

      // Check if any current manager dislikes the new manager
      const currentManagerData = getManagerById(manager.id);
      if (currentManagerData.dislikes && currentManagerData.dislikes.includes(newManagerId)) {
        conflicts.push(`${manager.name} dislikes ${newManagerData.name}`);
      }
    }

    if (conflicts.length > 0) {
      return `⚠️ Warning: ${conflicts.join(', ')}. This will reduce town happiness.`;
    }

    return null;
  }
}
