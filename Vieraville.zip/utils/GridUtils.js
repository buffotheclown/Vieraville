/**
 * GridUtils.js
 * Utility functions for grid coordinate conversions and tile operations
 */

import { GRID } from '../constants/gameConfig.js';

/**
 * Convert tile coordinates to pixel coordinates
 */
export function tileToPixel(tileX, tileY) {
  return {
    x: tileX * GRID.TILE_SIZE,
    y: tileY * GRID.TILE_SIZE
  };
}

/**
 * Convert pixel coordinates to tile coordinates
 */
export function pixelToTile(pixelX, pixelY) {
  return {
    x: Math.floor(pixelX / GRID.TILE_SIZE),
    y: Math.floor(pixelY / GRID.TILE_SIZE)
  };
}

/**
 * Check if tile coordinates are within grid bounds
 */
export function isValidTile(tileX, tileY) {
  return tileX >= 0 && tileX < GRID.WIDTH && tileY >= 0 && tileY < GRID.HEIGHT;
}

/**
 * Get neighboring tiles (4-directional)
 */
export function getNeighbors4(tileX, tileY) {
  const neighbors = [];
  const directions = [
    { x: 0, y: -1 },  // North
    { x: 1, y: 0 },   // East
    { x: 0, y: 1 },   // South
    { x: -1, y: 0 }   // West
  ];

  for (const dir of directions) {
    const nx = tileX + dir.x;
    const ny = tileY + dir.y;
    if (isValidTile(nx, ny)) {
      neighbors.push({ x: nx, y: ny });
    }
  }

  return neighbors;
}

/**
 * Get neighboring tiles (8-directional including diagonals)
 */
export function getNeighbors8(tileX, tileY) {
  const neighbors = [];
  
  for (let dy = -1; dy <= 1; dy++) {
    for (let dx = -1; dx <= 1; dx++) {
      if (dx === 0 && dy === 0) continue;
      
      const nx = tileX + dx;
      const ny = tileY + dy;
      
      if (isValidTile(nx, ny)) {
        neighbors.push({ x: nx, y: ny });
      }
    }
  }

  return neighbors;
}

/**
 * Calculate Manhattan distance between two tiles
 */
export function manhattanDistance(x1, y1, x2, y2) {
  return Math.abs(x2 - x1) + Math.abs(y2 - y1);
}

/**
 * Calculate Euclidean distance between two tiles
 */
export function euclideanDistance(x1, y1, x2, y2) {
  const dx = x2 - x1;
  const dy = y2 - y1;
  return Math.sqrt(dx * dx + dy * dy);
}

/**
 * Get tile index in 1D array from 2D coordinates
 */
export function getTileIndex(tileX, tileY) {
  return tileY * GRID.WIDTH + tileX;
}

/**
 * Get 2D coordinates from 1D tile index
 */
export function getTileCoords(index) {
  return {
    x: index % GRID.WIDTH,
    y: Math.floor(index / GRID.WIDTH)
  };
}

/**
 * Create empty grid with default value
 */
export function createEmptyGrid(defaultValue = null) {
  const grid = [];
  for (let y = 0; y < GRID.HEIGHT; y++) {
    const row = [];
    for (let x = 0; x < GRID.WIDTH; x++) {
      row.push(defaultValue);
    }
    grid.push(row);
  }
  return grid;
}

/**
 * Clone a grid
 */
export function cloneGrid(grid) {
  return grid.map(row => [...row]);
}
