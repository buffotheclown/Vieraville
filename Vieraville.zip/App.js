/**
 * App.js
 * Main React component - scene router and game coordinator
 */

import React, { useState, useEffect } from 'react';
import { GameStateProvider, useGameState } from './state/StateManager.js';
import { SplashScreen } from './components/scenes/SplashScreen.js';
import { TitleScreen } from './components/scenes/TitleScreen.js';
import { ManagerSelection } from './components/scenes/ManagerSelection.js';
import { GameScene } from './components/scenes/GameScene.js';
import { TimeManager } from './managers/TimeManager.js';
import { getSoundManager } from './services/SoundManager.js';
import { getMusicManager } from './services/MusicManager.js';
import { GAME_STATES } from './constants/gameConfig.js';

function GameRouter() {
  const gameState = useGameState();
  const [timeManager] = useState(() => new TimeManager(gameState));
  const [soundManager] = useState(() => getSoundManager(gameState));
  const [musicManager] = useState(() => getMusicManager(gameState));
  const [showSplash, setShowSplash] = useState(true);
  const [currentScene, setCurrentScene] = useState(GAME_STATES.TITLE);
  const [gameSceneCreated, setGameSceneCreated] = useState(false); // Track if GameScene was ever created

  // Start music when title screen loads (not on splash)
  useEffect(() => {
    // Only start music if splash is done and we're on title screen
    if (!showSplash && currentScene === GAME_STATES.TITLE) {
      const startMusic = () => {
        musicManager.start();
        // Remove listeners after first interaction
        window.removeEventListener('click', startMusic);
        window.removeEventListener('keydown', startMusic);
      };
      
      // Try to start immediately (may be blocked by browser)
      musicManager.start();
      
      // Also try on first user interaction
      window.addEventListener('click', startMusic);
      window.addEventListener('keydown', startMusic);
      
      return () => {
        window.removeEventListener('click', startMusic);
        window.removeEventListener('keydown', startMusic);
      };
    }
  }, [musicManager, showSplash, currentScene]);

  useEffect(() => {
    // Subscribe to scene changes
    const handleStateChange = (eventType) => {
      if (eventType === 'scene_change') {
        setCurrentScene(gameState.currentScene);
        
        // Once we enter PLAYING or MANAGER_SELECTION with managers, GameScene should persist
        if (gameState.currentScene === GAME_STATES.PLAYING || 
            (gameState.currentScene === GAME_STATES.MANAGER_SELECTION && gameState.hiredManagers.length > 0)) {
          setGameSceneCreated(true);
        }
      }
    };

    gameState.addListener(handleStateChange);

    return () => {
      gameState.removeListener(handleStateChange);
      timeManager.stop();
    };
  }, [gameState, timeManager]);

  const handleStartGame = (shouldLoadSave = false) => {
    if (shouldLoadSave) {
      console.log('Loading saved game...');
      // Don't reset - GameScene will handle loading
      gameState.setScene(GAME_STATES.PLAYING);
      // Start time manager for loaded game
      if (!timeManager.isRunning) {
        timeManager.start();
      }
    } else {
      console.log('Starting new game...');
      gameState.reset();
      gameState.setScene(GAME_STATES.MANAGER_SELECTION);
    }
  };

  const handleManagerSelected = () => {
    // CRITICAL: Set gameSceneCreated BEFORE changing scene to prevent unmount/remount
    if (!gameSceneCreated) {
      setGameSceneCreated(true);
    }
    
    gameState.setScene(GAME_STATES.PLAYING);
    
    // Only start time manager on first hire
    if (!timeManager.isRunning) {
      timeManager.start();
    }
  };

  // Show splash screen first
  if (showSplash) {
    return React.createElement(SplashScreen, {
      onComplete: () => setShowSplash(false)
    });
  }

  // Render current scene
  // NOTE: Once GameScene is created, keep it mounted but toggle visibility
  // This prevents managers from losing their state during hiring
  
  if (currentScene === GAME_STATES.TITLE) {
    return React.createElement(TitleScreen, { 
      onStart: handleStartGame,
      soundManager: soundManager
    });
  }
  
  // For all other scenes, we may need to show GameScene underneath
  return React.createElement('div', { style: styles.sceneContainer },
    // GameScene (kept mounted once created, but may be hidden)
    // CRITICAL: Once gameSceneCreated is true, it NEVER unmounts
    gameSceneCreated && React.createElement('div', {
      style: {
        ...styles.sceneLayer,
        display: currentScene === GAME_STATES.PLAYING ? 'block' : 'none'
      },
      key: 'game-scene' // Stable key to prevent remounting
    },
      React.createElement(GameScene, { 
        key: 'game-scene-component',
        timeManager: timeManager,
        soundManager: soundManager,
        musicManager: musicManager
      })
    ),
    
    // Manager Selection overlay (shown on top of game)
    currentScene === GAME_STATES.MANAGER_SELECTION && React.createElement('div', {
      style: styles.sceneLayer
    },
      React.createElement(ManagerSelection, { 
        onComplete: handleManagerSelected,
        soundManager: soundManager
      })
    ),
    
    // Victory/Defeat screens
    currentScene === GAME_STATES.VICTORY && React.createElement('div', {
      style: styles.sceneLayer
    },
      React.createElement('div', { style: styles.placeholder },
        React.createElement('h1', { style: styles.placeholderText }, 'Victory!')
      )
    ),
    
    currentScene === GAME_STATES.DEFEAT && React.createElement('div', {
      style: styles.sceneLayer
    },
      React.createElement('div', { style: styles.placeholder },
        React.createElement('h1', { style: styles.placeholderText }, 'Defeat')
      )
    )
  );
}

export default function App() {
  return React.createElement(GameStateProvider, null,
    React.createElement(GameRouter)
  );
}

const styles = {
  sceneContainer: {
    position: 'relative',
    width: '100vw',
    height: '100vh',
    overflow: 'hidden'
  },
  sceneLayer: {
    position: 'absolute',
    top: 0,
    left: 0,
    width: '100%',
    height: '100%',
    zIndex: 1
  },
  placeholder: {
    width: '100vw',
    height: '100vh',
    backgroundColor: '#1a1a1a',
    display: 'flex',
    flexDirection: 'column',
    justifyContent: 'center',
    alignItems: 'center',
    color: '#ffffff'
  },
  placeholderText: {
    fontSize: '48px',
    margin: '20px'
  },
  placeholderSubtext: {
    fontSize: '24px',
    color: '#888',
    margin: '10px'
  },
  placeholderButton: {
    fontSize: '16px',
    padding: '15px 30px',
    margin: '10px',
    backgroundColor: '#2E7D32',
    color: '#ffffff',
    border: 'none',
    borderRadius: '8px',
    cursor: 'pointer'
  },
  debugInfo: {
    marginTop: '40px',
    padding: '20px',
    backgroundColor: '#2a2a2a',
    borderRadius: '8px',
    textAlign: 'left'
  }
};
