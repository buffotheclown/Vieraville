/**
 * MaintenanceManager.js
 * Manages building and road degradation, repairs, and happiness penalties
 * Buildings/roads degrade over time and need repairs
 */

export class MaintenanceManager {
  constructor(gameState) {
    this.state = gameState;
    this.degradationRate = 0.01; // 1% chance per structure per month
    this.maxPerMonth = 10; // Maximum 10 structures can degrade per month
    this.lastDegradationCheck = 0;
  }

  /**
   * Check for degradation at end of each month
   * Called by TimeManager on month change
   */
  checkForDegradation() {
    const currentMonth = this.state.tickCount;
    
    // Only check once per month
    if (this.lastDegradationCheck === currentMonth) {
      return;
    }
    
    this.lastDegradationCheck = currentMonth;
    
    const gridManager = this.state.getGridManager();
    if (!gridManager) return;

    let buildingsDegraded = 0;
    let roadsDegraded = 0;
    const seenBuildings = new Set();
    let totalDegraded = 0;

    // Collect all structures that could degrade
    const candidates = [];
    
    for (let y = 0; y < 100; y++) {
      for (let x = 0; x < 100; x++) {
        // Check buildings
        const building = gridManager.getBuildingAt(x, y);
        if (building && building.building_id && !seenBuildings.has(building.building_id)) {
          seenBuildings.add(building.building_id);
          
          // Skip if already in disrepair
          if (!building.needs_repair) {
            candidates.push({ type: 'building', data: building });
          }
        }

        // Check roads
        const road = gridManager.getRoadAt(x, y);
        if (road && road.is_road && !road.needs_repair) {
          candidates.push({ type: 'road', data: road });
        }
      }
    }

    // Shuffle candidates and pick up to maxPerMonth
    const shuffled = candidates.sort(() => Math.random() - 0.5);
    
    for (const candidate of shuffled) {
      if (totalDegraded >= this.maxPerMonth) break;
      
      // 1% chance per structure
      if (Math.random() < this.degradationRate) {
        if (candidate.type === 'building') {
          // Set needs_repair on BOTH the grid tile AND the gameState building object
          candidate.data.needs_repair = true;
          candidate.data.repair_cost = Math.round((candidate.data.revenue_base || 10000) * 0.01);
          
          // ALSO set it on the gameState.buildings array
          const gameStateBuilding = this.state.buildings.find(b => b.building_id === candidate.data.building_id);
          if (gameStateBuilding) {
            gameStateBuilding.needs_repair = true;
            gameStateBuilding.repair_cost = candidate.data.repair_cost;
          }
          
          buildingsDegraded++;
        } else if (candidate.type === 'road') {
          candidate.data.needs_repair = true;
          candidate.data.repair_cost = 200;
          roadsDegraded++;
        }
        totalDegraded++;
      }
    }

    console.log(`🔧 MONTHLY DEGRADATION CHECK (Month ${currentMonth}) - ${buildingsDegraded} buildings, ${roadsDegraded} roads now need repair (max 10/month)`);
    
    if (buildingsDegraded > 0 || roadsDegraded > 0) {
      // Emit notification so player knows
      this.state.emit('manager-action', {
        action: 'maintenance-warning',
        buildings: buildingsDegraded,
        roads: roadsDegraded
      });
    }
  }

  /**
   * Get count of tiles needing repair
   */
  getDisrepairCount() {
    const gridManager = this.state.getGridManager();
    if (!gridManager) return { buildings: 0, roads: 0, total: 0 };

    let buildingsNeedingRepair = 0;
    let roadsNeedingRepair = 0;
    const seenBuildings = new Set();

    for (let y = 0; y < 100; y++) {
      for (let x = 0; x < 100; x++) {
        const building = gridManager.getBuildingAt(x, y);
        if (building && building.building_id && building.needs_repair && !seenBuildings.has(building.building_id)) {
          seenBuildings.add(building.building_id);
          buildingsNeedingRepair++;
        }

        const road = gridManager.getRoadAt(x, y);
        if (road && road.is_road && road.needs_repair) {
          roadsNeedingRepair++;
        }
      }
    }

    return {
      buildings: buildingsNeedingRepair,
      roads: roadsNeedingRepair,
      total: buildingsNeedingRepair + roadsNeedingRepair
    };
  }

  /**
   * Calculate happiness penalty from disrepair
   * Every 10 tiles in disrepair = -1% happiness (permanent)
   */
  calculateHappinessPenalty() {
    const disrepair = this.getDisrepairCount();
    const penalty = Math.floor(disrepair.total / 10);
    return penalty;
  }

  /**
   * Repair a building
   * Returns cost of repair, or null if couldn't repair
   */
  repairBuilding(x, y) {
    const gridManager = this.state.getGridManager();
    if (!gridManager) return null;

    const building = gridManager.getBuildingAt(x, y);
    if (!building || !building.needs_repair) {
      return null;
    }

    const cost = building.repair_cost || 0;
    
    if (!this.state.canAfford(cost)) {
      return null;
    }

    // Deduct cost and repair
    this.state.subtractBudget(cost);
    building.needs_repair = false;
    building.repair_cost = 0;

    return cost;
  }

  /**
   * Repair a road tile
   * Returns cost of repair, or null if couldn't repair
   */
  repairRoad(x, y) {
    const gridManager = this.state.getGridManager();
    if (!gridManager) return null;

    const road = gridManager.getRoadAt(x, y);
    if (!road || !road.needs_repair) {
      return null;
    }

    const cost = road.repair_cost || 200;
    
    if (!this.state.canAfford(cost)) {
      return null;
    }

    // Deduct cost and repair
    this.state.subtractBudget(cost);
    road.needs_repair = false;
    road.repair_cost = 0;

    return cost;
  }

  /**
   * Get building info at position (for inspection)
   */
  getBuildingInfo(x, y) {
    const gridManager = this.state.getGridManager();
    if (!gridManager) return null;

    const building = gridManager.getBuildingAt(x, y);
    if (!building || !building.building_id) return null;

    const employmentRate = building.employment_rate || 1.0;
    const yearsSinceBuilt = this.state.year - (building.longevity_year_built || this.state.year);

    return {
      name: building.name,
      type: building.building_type,
      subtype: building.building_subtype,
      position: { x: building.startX, y: building.startY },
      yearBuilt: building.longevity_year_built || this.state.year,
      yearsSinceBuilt: yearsSinceBuilt,
      ownerManager: building.owner_manager,
      // Stats
      population: building.current_population || 0,
      maxPopulation: building.max_population || 0,
      jobs: building.jobs_available || 0,
      employees: building.current_employees || 0,
      employmentRate: employmentRate,
      revenue: building.revenue_base || 0,
      happiness: building.happiness_effect || 0,
      // Maintenance
      needsRepair: building.needs_repair || false,
      repairCost: building.repair_cost || 0,
      // Additional
      size: building.size || 1,
      buildingId: building.building_id
    };
  }

  /**
   * Get road info at position
   */
  getRoadInfo(x, y) {
    const gridManager = this.state.getGridManager();
    if (!gridManager) return null;

    const road = gridManager.getRoadAt(x, y);
    if (!road || !road.is_road) return null;

    return {
      position: { x, y },
      quality: road.road_quality || 1.0,
      orientation: road.orientation || 'vertical',
      needsRepair: road.needs_repair || false,
      repairCost: road.repair_cost || 200
    };
  }

  /**
   * Demolish building and get refund
   * Returns 50% of estimated value
   */
  demolishBuilding(buildingId) {
    console.log('🔵 [MaintenanceManager] demolishBuilding called');
    console.log('  buildingId:', buildingId);
    
    const gridManager = this.state.getGridManager();
    console.log('  gridManager exists?', !!gridManager);
    
    if (!gridManager) {
      console.error('  ❌ No gridManager!');
      return null;
    }

    const seenBuildings = new Set();
    let targetBuilding = null;
    let tilesToClear = [];

    // Find all tiles for this building
    console.log('  Scanning grid for building tiles...');
    for (let y = 0; y < 100; y++) {
      for (let x = 0; x < 100; x++) {
        const building = gridManager.getBuildingAt(x, y);
        if (building && building.building_id === buildingId) {
          tilesToClear.push({ x, y });
          if (!targetBuilding) {
            targetBuilding = building;
            console.log('  Found target building:', building);
          }
        }
      }
    }

    console.log('  Tiles to clear:', tilesToClear.length);
    console.log('  Target building:', targetBuilding);

    if (!targetBuilding) {
      console.error('  ❌ Building not found with ID:', buildingId);
      return null;
    }

    // Calculate refund (50% of estimated value)
    const estimatedValue = (targetBuilding.revenue_base || 10000) * 10; // Rough estimate
    const refund = Math.round(estimatedValue * 0.5);
    console.log('  Estimated value:', estimatedValue);
    console.log('  Refund (50%):', refund);

    // Clear all tiles
    console.log('  Clearing tiles...');
    for (const pos of tilesToClear) {
      gridManager.clearBuilding(pos.x, pos.y);
    }
    console.log('  Tiles cleared');

    // Remove from gameState buildings array
    console.log('  Buildings in gameState before:', this.state.buildings.length);
    this.state.buildings = this.state.buildings.filter(b => b.building_id !== buildingId);
    console.log('  Buildings in gameState after:', this.state.buildings.length);

    // Give refund
    console.log('  Adding refund to budget...');
    this.state.addBudget(refund);
    console.log('  New budget:', this.state.budget);

    console.log(`✅ Demolished ${targetBuilding.name} for $${refund.toLocaleString()} refund`);

    return {
      name: targetBuilding.name,
      refund: refund
    };
  }
}
