/**
 * EventManager.js
 * Handles random events and milestone achievements
 */

export class EventManager {
  constructor(gameState) {
    this.state = gameState;
    this.lastSeasonEventCheck = -1; // Track which season we last checked for events
    this.achievedMilestones = new Set();
    
    // Listen for season changes
    this.state.on('season_change', () => this.onSeasonChange());
  }

  /**
   * Check for random events and milestones
   */
  update() {
    // Events now trigger on season change, not on cooldown
    this.checkForMilestones();
  }

  /**
   * Called when season changes - 25% chance for event
   */
  onSeasonChange() {
    const currentSeason = this.state.tickCount;
    
    // Prevent double-triggering for same season
    if (this.lastSeasonEventCheck === currentSeason) {
      return;
    }
    
    this.lastSeasonEventCheck = currentSeason;
    
    // 25% chance for event to occur at end of season
    if (Math.random() < 0.25) {
      this.triggerRandomEvent();
    }
  }

  /**
   * Check if a random event should occur (DEPRECATED - now using season-based)
   */
  checkForRandomEvent() {
    // No longer used - events trigger on season change instead
  }

  /**
   * Trigger a random event
   */
  triggerRandomEvent() {
    const events = [
      // Positive events
      {
        type: 'tourism_boom',
        name: '🌴 Tourism Boom',
        message: 'Tourist season brings extra revenue!',
        effect: () => {
          const bonus = 50000;
          this.state.addBudget(bonus);
          return `+$${(bonus / 1000).toFixed(0)}K revenue`;
        },
        weight: 2
      },
      {
        type: 'federal_grant',
        name: '💵 Federal Grant',
        message: 'Received federal development grant!',
        effect: () => {
          const grant = 100000;
          this.state.addBudget(grant);
          return `+$${(grant / 1000).toFixed(0)}K`;
        },
        weight: 1
      },
      {
        type: 'population_influx',
        name: '👥 Population Influx',
        message: 'New families moving to town!',
        effect: () => {
          const bonus = Math.round(this.state.population * 0.05);
          this.state.population += bonus;
          return `+${bonus} residents`;
        },
        weight: 2
      },
      {
        type: 'perfect_weather',
        name: '☀️ Perfect Weather',
        message: 'Perfect weather boosts happiness!',
        effect: () => {
          this.state.addHappinessModifier(5, 3, 'Perfect Weather'); // +5% for 3 months
          return '+5% happiness for 3 months';
        },
        weight: 3
      },

      // Negative events
      {
        type: 'hurricane_damage',
        name: '🌀 Hurricane Damage',
        message: 'Hurricane caused property damage!',
        effect: () => {
          const damage = 75000;
          this.state.subtractBudget(damage);
          return `-$${(damage / 1000).toFixed(0)}K repairs`;
        },
        weight: 1
      },
      {
        type: 'flooding',
        name: '🌊 Flooding',
        message: 'Seasonal flooding requires cleanup!',
        effect: () => {
          const cost = 30000;
          this.state.subtractBudget(cost);
          this.state.addHappinessModifier(-3, 2, 'Flooding'); // -3% for 2 months
          return `-$${(cost / 1000).toFixed(0)}K, -3% happiness for 2 months`;
        },
        weight: 2
      },
      {
        type: 'recession',
        name: '📉 Economic Downturn',
        message: 'Economic recession affects revenue!',
        effect: () => {
          const loss = 40000;
          this.state.subtractBudget(loss);
          return `-$${(loss / 1000).toFixed(0)}K`;
        },
        weight: 1
      },
      {
        type: 'heat_wave',
        name: '🔥 Heat Wave',
        message: 'Extreme heat affects happiness!',
        effect: () => {
          this.state.addHappinessModifier(-5, 3, 'Heat Wave'); // -5% for 3 months
          return '-5% happiness for 3 months';
        },
        weight: 2
      },

      // Additional Negative Events
      {
        type: 'red_tide',
        name: '🦠 Red Tide Outbreak',
        message: 'Toxic algae bloom hits the coast!',
        effect: () => {
          const cost = 45000;
          this.state.subtractBudget(cost);
          this.state.addHappinessModifier(-4, 3, 'Red Tide'); // -4% for 3 months
          return `-$${(cost / 1000).toFixed(0)}K cleanup, -4% happiness for 3 months`;
        },
        weight: 1
      },
      {
        type: 'sinkhole',
        name: '🕳️ Sinkhole Emergency',
        message: 'Massive sinkhole requires immediate repairs!',
        effect: () => {
          const damage = 90000;
          this.state.subtractBudget(damage);
          return `-$${(damage / 1000).toFixed(0)}K emergency repairs`;
        },
        weight: 1
      },
      {
        type: 'water_shortage',
        name: '💧 Water Shortage',
        message: 'Drought forces water restrictions!',
        effect: () => {
          this.state.addHappinessModifier(-6, 4, 'Water Shortage'); // -6% for 4 months
          const cost = 25000;
          this.state.subtractBudget(cost);
          return `-$${(cost / 1000).toFixed(0)}K water imports, -6% happiness for 4 months`;
        },
        weight: 2
      },
      {
        type: 'power_outage',
        name: '⚡ Major Power Outage',
        message: 'Grid failure causes widespread outages!',
        effect: () => {
          const cost = 35000;
          this.state.subtractBudget(cost);
          this.state.addHappinessModifier(-7, 2, 'Power Outage'); // -7% for 2 months
          return `-$${(cost / 1000).toFixed(0)}K repairs, -7% happiness for 2 months`;
        },
        weight: 2
      },
      {
        type: 'invasive_species',
        name: '🐍 Invasive Python Problem',
        message: 'Burmese pythons threaten local wildlife!',
        effect: () => {
          const cost = 20000;
          this.state.subtractBudget(cost);
          this.state.addHappinessModifier(-3, 6, 'Python Problem'); // -3% for 6 months
          return `-$${(cost / 1000).toFixed(0)}K removal program, -3% happiness for 6 months`;
        },
        weight: 2
      },
      {
        type: 'lawsuit',
        name: '⚖️ Zoning Lawsuit',
        message: 'Legal battle over zoning violations!',
        effect: () => {
          const cost = 60000;
          this.state.subtractBudget(cost);
          return `-$${(cost / 1000).toFixed(0)}K legal fees and settlement`;
        },
        weight: 1
      },
      {
        type: 'infrastructure_collapse',
        name: '🌉 Infrastructure Failure',
        message: 'Aging infrastructure requires replacement!',
        effect: () => {
          const damage = 80000;
          this.state.subtractBudget(damage);
          this.state.addHappinessModifier(-5, 3, 'Infrastructure Collapse');
          return `-$${(damage / 1000).toFixed(0)}K repairs, -5% happiness for 3 months`;
        },
        weight: 1
      },
      {
        type: 'toxic_spill',
        name: '☣️ Chemical Spill',
        message: 'Hazardous materials spill requires cleanup!',
        effect: () => {
          const cost = 55000;
          this.state.subtractBudget(cost);
          this.state.addHappinessModifier(-8, 4, 'Toxic Spill'); // -8% for 4 months
          return `-$${(cost / 1000).toFixed(0)}K hazmat cleanup, -8% happiness for 4 months`;
        },
        weight: 1
      },
      {
        type: 'corruption_scandal',
        name: '🕵️ Corruption Scandal',
        message: 'Political scandal damages reputation!',
        effect: () => {
          const cost = 40000;
          this.state.subtractBudget(cost);
          this.state.addHappinessModifier(-10, 5, 'Corruption Scandal'); // -10% for 5 months
          return `-$${(cost / 1000).toFixed(0)}K investigations, -10% happiness for 5 months`;
        },
        weight: 1
      },
      {
        type: 'wildfire_smoke',
        name: '💨 Wildfire Smoke',
        message: 'Smoke from distant wildfires blankets town!',
        effect: () => {
          this.state.addHappinessModifier(-4, 2, 'Wildfire Smoke'); // -4% for 2 months
          const cost = 15000;
          this.state.subtractBudget(cost);
          return `-$${(cost / 1000).toFixed(0)}K air quality measures, -4% happiness for 2 months`;
        },
        weight: 2
      },

      // Neutral/Mixed events
      {
        type: 'festival',
        name: '🎉 Local Festival',
        message: 'Annual festival brings joy and costs!',
        effect: () => {
          const cost = 20000;
          this.state.subtractBudget(cost);
          this.state.addHappinessModifier(8, 2, 'Local Festival'); // +8% for 2 months
          return `-$${(cost / 1000).toFixed(0)}K, +8% happiness for 2 months`;
        },
        weight: 2
      },
      {
        type: 'sports_team',
        name: '⚾ Sports Victory',
        message: 'Local team wins championship!',
        effect: () => {
          this.state.addHappinessModifier(10, 4, 'Sports Victory'); // +10% for 4 months
          return '+10% happiness for 4 months';
        },
        weight: 2
      }
    ];

    // Weighted random selection
    const totalWeight = events.reduce((sum, e) => sum + e.weight, 0);
    let random = Math.random() * totalWeight;
    
    let selectedEvent = events[0];
    for (const event of events) {
      random -= event.weight;
      if (random <= 0) {
        selectedEvent = event;
        break;
      }
    }

    // Apply event effect
    const effectResult = selectedEvent.effect();
    
    // Emit event
    this.state.emit('random-event', {
      type: selectedEvent.type,
      name: selectedEvent.name,
      message: selectedEvent.message,
      result: effectResult
    });
  }

  /**
   * Check for milestone achievements
   */
  checkForMilestones() {
    const milestones = [
      {
        id: 'pop_100',
        name: 'First Hundred',
        description: 'Reached 100 residents',
        check: () => this.state.population >= 100,
        reward: 25000
      },
      {
        id: 'pop_500',
        name: 'Growing Town',
        description: 'Reached 500 residents',
        check: () => this.state.population >= 500 && this.state.population > 0, // Must have built something
        reward: 50000
      },
      {
        id: 'pop_1000',
        name: 'Small City',
        description: 'Reached 1,000 residents',
        check: () => this.state.population >= 1000,
        reward: 100000
      },
      {
        id: 'pop_5000',
        name: 'Thriving City',
        description: 'Reached 5,000 residents',
        check: () => this.state.population >= 5000,
        reward: 250000
      },
      {
        id: 'happiness_80',
        name: 'Happy Town',
        description: 'Reached 80% happiness',
        check: () => this.state.happiness >= 80 && this.state.buildings.length >= 5, // Must have buildings
        reward: 30000
      },
      {
        id: 'happiness_95',
        name: 'Paradise Found',
        description: 'Reached 95% happiness',
        check: () => this.state.happiness >= 95 && this.state.buildings.length >= 10, // Must have substantial town
        reward: 75000
      },
      {
        id: 'millionaire',
        name: 'Millionaire Mayor',
        description: 'Earned $1M in net revenue',
        check: () => this.state.totalEarned >= 1000000,
        reward: 50000
      },
      {
        id: 'first_year',
        name: 'Anniversary',
        description: 'Survived one year',
        check: () => this.state.year >= 2,
        reward: 100000
      },
      {
        id: 'five_years',
        name: 'Five Year Plan',
        description: 'Survived five years',
        check: () => this.state.year >= 6,
        reward: 500000
      }
    ];

    for (const milestone of milestones) {
      // Skip if already achieved
      if (this.achievedMilestones.has(milestone.id)) {
        continue;
      }

      // Check if milestone is achieved
      if (milestone.check()) {
        this.achieveMilestone(milestone);
      }
    }
  }

  /**
   * Award milestone achievement
   */
  achieveMilestone(milestone) {
    this.achievedMilestones.add(milestone.id);
    this.state.addBudget(milestone.reward);

    // Emit milestone event
    this.state.emit('milestone-achieved', {
      id: milestone.id,
      name: milestone.name,
      description: milestone.description,
      reward: milestone.reward
    });
  }

  /**
   * Get all achieved milestones
   */
  getAchievedMilestones() {
    return Array.from(this.achievedMilestones);
  }

  /**
   * Reset event manager (for new game)
   */
  reset() {
    this.lastEventTime = Date.now();
    this.achievedMilestones.clear();
  }
}
