/**
 * GameConditionChecker.js
 * Monitors win/lose conditions during gameplay
 */

import { WIN_CONDITIONS, LOSE_CONDITIONS } from '../constants/gameConfig.js';

export class GameConditionChecker {
  constructor(gameState) {
    this.state = gameState;
    this.victoryAchieved = false;
    this.defeatTriggered = false;
    this.lastCheckTime = Date.now();
    this.checkInterval = 5000; // Check every 5 seconds
  }

  /**
   * Check all win/lose conditions
   */
  check() {
    const now = Date.now();
    
    // Throttle checks
    if (now - this.lastCheckTime < this.checkInterval) {
      return null;
    }
    
    this.lastCheckTime = now;

    // Don't check again if already won or lost
    if (this.victoryAchieved || this.defeatTriggered) {
      return null;
    }

    // Check defeat conditions first
    const defeatReason = this.checkDefeatConditions();
    if (defeatReason) {
      this.defeatTriggered = true;
      return {
        type: 'defeat',
        reason: defeatReason
      };
    }

    // Check victory conditions
    if (this.checkVictoryConditions()) {
      this.victoryAchieved = true;
      return {
        type: 'victory'
      };
    }

    return null;
  }

  /**
   * Check if player has achieved victory
   */
  checkVictoryConditions() {
    const population = this.state.population;
    const happiness = this.state.happiness;

    // Win condition: 16,000 population AND 70% happiness
    const hasPopulation = population >= WIN_CONDITIONS.TARGET_POPULATION;
    const hasHappiness = happiness >= WIN_CONDITIONS.MIN_HAPPINESS;

    return hasPopulation && hasHappiness;
  }

  /**
   * Check if player has been defeated
   * Returns reason string or null
   */
  checkDefeatConditions() {
    const happiness = this.state.happiness;
    const budget = this.state.budget;

    // Lose condition 1: Happiness drops to 0
    if (happiness <= LOSE_CONDITIONS.MIN_HAPPINESS) {
      return 'unhappiness';
    }

    // Lose condition 2: Bankruptcy (negative budget below -$100K)
    if (budget < -100000) {
      return 'bankruptcy';
    }

    return null;
  }

  /**
   * Get progress toward victory
   */
  getVictoryProgress() {
    const population = this.state.population;
    const happiness = this.state.happiness;

    const populationProgress = Math.min(100, (population / WIN_CONDITIONS.TARGET_POPULATION) * 100);
    const happinessProgress = Math.min(100, (happiness / WIN_CONDITIONS.MIN_HAPPINESS) * 100);

    return {
      population: Math.round(populationProgress),
      happiness: Math.round(happinessProgress),
      overall: Math.round((populationProgress + happinessProgress) / 2)
    };
  }

  /**
   * Reset checker (for new game)
   */
  reset() {
    this.victoryAchieved = false;
    this.defeatTriggered = false;
    this.lastCheckTime = Date.now();
  }
}
