/**
 * PopulationManager.js
 * Tracks population and calculates happiness
 * Population comes from residential buildings, jobs from other buildings
 */

import { BUILDINGS } from '../constants/buildingData.js';
import { RelationshipService } from '../services/RelationshipService.js';

export class PopulationManager {
  constructor(gameState) {
    this.state = gameState;
  }

  /**
   * Calculate current population from all residential buildings
   */
  calculatePopulation() {
    const gridManager = this.state.getGridManager();
    if (!gridManager) return { total: 0, capacity: 0, employed: 0, unemployed: 0 };

    let totalPopulation = 0;
    let totalCapacity = 0;
    let totalJobs = 0;

    // Count population from buildings
    const seenBuildings = new Set(); // Track buildings we've already counted (to avoid multi-tile buildings)
    
    for (let y = 0; y < 100; y++) {
      for (let x = 0; x < 100; x++) {
        const building = gridManager.getBuildingAt(x, y);
        if (!building || !building.building_id) continue;

        // Skip if we've already counted this building
        if (seenBuildings.has(building.building_id)) continue;
        seenBuildings.add(building.building_id);

        // Add population (from residential buildings)
        if (building.current_population) {
          totalPopulation += building.current_population;
        }

        // Add housing capacity (use population_max for capacity)
        if (building.building_type === 'residential' && building.population_max) {
          totalCapacity += building.population_max;
        }

        // Add jobs (from all buildings)
        if (building.jobs_available) {
          totalJobs += building.jobs_available;
        }
      }
    }

    // Update game state
    this.state.population = totalPopulation;
    this.state.availableJobs = totalJobs; // Update available jobs in game state

    const employed = Math.min(totalPopulation, totalJobs);
    const unemployed = Math.max(0, totalPopulation - totalJobs);

    console.log(`📊 Population Stats - Total: ${totalPopulation}, Jobs: ${totalJobs}, Employed: ${employed}, Unemployed: ${unemployed}`);

    return {
      total: totalPopulation,
      capacity: totalCapacity,
      employed: employed,
      unemployed: unemployed,
      jobs: totalJobs,
      employmentRate: totalPopulation > 0 ? (employed / totalPopulation) : 1.0
    };
  }

  /**
   * Calculate overall happiness score (0-100)
   */
  calculateHappiness() {
    const gridManager = this.state.getGridManager();
    if (!gridManager) return 50;

    const popStats = this.calculatePopulation();
    
    // If no population, neutral happiness
    if (popStats.total === 0) {
      this.state.happiness = 50;
      return 50;
    }

    let happinessScore = 0;
    let totalWeight = 0;

    // 1. Employment factor (30% weight)
    const employmentHappiness = popStats.employmentRate * 100;
    happinessScore += employmentHappiness * 0.3;
    totalWeight += 0.3;

    // 2. Building diversity factor (20% weight)
    const diversityHappiness = this.calculateDiversityHappiness();
    happinessScore += diversityHappiness * 0.2;
    totalWeight += 0.2;

    // 3. Amenities factor (25% weight)
    const amenitiesHappiness = this.calculateAmenitiesHappiness(popStats.total);
    happinessScore += amenitiesHappiness * 0.25;
    totalWeight += 0.25;

    // 4. Housing quality factor (20% weight)
    const housingHappiness = this.calculateHousingHappiness(popStats);
    happinessScore += housingHappiness * 0.2;
    totalWeight += 0.2;

    // 5. Manager relationships factor (15% weight)
    const relationshipHappiness = this.calculateRelationshipHappiness();
    happinessScore += relationshipHappiness * 0.15;
    totalWeight += 0.15;

    // Normalize
    const finalHappiness = Math.round(happinessScore / totalWeight);
    
    // Update game state
    this.state.happiness = Math.max(0, Math.min(100, finalHappiness));

    return this.state.happiness;
  }

  /**
   * Calculate happiness from building diversity
   */
  calculateDiversityHappiness() {
    const gridManager = this.state.getGridManager();
    const buildingTypes = new Set();
    const seenBuildings = new Set();

    for (let y = 0; y < 100; y++) {
      for (let x = 0; x < 100; x++) {
        const building = gridManager.getBuildingAt(x, y);
        if (!building || !building.building_id) continue;

        // Skip if we've already counted this building
        if (seenBuildings.has(building.building_id)) continue;
        seenBuildings.add(building.building_id);

        if (building.building_type) {
          buildingTypes.add(building.building_type);
        }
      }
    }

    // More building types = higher happiness
    // 6 types available: residential, commercial, industrial, agricultural, ranch, amenity
    const typeCount = buildingTypes.size;
    return Math.min(100, (typeCount / 6) * 100);
  }

  /**
   * Calculate happiness from amenities
   */
  calculateAmenitiesHappiness(population) {
    const gridManager = this.state.getGridManager();
    let amenityCount = 0;
    let totalHappinessBonus = 0;
    const seenBuildings = new Set();

    for (let y = 0; y < 100; y++) {
      for (let x = 0; x < 100; x++) {
        const building = gridManager.getBuildingAt(x, y);
        if (!building || !building.building_id) continue;

        // Skip if we've already counted this building
        if (seenBuildings.has(building.building_id)) continue;
        seenBuildings.add(building.building_id);

        if (building.building_type === 'amenity') {
          amenityCount++;
          // Each amenity building provides happiness bonus
          totalHappinessBonus += building.happiness_effect || 5;
        }
      }
    }

    // Need roughly 1 amenity per 50 population
    if (population === 0) return 50;
    
    const idealAmenityCount = Math.ceil(population / 50);
    const amenityRatio = amenityCount / idealAmenityCount;
    
    // Base happiness + bonus
    const baseHappiness = Math.min(100, amenityRatio * 100);
    const bonusHappiness = Math.min(20, totalHappinessBonus);
    
    return Math.min(100, baseHappiness + bonusHappiness);
  }

  /**
   * Calculate happiness from manager relationships
   */
  calculateRelationshipHappiness() {
    const managers = this.state.managers || [];
    
    if (managers.length <= 1) {
      return 100; // No relationship issues with 0-1 managers
    }

    const result = RelationshipService.calculateRelationshipEffects(managers);
    
    // Base 100, modified by relationship effects
    // Each positive relationship (+10), each negative (-15)
    const happiness = 100 + result.totalEffect;
    
    return Math.max(0, Math.min(100, happiness));
  }

  /**
   * Calculate happiness from housing situation
   */
  calculateHousingHappiness(popStats) {
    // Check if housing is adequate
    if (popStats.total === 0) return 100;
    
    const housingRatio = popStats.capacity / popStats.total;
    
    // Perfect: 1 capacity per person = 100 happiness
    // Overcrowded: Less capacity = lower happiness
    // Underpopulated: More capacity = slight bonus
    
    if (housingRatio >= 1.0) {
      // Adequate or surplus housing
      return Math.min(100, 80 + (housingRatio - 1.0) * 20);
    } else {
      // Overcrowded
      return Math.max(20, housingRatio * 80);
    }
  }

  /**
   * Get population statistics by building type
   */
  getPopulationByType() {
    const gridManager = this.state.getGridManager();
    if (!gridManager) return {};

    const byType = {};
    const seenBuildings = new Set(); // Track buildings we've already counted

    for (let y = 0; y < 100; y++) {
      for (let x = 0; x < 100; x++) {
        const building = gridManager.getBuildingAt(x, y);
        if (!building || !building.building_id) continue;

        // Skip if we've already counted this building
        if (seenBuildings.has(building.building_id)) continue;
        seenBuildings.add(building.building_id);

        const type = building.building_type;
        if (!type) continue;

        if (!byType[type]) {
          byType[type] = { count: 0, population: 0, jobs: 0 };
        }

        byType[type].count++;
        byType[type].population += building.current_population || 0;
        byType[type].jobs += building.jobs_available || 0;
      }
    }

    return byType;
  }

  /**
   * Get happiness breakdown for debugging/display
   */
  getHappinessBreakdown() {
    const popStats = this.calculatePopulation();
    
    if (popStats.total === 0) {
      return {
        overall: 50,
        employment: 50,
        diversity: this.calculateDiversityHappiness(),
        amenities: 50,
        housing: 100
      };
    }

    return {
      overall: this.state.happiness,
      employment: Math.round(popStats.employmentRate * 100),
      diversity: Math.round(this.calculateDiversityHappiness()),
      amenities: Math.round(this.calculateAmenitiesHappiness(popStats.total)),
      housing: Math.round(this.calculateHousingHappiness(popStats)),
      relationships: Math.round(this.calculateRelationshipHappiness())
    };
  }

  /**
   * Get detailed relationship info for UI
   */
  getRelationshipDetails() {
    const managers = this.state.managers || [];
    return RelationshipService.calculateRelationshipEffects(managers);
  }
}
