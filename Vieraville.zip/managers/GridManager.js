/**
 * GridManager.js
 * Manages the tile grid system - terrain, roads, and buildings
 * Handles tile data storage and queries
 */

import { GRID } from '../constants/gameConfig.js';
import { createEmptyGrid, isValidTile, getTileIndex } from '../utils/GridUtils.js';

export class GridManager {
  constructor(gameState) {
    this.state = gameState;
    
    // Three layers: terrain (static), roads (dynamic), buildings (dynamic)
    this.terrainLayer = createEmptyGrid();
    this.roadLayer = createEmptyGrid();
    this.buildingLayer = createEmptyGrid();
    
    // Entry points for managers
    this.entryPoints = [];
    
    // Tiled map data
    this.tiledMapData = null;
    this.tilesetImage = null;
    this.tileProperties = {}; // Map of tileId -> custom properties from tileset
    
    // Will be initialized with loadTiledMap()
  }
  
  /**
   * Load Tiled map data
   */
  async loadTiledMap(mapData, tilesetImage) {
    this.tiledMapData = mapData;
    this.tilesetImage = tilesetImage;
    this.tileProperties = mapData.tileProperties || {}; // Store tileset custom properties
    
    console.log('Loaded tile properties from tileset:', Object.keys(this.tileProperties).length, 'tiles with properties');
    
    // Load terrain layer from Tiled
    if (mapData.layers.Terrain) {
      this.loadTerrainFromTiled(mapData.layers.Terrain);
    } else {
      this.generateFloridaTerrain();
    }
    
    // Entry points are now read from Tiled custom properties
    console.log(`Loaded ${this.entryPoints.length} entry points from Tiled map`);
    
    // Only generate if NONE found in Tiled (emergency fallback)
    if (this.entryPoints.length === 0) {
      console.warn('No entry points found in Tiled map! Using fallback generation.');
      this.generateEntryPoints();
    }
  }

  /**
   * Load terrain from Tiled layer
   * NOW READS CUSTOM PROPERTIES FROM TMJ FILE!
   * 
   * Custom properties supported:
   * - buildable: boolean - allows ROADS to be placed (enables bridges over water)
   * - allows_roads_only: boolean - allows roads but NOT buildings (for water/bridges)
   * - terrain_quality: number (0-100) - quality multiplier for revenue
   * - zone_preference: string - preferred building types for this zone
   * - entry_point: boolean - marks tile as manager entry point
   */
  loadTerrainFromTiled(tiledLayer) {
    if (!tiledLayer || !tiledLayer.grid) {
      console.error('Invalid Tiled layer - no grid data');
      return;
    }
    
    console.log('Loading terrain from TMJ...');
    
    for (let y = 0; y < GRID.HEIGHT; y++) {
      for (let x = 0; x < GRID.WIDTH; x++) {
        const tile = tiledLayer.grid[y] ? tiledLayer.grid[y][x] : null;
        if (!tile) continue;
        
        const tileId = tile.tileId;
        const customProps = tile.properties || {};
        
        // ONLY USE CUSTOM PROPERTIES FROM TMJ - NO DEFAULTS, NO FALLBACKS
        const buildable = customProps.buildable !== undefined ? customProps.buildable : true;
        const terrainQuality = customProps.terrain_quality !== undefined ? (customProps.terrain_quality / 100) : 0.5;
        const zonePreference = customProps.zone_preference || 'mixed';
        const isEntryPoint = customProps.entry_point === true || customProps.entry_point === 'true';
        const allowsRoadsOnly = customProps.allows_roads_only === true || customProps.allows_roads_only === 'true';
        
        this.terrainLayer[y][x] = {
          buildable: buildable,
          allows_roads_only: allowsRoadsOnly, // New property: roads OK, buildings NOT OK
          terrain_quality: terrainQuality,
          entry_point: isEntryPoint,
          zone_preference: zonePreference,
          tileId: tileId
        };
        
        // If this tile is marked as entry point, add to entry points array
        if (isEntryPoint) {
          this.entryPoints.push({ x, y, used: false });
        }
      }
    }
    
    // Count zone preferences for debugging
    const zoneCounts = {};
    for (let y = 0; y < GRID.HEIGHT; y++) {
      for (let x = 0; x < GRID.WIDTH; x++) {
        const zone = this.terrainLayer[y][x].zone_preference;
        zoneCounts[zone] = (zoneCounts[zone] || 0) + 1;
      }
    }
    
    console.log(`Terrain loaded: ${this.entryPoints.length} entry points found`);
  }

  /**
   * Generate procedural Florida-style terrain (fallback)
   * Mix of grassland, some water features, dirt patches
   * Sets zone_preference: most tiles are "mixed" (buildable by all managers)
   */
  generateFloridaTerrain() {
    for (let y = 0; y < GRID.HEIGHT; y++) {
      for (let x = 0; x < GRID.WIDTH; x++) {
        // Default to grass
        let terrainType = 'grass';
        let buildable = true;
        let terrainQuality = 1.0;
        let zonePreference = 'mixed'; // Default: all managers can build here
        
        // Create water features (lakes/ponds)
        // Use noise-like pattern for natural looking water bodies
        const distFromCenter = Math.sqrt(
          Math.pow(x - GRID.WIDTH / 2, 2) + 
          Math.pow(y - GRID.HEIGHT / 2, 2)
        );
        
        // Small lakes scattered around
        const lakeNoise = this.simplexNoise(x / 15, y / 15);
        if (lakeNoise > 0.6 && distFromCenter < 35) {
          terrainType = 'water';
          buildable = false;
          terrainQuality = 0;
          zonePreference = 'wetland'; // Can't build on water
        }
        
        // Dirt patches (lower quality land)
        const dirtNoise = this.simplexNoise(x / 10 + 100, y / 10 + 100);
        if (dirtNoise > 0.5 && terrainType === 'grass') {
          terrainType = 'dirt';
          terrainQuality = 0.8;
        }
        
        // Edge buffer (map edges)
        if (x < 2 || x >= GRID.WIDTH - 2 || y < 2 || y >= GRID.HEIGHT - 2) {
          buildable = false;
        }
        
        this.terrainLayer[y][x] = {
          type: terrainType,
          buildable: buildable,
          allows_roads_only: false, // Default: no restriction for procedural terrain
          terrain_quality: terrainQuality,
          entry_point: false,
          zone_preference: zonePreference
        };
      }
    }
    
    // Add 24 entry points around the perimeter
    this.generateEntryPoints();
  }

  /**
   * Simple pseudo-random noise function for terrain generation
   */
  simplexNoise(x, y) {
    // Simple pseudo-noise using sine waves
    return (
      Math.sin(x * 0.5) * Math.cos(y * 0.5) +
      Math.sin(x * 1.2 + 3) * Math.cos(y * 0.8 + 5) * 0.5 +
      Math.sin(x * 2.1 + 7) * Math.cos(y * 1.7 + 2) * 0.25
    ) / 1.75;
  }

  /**
   * Generate 24 entry points around map perimeter
   * Evenly distributed on all 4 sides (6 per side)
   * INSET by 3 tiles from edge to allow building placement
   */
  generateEntryPoints() {
    const entriesPerSide = 6;
    const spacing = GRID.WIDTH / (entriesPerSide + 1);
    const EDGE_INSET = 3; // Keep entry points 3 tiles from edge
    
    // Top edge (inset from y=0)
    for (let i = 1; i <= entriesPerSide; i++) {
      const x = Math.floor(spacing * i);
      const y = EDGE_INSET;
      this.addEntryPoint(x, y);
    }
    
    // Bottom edge (inset from y=99)
    for (let i = 1; i <= entriesPerSide; i++) {
      const x = Math.floor(spacing * i);
      const y = GRID.HEIGHT - 1 - EDGE_INSET;
      this.addEntryPoint(x, y);
    }
    
    // Left edge (inset from x=0)
    for (let i = 1; i <= entriesPerSide; i++) {
      const y = Math.floor(spacing * i);
      const x = EDGE_INSET;
      this.addEntryPoint(x, y);
    }
    
    // Right edge (inset from x=99)
    for (let i = 1; i <= entriesPerSide; i++) {
      const y = Math.floor(spacing * i);
      const x = GRID.WIDTH - 1 - EDGE_INSET;
      this.addEntryPoint(x, y);
    }
  }

  /**
   * Mark a tile as an entry point
   */
  addEntryPoint(x, y) {
    if (isValidTile(x, y)) {
      this.terrainLayer[y][x].entry_point = true;
      this.terrainLayer[y][x].buildable = true; // Entry points are always buildable
      this.entryPoints.push({ x, y, used: false });
    }
  }

  /**
   * Get terrain data at tile coordinates
   */
  getTerrainAt(x, y) {
    if (!isValidTile(x, y)) return null;
    return this.terrainLayer[y][x];
  }

  /**
   * Get road data at tile coordinates
   */
  getRoadAt(x, y) {
    if (!isValidTile(x, y)) return null;
    return this.roadLayer[y][x];
  }

  /**
   * Get building data at tile coordinates
   */
  getBuildingAt(x, y) {
    if (!isValidTile(x, y)) return null;
    return this.buildingLayer[y][x];
  }

  /**
   * Check if tile is buildable for ROADS (allows roads on water/bridges via buildable=true)
   */
  isBuildable(x, y) {
    if (!isValidTile(x, y)) return false;
    
    const terrain = this.getTerrainAt(x, y);
    if (!terrain || !terrain.buildable) return false;
    
    // Can't build if road or building already exists
    if (this.roadLayer[y][x] !== null) return false;
    if (this.buildingLayer[y][x] !== null) return false;
    
    return true;
  }

  /**
   * Check if tile can have a BUILDING placed on it
   * Stricter than isBuildable() - blocks buildings on allows_roads_only tiles (water/bridges)
   */
  canPlaceBuilding(x, y) {
    if (!isValidTile(x, y)) return false;
    
    const terrain = this.getTerrainAt(x, y);
    if (!terrain || !terrain.buildable) return false;
    
    // Block buildings on tiles marked as "roads only" (water/bridges)
    if (terrain.allows_roads_only) return false;
    
    // Can't build if road or building already exists
    if (this.roadLayer[y][x] !== null) return false;
    if (this.buildingLayer[y][x] !== null) return false;
    
    return true;
  }

  /**
   * Place a road tile
   */
  placeRoad(x, y, roadQuality = 1.0, orientation = 'vertical') {
    if (!isValidTile(x, y)) return false;
    
    this.roadLayer[y][x] = {
      is_road: true,
      road_quality: roadQuality,
      orientation: orientation // 'vertical', 'horizontal', 'turn_ne', 'turn_nw', 'turn_se', 'turn_sw', 'cross'
    };
    
    return true;
  }

  /**
   * Place a building tile
   */
  placeBuilding(x, y, buildingData) {
    if (!isValidTile(x, y)) return false;
    
    this.buildingLayer[y][x] = {
      ...buildingData,
      x: x,
      y: y
    };
    
    return true;
  }

  /**
   * Clear a building tile (for demolition)
   */
  clearBuilding(x, y) {
    if (!isValidTile(x, y)) return false;
    this.buildingLayer[y][x] = null;
    return true;
  }

  /**
   * Get an unused entry point
   * @param {Object} preferredEntryPoint - If provided, return this specific entry point if available
   */
  getUnusedEntryPoint(preferredEntryPoint = null) {
    // If preferred entry point specified, try to use it
    if (preferredEntryPoint) {
      const preferred = this.entryPoints.find(ep => 
        ep.x === preferredEntryPoint.x && 
        ep.y === preferredEntryPoint.y
      );
      
      if (preferred && !preferred.used) {
        preferred.used = true;
        return preferred;
      }
      
      // If preferred is already used by this manager, return it anyway (it's their reserved point)
      if (preferred && preferred.used) {
        return { ...preferred }; // Return copy, don't mark as used again
      }
    }
    
    // Otherwise get random unused entry point
    const unused = this.entryPoints.filter(ep => !ep.used);
    if (unused.length === 0) return null;
    
    // Return random unused entry point
    const index = Math.floor(Math.random() * unused.length);
    const entryPoint = unused[index];
    entryPoint.used = true;
    
    return entryPoint;
  }

  /**
   * Get all entry points
   */
  getEntryPoints() {
    return this.entryPoints;
  }

  /**
   * Debug: Get grid statistics
   */
  getStats() {
    let buildableCount = 0;
    let roadCount = 0;
    let buildingCount = 0;
    
    for (let y = 0; y < GRID.HEIGHT; y++) {
      for (let x = 0; x < GRID.WIDTH; x++) {
        const terrain = this.terrainLayer[y][x];
        if (terrain.buildable) buildableCount++;
        
        if (this.roadLayer[y][x]) roadCount++;
        if (this.buildingLayer[y][x]) buildingCount++;
      }
    }
    
    return {
      totalTiles: GRID.WIDTH * GRID.HEIGHT,
      buildable: buildableCount,
      roads: roadCount,
      buildings: buildingCount,
      entryPoints: this.entryPoints.length
    };
  }
}
