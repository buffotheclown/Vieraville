/**
 * EmploymentManager.js
 * Distributes population to available jobs in buildings
 * Determines building employment rates for revenue calculations
 */

export class EmploymentManager {
  constructor(gameState) {
    this.state = gameState;
    this.cachedStats = null;
    this.lastCalculationTime = 0;
    this.CACHE_DURATION = 500; // Cache for 500ms to prevent spam
  }

  /**
   * Distribute population to jobs across all buildings
   * Updates each building's current_employees property
   * Returns employment statistics
   * CACHED: Only recalculates if cache is stale (> 500ms old)
   */
  distributeEmployment() {
    const now = Date.now();
    
    // Return cached result if still fresh
    if (this.cachedStats && (now - this.lastCalculationTime) < this.CACHE_DURATION) {
      return this.cachedStats;
    }

    const gridManager = this.state.getGridManager();
    if (!gridManager) return { totalEmployed: 0, totalUnemployed: 0, buildingsStaffed: 0 };

    // First pass: Get all buildings and total population/jobs
    const buildingsWithJobs = [];
    const seenBuildings = new Set();
    let totalPopulation = 0;
    let totalJobs = 0;

    for (let y = 0; y < 100; y++) {
      for (let x = 0; x < 100; x++) {
        const building = gridManager.getBuildingAt(x, y);
        if (!building || !building.building_id) continue;

        // Skip if we've already counted this building
        if (seenBuildings.has(building.building_id)) continue;
        seenBuildings.add(building.building_id);

        // Count population from residential buildings
        if (building.current_population) {
          totalPopulation += building.current_population;
        }

        // Track buildings with jobs
        if (building.jobs_available && building.jobs_available > 0) {
          buildingsWithJobs.push({
            building: building,
            position: { x, y },
            jobsAvailable: building.jobs_available,
            currentEmployees: 0 // Will be filled
          });
          totalJobs += building.jobs_available;
        }
      }
    }

    // Second pass: Distribute workers to buildings
    let remainingWorkers = totalPopulation;
    let buildingsStaffed = 0;

    // Sort buildings by priority (you could add priority logic here)
    // For now, distribute evenly based on job capacity
    buildingsWithJobs.forEach(entry => {
      if (remainingWorkers <= 0) {
        entry.currentEmployees = 0;
        return;
      }

      // Assign workers up to the building's capacity
      const workersAssigned = Math.min(entry.jobsAvailable, remainingWorkers);
      entry.currentEmployees = workersAssigned;
      remainingWorkers -= workersAssigned;

      if (workersAssigned > 0) {
        buildingsStaffed++;
      }

      // Update the building tile with employment data
      entry.building.current_employees = workersAssigned;
      entry.building.employment_rate = workersAssigned / entry.jobsAvailable;
    });

    const totalEmployed = totalPopulation - remainingWorkers;
    const totalUnemployed = remainingWorkers;

    const stats = {
      totalEmployed: totalEmployed,
      totalUnemployed: totalUnemployed,
      buildingsStaffed: buildingsStaffed,
      totalBuildings: buildingsWithJobs.length,
      employmentRate: totalJobs > 0 ? totalEmployed / totalJobs : 0
    };

    // Cache the result
    this.cachedStats = stats;
    this.lastCalculationTime = now;

    return stats;
  }

  /**
   * Get employment rate for a specific building
   * Returns 0.0 to 1.0 (0% to 100%)
   */
  getBuildingEmploymentRate(building) {
    if (!building || !building.jobs_available || building.jobs_available === 0) {
      return 1.0; // Buildings without jobs are considered "fully operational"
    }

    return building.employment_rate || 0.0;
  }
}
