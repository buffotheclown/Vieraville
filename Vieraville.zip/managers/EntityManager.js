/**
 * EntityManager.js
 * Manages manager entity ("little man") movement and rendering
 * Entities move at 1 tile per second along roads
 */

export class EntityManager {
  constructor() {
    this.entities = [];
  }

  /**
   * Create a new manager entity
   */
  createEntity(managerId, startX, startY) {
    const entity = {
      id: managerId,
      x: startX,
      y: startY,
      path: [],
      pathIndex: 0,
      moveTimer: 0,
      moveInterval: 1000, // 1 second per tile
      isMoving: false
    };

    this.entities.push(entity);
    console.log(`Created entity for ${managerId} at (${startX}, ${startY})`);
    return entity;
  }

  /**
   * Set path for entity to follow
   */
  setEntityPath(managerId, path) {
    const entity = this.entities.find(e => e.id === managerId);
    if (!entity) return;

    entity.path = [...path];
    entity.pathIndex = 0;
    entity.isMoving = true;
    entity.moveTimer = 0;

    console.log(`Set path for ${managerId}: ${path.length} tiles`);
  }

  /**
   * Update all entities
   */
  update(deltaTime) {
    for (const entity of this.entities) {
      if (!entity.isMoving || entity.pathIndex >= entity.path.length) {
        entity.isMoving = false;
        continue;
      }

      entity.moveTimer += deltaTime;

      if (entity.moveTimer >= entity.moveInterval) {
        entity.moveTimer -= entity.moveInterval;
        entity.pathIndex++;

        if (entity.pathIndex < entity.path.length) {
          const nextPos = entity.path[entity.pathIndex];
          entity.x = nextPos.x;
          entity.y = nextPos.y;
        } else {
          entity.isMoving = false;
        }
      }
    }
  }

  /**
   * Check if entity has completed path
   */
  hasCompletedPath(managerId) {
    const entity = this.entities.find(e => e.id === managerId);
    if (!entity) return true;
    return !entity.isMoving && entity.pathIndex >= entity.path.length;
  }

  /**
   * Get entity position
   */
  getEntityPosition(managerId) {
    const entity = this.entities.find(e => e.id === managerId);
    return entity ? { x: entity.x, y: entity.y } : null;
  }

  /**
   * Remove entity
   */
  removeEntity(managerId) {
    const index = this.entities.findIndex(e => e.id === managerId);
    if (index !== -1) {
      this.entities.splice(index, 1);
    }
  }

  /**
   * Get all entities for rendering
   */
  getAllEntities() {
    return this.entities;
  }
}
