/**
 * SaveManager.js
 * Handles saving and loading game state to/from LocalStorage
 */

const SAVE_KEY = 'vieraville_save';
const SAVE_VERSION = 1;

export class SaveManager {
  /**
   * Save current game state to LocalStorage
   */
  static saveGame(gameState, gridManager, managerCoordinator, eventManager) {
    try {
      const saveData = {
        version: SAVE_VERSION,
        timestamp: Date.now(),
        
        // Core state
        budget: gameState.budget,
        year: gameState.year,
        monthIndex: gameState.monthIndex,
        tickCount: gameState.tickCount,
        population: gameState.population,
        happiness: gameState.happiness,
        happinessModifiers: gameState.happinessModifiers,
        
        // Managers
        hiredManagers: gameState.hiredManagers,
        managers: this.serializeManagers(managerCoordinator),
        
        // Grid data
        grid: this.serializeGrid(gridManager),
        
        // Events
        events: this.serializeEvents(eventManager),
        
        // Metadata
        savedAt: new Date().toISOString()
      };

      const serialized = JSON.stringify(saveData);
      localStorage.setItem(SAVE_KEY, serialized);
      
      console.log('Game saved successfully');
      return true;
    } catch (error) {
      console.error('Failed to save game:', error);
      return false;
    }
  }

  /**
   * Load game state from LocalStorage
   */
  static loadGame() {
    try {
      const serialized = localStorage.getItem(SAVE_KEY);
      if (!serialized) {
        console.log('No save data found');
        return null;
      }

      const saveData = JSON.parse(serialized);
      
      // Version check
      if (saveData.version !== SAVE_VERSION) {
        console.warn('Save data version mismatch');
        // Could implement migration logic here
      }

      console.log('Game loaded successfully');
      return saveData;
    } catch (error) {
      console.error('Failed to load game:', error);
      return null;
    }
  }

  /**
   * Check if a save exists
   */
  static hasSave() {
    return localStorage.getItem(SAVE_KEY) !== null;
  }

  /**
   * Get save metadata without loading full game
   */
  static getSaveMetadata() {
    try {
      const serialized = localStorage.getItem(SAVE_KEY);
      if (!serialized) return null;

      const saveData = JSON.parse(serialized);
      return {
        savedAt: saveData.savedAt,
        year: saveData.year,
        month: saveData.monthIndex,
        population: saveData.population,
        budget: saveData.budget,
        managerCount: saveData.hiredManagers?.length || 0
      };
    } catch (error) {
      console.error('Failed to get save metadata:', error);
      return null;
    }
  }

  /**
   * Delete save data
   */
  static deleteSave() {
    try {
      localStorage.removeItem(SAVE_KEY);
      return true;
    } catch (error) {
      console.error('Failed to delete save:', error);
      return false;
    }
  }

  /**
   * Serialize manager data
   */
  static serializeManagers(managerCoordinator) {
    if (!managerCoordinator) return [];

    const managers = managerCoordinator.getAllManagers();
    return managers.map(manager => ({
      id: manager.managerId,
      happiness: manager.happiness,
      efficiency: manager.efficiency,
      raises: manager.raises,
      autoApprove: manager.autoApprove,
      currentState: manager.currentState,
      currentPlan: manager.currentPlan,
      currentPlans: manager.currentPlans,
      lastPlanTime: manager.lastPlanTime,
      position: manager.position,
      targetPosition: manager.targetPosition,
      // Road continuation system
      originalEntryPoint: manager.originalEntryPoint,
      lastRoadEndpoint: manager.lastRoadEndpoint,
      hasReachedCenter: manager.hasReachedCenter,
      // Building progress (for in-progress plans)
      buildProgress: manager.buildProgress
    }));
  }

  /**
   * Serialize grid data (roads and buildings)
   */
  static serializeGrid(gridManager) {
    if (!gridManager) return { roads: [], buildings: [] };

    const roads = [];
    const buildings = [];

    // Scan grid for roads and buildings
    for (let y = 0; y < 100; y++) {
      for (let x = 0; x < 100; x++) {
        const road = gridManager.getRoadAt(x, y);
        if (road) {
          roads.push({
            x,
            y,
            road_quality: road.road_quality,
            orientation: road.orientation || 'vertical'
          });
        }

        const building = gridManager.getBuildingAt(x, y);
        if (building) {
          buildings.push({
            x,
            y,
            building_id: building.building_id,
            manager_id: building.manager_id,
            owner_manager: building.owner_manager,
            name: building.name,
            type: building.type,
            building_type: building.building_type,
            building_subtype: building.building_subtype,
            tileId: building.tileId,
            size: building.size,
            startX: building.startX,
            startY: building.startY,
            current_population: building.current_population,
            max_population: building.max_population,
            population_min: building.population_min,
            population_max: building.population_max,
            jobs_available: building.jobs_available,
            revenue_base: building.revenue_base,
            happiness_effect: building.happiness_effect,
            longevity_year_built: building.longevity_year_built,
            is_complete: building.is_complete
          });
        }
      }
    }

    return { roads, buildings };
  }

  /**
   * Serialize event manager data
   */
  static serializeEvents(eventManager) {
    if (!eventManager) return { achievedMilestones: [] };

    return {
      achievedMilestones: eventManager.getAchievedMilestones(),
      lastEventTime: eventManager.lastEventTime
    };
  }

  /**
   * Restore game state from save data
   */
  static restoreGameState(saveData, gameState) {
    gameState.budget = saveData.budget;
    gameState.year = saveData.year;
    gameState.monthIndex = saveData.monthIndex;
    gameState.tickCount = saveData.tickCount;
    gameState.population = saveData.population;
    gameState.happiness = saveData.happiness;
    gameState.townHappiness = saveData.happiness; // Backwards compatibility
    gameState.happinessModifiers = saveData.happinessModifiers || [];
    gameState.hiredManagers = saveData.hiredManagers || [];
  }

  /**
   * Restore grid data
   */
  static restoreGrid(saveData, gridManager, gameState = null) {
    if (!saveData.grid) return;

    // Restore roads (skip auto-join to preserve saved orientations)
    for (const road of saveData.grid.roads) {
      gridManager.placeRoad(road.x, road.y, road.road_quality, road.orientation || 'vertical', true);
    }

    // Track unique buildings to avoid duplicates (multi-tile buildings)
    const restoredBuildingIds = new Set();

    // Restore buildings
    for (const building of saveData.grid.buildings) {
      const buildingData = {
        building_id: building.building_id,
        manager_id: building.manager_id,
        owner_manager: building.owner_manager,
        name: building.name,
        type: building.type,
        building_type: building.building_type,
        building_subtype: building.building_subtype,
        tileId: building.tileId,
        size: building.size,
        startX: building.startX,
        startY: building.startY,
        current_population: building.current_population,
        max_population: building.max_population,
        population_min: building.population_min,
        population_max: building.population_max,
        jobs_available: building.jobs_available,
        revenue_base: building.revenue_base,
        happiness_effect: building.happiness_effect,
        longevity_year_built: building.longevity_year_built,
        is_complete: building.is_complete
      };
      
      gridManager.placeBuilding(building.x, building.y, buildingData);
      
      // Add to gameState buildings array (only once per unique building_id)
      if (gameState && building.building_id && !restoredBuildingIds.has(building.building_id)) {
        gameState.addBuilding(buildingData);
        restoredBuildingIds.add(building.building_id);
      }
    }

    console.log(`Restored ${saveData.grid.roads.length} roads and ${saveData.grid.buildings.length} building tiles (${restoredBuildingIds.size} unique buildings)`);
  }

  /**
   * Restore manager data
   */
  static restoreManagers(saveData, managerCoordinator) {
    if (!saveData.managers) return;

    for (const managerData of saveData.managers) {
      const manager = managerCoordinator.getManager(managerData.id);
      if (!manager) continue;

      // Restore manager state using the restoreState method
      manager.restoreState({
        happiness: managerData.happiness,
        efficiency: managerData.efficiency,
        raises: managerData.raises,
        autoApprove: managerData.autoApprove,
        state: managerData.currentState,
        currentPlan: managerData.currentPlan,
        currentPlans: managerData.currentPlans,
        position: managerData.position,
        targetPosition: managerData.targetPosition,
        originalEntryPoint: managerData.originalEntryPoint,
        lastRoadEndpoint: managerData.lastRoadEndpoint,
        hasReachedCenter: managerData.hasReachedCenter,
        buildProgress: managerData.buildProgress
      });
      
      // Update lastPlanTime separately
      if (managerData.lastPlanTime) {
        manager.lastPlanTime = managerData.lastPlanTime;
      }
    }

    console.log(`Restored ${saveData.managers.length} managers`);
  }

  /**
   * Restore event manager data
   */
  static restoreEvents(saveData, eventManager) {
    if (!saveData.events) return;

    // Restore achieved milestones
    for (const milestoneId of saveData.events.achievedMilestones) {
      eventManager.achievedMilestones.add(milestoneId);
    }

    // Restore last event time
    if (saveData.events.lastEventTime) {
      eventManager.lastEventTime = saveData.events.lastEventTime;
    }

    console.log(`Restored ${saveData.events.achievedMilestones.length} achieved milestones`);
  }

  /**
   * Auto-save with throttling
   */
  static autoSave(gameState, gridManager, managerCoordinator, eventManager) {
    // Don't auto-save too frequently
    const now = Date.now();
    if (!this.lastAutoSave || now - this.lastAutoSave > 30000) { // 30 seconds
      this.lastAutoSave = now;
      return this.saveGame(gameState, gridManager, managerCoordinator, eventManager);
    }
    return false;
  }

  /**
   * Export save data as JSON file (for backup)
   */
  static exportSave() {
    try {
      const serialized = localStorage.getItem(SAVE_KEY);
      if (!serialized) {
        console.log('No save data to export');
        return null;
      }

      const saveData = JSON.parse(serialized);
      const blob = new Blob([JSON.stringify(saveData, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      
      const a = document.createElement('a');
      a.href = url;
      a.download = `vieraville_save_${Date.now()}.json`;
      a.click();
      
      URL.revokeObjectURL(url);
      console.log('Save exported successfully');
      return true;
    } catch (error) {
      console.error('Failed to export save:', error);
      return false;
    }
  }

  /**
   * Import save data from JSON file
   */
  static async importSave(file) {
    try {
      const text = await file.text();
      const saveData = JSON.parse(text);
      
      // Validate save data
      if (!saveData.version || !saveData.budget) {
        throw new Error('Invalid save file');
      }

      // Store in localStorage
      localStorage.setItem(SAVE_KEY, JSON.stringify(saveData));
      console.log('Save imported successfully');
      return true;
    } catch (error) {
      console.error('Failed to import save:', error);
      return false;
    }
  }
}

SaveManager.lastAutoSave = 0;
