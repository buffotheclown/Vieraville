/**
 * ManagerAI.js
 * Finite State Machine for manager behavior
 * States: Idle -> Proposing -> Approved -> Building -> Idle
 */

import { getManagerById } from '../constants/managerData.js';
import { PlanGenerator } from '../services/PlanGenerator.js';
import { MANAGER_STATS } from '../constants/gameConfig.js';

export const MANAGER_STATES = {
  IDLE: 'idle',
  PROPOSING: 'proposing',
  APPROVED: 'approved',
  BUILDING: 'building'
};

export class ManagerAI {
  constructor(managerId, gameState, gridManager, constructionEffects = null, soundManager = null) {
    this.managerId = managerId;
    this.state = gameState;
    this.gridManager = gridManager;
    this.constructionEffects = constructionEffects; // Reference to shared ConstructionEffects instance
    this.soundManager = soundManager; // Reference to SoundManager for construction sounds
    this.camera = null; // Camera reference for viewport-based volume
    
    // Load manager data
    const managerData = getManagerById(managerId);
    if (!managerData) {
      throw new Error(`Manager not found: ${managerId}`);
    }
    
    this.name = managerData.name;
    this.specialty = managerData.specialty;
    this.specialtyEffect = managerData.specialty_effect;
    this.buildPreferences = managerData.build_preferences;
    this.likes = managerData.likes;
    this.dislikes = managerData.dislikes;
    
    // Stats
    this.happiness = MANAGER_STATS.STARTING_HAPPINESS;
    this.efficiency = MANAGER_STATS.STARTING_EFFICIENCY;
    this.raises = 0;
    
    // Auto-approval system
    this.autoApprove = false; // When true, manager auto-approves their own plans
    
    // FSM state
    this.currentState = MANAGER_STATES.IDLE;
    this.currentPlan = null;
    
    // Building state
    this.buildProgress = {
      roadTiles: [],
      buildings: [],
      currentStep: 0,
      totalSteps: 0
    };
    
    // Entity position (for rendering with smooth movement)
    // FIXED PROBLEM #1: Initialize at FAR off-map position so arrows ALWAYS work
    // Position at (-1000, -1000) is guaranteed off-screen and will show arrow
    this.position = { x: -1000, y: -1000 }; // Current visual position (interpolated)
    this.targetPosition = { x: -1000, y: -1000 }; // Target grid position
    this.moveSpeed = 0.1; // Interpolation speed (0-1, higher = faster)
    
    // Road continuation system
    this.originalEntryPoint = null;  // First entry point used (reserved for this manager)
    this.lastRoadEndpoint = null;    // Last tile of most recent road (start point for next plan)
    this.hasReachedCenter = false;   // Whether this manager has reached (50, 50)
    
    // Timing
    this.lastPlanTime = Date.now();
    this.planCooldown = 30000; // 30 seconds between plans (3 months game time)
    

  }

  /**
   * Restore manager state from saved data
   */
  restoreState(savedData) {
    if (!savedData) return;
    
    this.happiness = savedData.happiness ?? this.happiness;
    this.efficiency = savedData.efficiency ?? this.efficiency;
    this.raises = savedData.raises ?? this.raises;
    this.autoApprove = savedData.autoApprove ?? this.autoApprove;
    this.currentState = savedData.state ?? this.currentState;
    this.currentPlan = savedData.currentPlan ?? this.currentPlan;
    this.currentPlans = savedData.currentPlans ?? this.currentPlans;
    
    // Restore position and targetPosition for smooth movement
    if (savedData.position) {
      this.position = { ...savedData.position };
    }
    if (savedData.targetPosition) {
      this.targetPosition = { ...savedData.targetPosition };
    } else if (savedData.position) {
      this.targetPosition = { ...savedData.position };
    }
    
    // Road continuation system
    this.originalEntryPoint = savedData.originalEntryPoint ?? this.originalEntryPoint;
    this.lastRoadEndpoint = savedData.lastRoadEndpoint ?? this.lastRoadEndpoint;
    this.hasReachedCenter = savedData.hasReachedCenter ?? this.hasReachedCenter;
    
    // Restore building progress (for in-progress plans)
    if (savedData.buildProgress && savedData.buildProgress.totalSteps > 0) {
      this.buildProgress = { ...savedData.buildProgress };
      console.log(`✅ [${this.name}] Restored building progress: ${this.buildProgress.currentStep}/${this.buildProgress.totalSteps} steps complete`);
      
      // If manager was in BUILDING state, we need to reload the builder classes and resume
      if (this.currentState === MANAGER_STATES.BUILDING) {
        console.log(`🔄 [${this.name}] Resuming building after load...`);
        this.resumeBuilding();
      }
    }

  }

  /**
   * Resume building after loading from save
   */
  async resumeBuilding() {
    // Import builder classes
    const { RoadBuilder } = await import('../services/RoadBuilder.js');
    const { BuildingPlacer } = await import('../services/BuildingPlacer.js');
    
    this.RoadBuilder = RoadBuilder;
    this.BuildingPlacer = BuildingPlacer;
    
    // Initialize build timer
    this.buildTimer = 0;
    
    console.log(`✅ [${this.name}] Building resumed - ready to continue from step ${this.buildProgress.currentStep}/${this.buildProgress.totalSteps}`);
  }

  /**
   * Set camera reference for viewport-based volume calculations
   */
  setCamera(camera) {
    this.camera = camera;
  }
  
  /**
   * Calculate volume multiplier based on viewport position
   * Returns 1.0 if in viewport, 0.2 if out of viewport
   */
  calculateVolumeMultiplier(x, y) {
    if (!this.camera || !this.camera.canvas) {
      return 1.0; // Default to full volume if no camera
    }
    
    const canvas = this.camera.canvas;
    const GRID_TILE_SIZE = 32;
    
    // Convert grid coordinates to world coordinates (pixels)
    const worldX = x * GRID_TILE_SIZE;
    const worldY = y * GRID_TILE_SIZE;
    
    // Convert world coordinates to screen coordinates
    const screenX = worldX * this.camera.zoom + this.camera.x;
    const screenY = worldY * this.camera.zoom + this.camera.y;
    
    // Check if in viewport (with some padding)
    const inViewport = (
      screenX >= -GRID_TILE_SIZE * this.camera.zoom &&
      screenX <= canvas.width + GRID_TILE_SIZE * this.camera.zoom &&
      screenY >= -GRID_TILE_SIZE * this.camera.zoom &&
      screenY <= canvas.height + GRID_TILE_SIZE * this.camera.zoom
    );
    
    return inViewport ? 1.0 : 0.2;
  }

  /**
   * Update manager AI (called each frame or tick)
   */
  update(deltaTime) {
    // ALWAYS update position interpolation for smooth movement
    this.updatePositionInterpolation();
    
    switch (this.currentState) {
      case MANAGER_STATES.IDLE:
        this.updateIdle();
        break;
      case MANAGER_STATES.PROPOSING:
        // Auto-approve if enabled
        if (this.autoApprove && this.currentPlans && this.currentPlans.length > 0) {
          const selectedPlanIndex = this.autoSelectPlan();
          console.log(`🤖 [${this.name}] Auto-approving plan ${selectedPlanIndex + 1} (AUTO mode enabled)`);
          this.approvePlan(selectedPlanIndex);
        }
        // Otherwise waiting for player approval
        break;
      case MANAGER_STATES.APPROVED:
        // Plan approved, ready to start building
        this.startBuilding();
        break;
      case MANAGER_STATES.BUILDING:
        this.updateBuildingThrottled(deltaTime);
        break;
    }
  }
  
  /**
   * Smoothly interpolate position towards target
   */
  updatePositionInterpolation() {
    // Don't interpolate if we don't have a target
    if (!this.targetPosition) return;
    
    // Always ensure position exists and is valid
    if (!this.position || this.position.x == null || this.position.y == null) {
      this.position = { x: this.targetPosition.x, y: this.targetPosition.y };
      return;
    }
    
    // Interpolate towards target
    const dx = this.targetPosition.x - this.position.x;
    const dy = this.targetPosition.y - this.position.y;
    
    // If very close, snap to target
    if (Math.abs(dx) < 0.01 && Math.abs(dy) < 0.01) {
      this.position.x = this.targetPosition.x;
      this.position.y = this.targetPosition.y;
    } else {
      // Smooth interpolation - apply game speed multiplier
      const adjustedMoveSpeed = this.moveSpeed * this.state.gameSpeed;
      this.position.x += dx * adjustedMoveSpeed;
      this.position.y += dy * adjustedMoveSpeed;
    }
  }
  
  /**
   * Set target position for smooth movement
   */
  setTargetPosition(x, y) {
    // Always ensure position is initialized
    if (!this.position) {
      this.position = { x, y };
      console.log(`✅ [${this.name}] Position initialized at (${x}, ${y})`);
    }
    
    if (!this.targetPosition) {
      this.targetPosition = { x, y };
    } else {
      this.targetPosition.x = x;
      this.targetPosition.y = y;
    }
  }

  /**
   * Throttled building update - 1 tile per second
   */
  updateBuildingThrottled(deltaTime) {
    if (!this.buildTimer) {
      this.buildTimer = 0;
    }

    this.buildTimer += deltaTime;

    // Build 1 tile per second (1000ms)
    if (this.buildTimer >= 1000) {
      this.buildTimer -= 1000;
      this.updateBuilding(deltaTime);
    }
  }

  /**
   * Idle state - check if should generate new plan
   */
  updateIdle() {
    const now = Date.now();
    const timeSinceLastPlan = now - this.lastPlanTime;
    
    // Check cooldown
    if (timeSinceLastPlan < this.planCooldown) {
      return;
    }
    
    // Generate new plan based on efficiency
    const shouldGeneratePlan = Math.random() * 100 < this.efficiency;
    
    if (shouldGeneratePlan) {
      this.generatePlan();
    }
  }

  /**
   * Generate 3 construction plans for player to choose from
   * Every manager proposal should offer 3 choices
   * Plan 1 = Tier 1 ($200-500K), Plan 2 = Tier 2 ($600-800K), Plan 3 = Tier 3 ($900K-1.5M)
   * 
   * EARLY GAME RULE: First 2 years, one plan is ALWAYS residential
   */
  generatePlan() {
    console.log(`${this.name} generating 3 plans...`);
    
    // Check if we're in the first 2 years (game starts at year 2030, so < 2032)
    const isEarlyGame = this.state.year < 2032;
    const forceResidentialIndex = isEarlyGame ? 0 : -1; // Force plan 0 (Tier 1) to be residential in early game
    
    if (isEarlyGame) {
      console.log(`🏠 Early game detected (Year ${this.state.year}) - Plan 1 will be RESIDENTIAL`);
    }
    
    const plans = [];
    for (let i = 0; i < 3; i++) {
      const forceResidential = (i === forceResidentialIndex);
      
      const plan = PlanGenerator.generatePlan(
        {
          id: this.managerId,
          name: this.name,
          build_preferences: this.buildPreferences,
          // Road continuation system properties
          lastRoadEndpoint: this.lastRoadEndpoint,
          originalEntryPoint: this.originalEntryPoint,
          hasReachedCenter: this.hasReachedCenter
        },
        this.state,
        this.gridManager,
        i, // Pass tier index: 0=Tier1, 1=Tier2, 2=Tier3
        forceResidential // Force residential for plan 0 during first 2 years
      );
      
      if (plan) {
        plans.push(plan);
      }
    }
    
    if (plans.length > 0) {
      this.currentPlans = plans;
      this.currentState = MANAGER_STATES.PROPOSING;
      this.lastPlanTime = Date.now();
      
      // Emit event with all 3 plans
      this.state.emit('manager-action', {
        action: 'plan-proposed',
        managerName: this.name,
        managerId: this.managerId,
        plans: plans
      });
    }
  }

  /**
   * Generate 3 initial plans for player to choose from
   * Plan 1 = Tier 1 ($200-500K), Plan 2 = Tier 2 ($600-800K), Plan 3 = Tier 3 ($900K-1.5M)
   * 
   * EARLY GAME RULE: First 2 years, one plan is ALWAYS residential
   */
  generateInitialPlans() {
    // Check if we're in the first 2 years (game starts at year 2030, so < 2032)
    const isEarlyGame = this.state.year < 2032;
    const forceResidentialIndex = isEarlyGame ? 0 : -1; // Force plan 0 (Tier 1) to be residential in early game
    
    const plans = [];
    for (let i = 0; i < 3; i++) {
      const forceResidential = (i === forceResidentialIndex);
      
      const plan = PlanGenerator.generatePlan(
        {
          id: this.managerId,
          name: this.name,
          build_preferences: this.buildPreferences,
          // Road continuation system properties
          lastRoadEndpoint: this.lastRoadEndpoint,
          originalEntryPoint: this.originalEntryPoint,
          hasReachedCenter: this.hasReachedCenter
        },
        this.state,
        this.gridManager,
        i, // Pass tier index: 0=Tier1, 1=Tier2, 2=Tier3
        forceResidential // Force residential for plan 0 during first 2 years
      );
      
      if (plan) {
        plans.push(plan);
      }
    }
    
    if (plans.length > 0) {
      this.currentPlans = plans;
      this.currentState = MANAGER_STATES.PROPOSING;
      this.lastPlanTime = Date.now();
      
      // Set position to entry point of first plan so arrow appears immediately
      if (plans[0] && plans[0].entryPoint) {
        this.position = { x: plans[0].entryPoint.x, y: plans[0].entryPoint.y };
        this.targetPosition = { x: plans[0].entryPoint.x, y: plans[0].entryPoint.y };
      }
      
      // Emit event with all 3 plans
      this.state.emit('manager-action', {
        action: 'initial-plans-proposed',
        managerName: this.name,
        managerId: this.managerId,
        plans: plans
      });
    }
  }

  /**
   * Player approves a plan (supports selecting from multiple plans)
   */
  approvePlan(planIndex = 0) {
    if (this.currentState !== MANAGER_STATES.PROPOSING) {
      console.error(`❌ Cannot approve - manager not in proposing state for ${this.name}`);
      return false;
    }
    
    // Select the plan from currentPlans or currentPlan
    let selectedPlan = null;
    if (this.currentPlans && this.currentPlans.length > 0) {
      selectedPlan = this.currentPlans[planIndex] || this.currentPlans[0];
      // Clear other plans and set this as current
      this.currentPlan = selectedPlan;
      this.currentPlans = null;
    } else if (this.currentPlan) {
      selectedPlan = this.currentPlan;
    } else {
      console.error(`❌ Cannot approve - no plan pending for ${this.name}`);
      return false;
    }
    
    // Check if can afford
    if (!this.state.canAfford(selectedPlan.totalCost)) {
      console.error(`❌ Cannot afford plan: $${selectedPlan.totalCost}`);
      this.state.addNotification(`Cannot afford ${this.name}'s plan!`, 'error');
      return false;
    }
    
    // Deduct cost
    this.state.subtractBudget(selectedPlan.totalCost);
    
    // Update happiness and efficiency
    this.happiness = Math.min(100, this.happiness + 5);
    this.efficiency = Math.min(100, this.efficiency + 2);
    
    this.currentState = MANAGER_STATES.APPROVED;
    
    // Emit event
    this.state.emit('manager-action', {
      action: 'plan-approved',
      managerName: this.name,
      managerId: this.managerId,
      planName: selectedPlan.name
    });
    
    return true;
  }

  /**
   * Player denies the plan(s)
   */
  denyPlan() {
    if (this.currentState !== MANAGER_STATES.PROPOSING) {
      return false;
    }
    
    // Update happiness (decrease)
    this.happiness = Math.max(0, this.happiness - 10);
    
    // Emit event
    this.state.emit('manager-action', {
      action: 'plan-denied',
      managerName: this.name,
      managerId: this.managerId
    });
    
    // Return to idle
    this.currentPlan = null;
    this.currentPlans = null;
    this.currentState = MANAGER_STATES.IDLE;
    
    return true;
  }

  /**
   * Start building phase
   */
  startBuilding() {
    console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
    console.log(`🏗️ ${this.name} startBuilding() called`);
    
    if (!this.currentPlan) {
      console.error(`❌ ${this.name}: No plan to build!`);
      console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
      return;
    }
    
    // CRITICAL: Change state immediately to prevent being called multiple times
    // while async imports are loading
    if (this.currentState === MANAGER_STATES.APPROVED) {
      this.currentState = MANAGER_STATES.BUILDING; // Transition immediately
      console.log(`✓ State changed from APPROVED → BUILDING (prevents re-entry)`);
    }
    
    console.log(`✓ Current plan:`, this.currentPlan);
    console.log(`✓ Entry point: (${this.currentPlan.entryPoint.x}, ${this.currentPlan.entryPoint.y})`);
    console.log(`✓ Building: ${this.currentPlan.buildingName} (ID: ${this.currentPlan.buildingId})`);
    console.log(`✓ Count: ${this.currentPlan.buildingCount}`);
    
    // Import RoadBuilder and BuildingPlacer (NO MORE HARDCODED BUILDING DATA)
    import('../services/RoadBuilder.js').then(({ RoadBuilder }) => {
      console.log(`✓ RoadBuilder imported`);
      import('../services/BuildingPlacer.js').then(({ BuildingPlacer }) => {
        console.log(`✓ BuildingPlacer imported`);
        
        this.RoadBuilder = RoadBuilder;
        this.BuildingPlacer = BuildingPlacer;
        
        // FIXED PROBLEM #2: Set entity position to entry point (snap immediately)
        // Position already set during generateInitialPlans(), just ensure it's correct
        if (!this.position || this.position.x === -1000) {
          this.position = { x: this.currentPlan.entryPoint.x, y: this.currentPlan.entryPoint.y };
          this.targetPosition = { x: this.currentPlan.entryPoint.x, y: this.currentPlan.entryPoint.y };
          console.log(`✓ Manager position set to entry point (instant):`, this.position);
        }
        
        // Get building data FROM PLAN (which read it from TMJ)
        const buildingSize = this.currentPlan.buildingSize;
        const buildingType = this.currentPlan.buildingType;
        const buildingName = this.currentPlan.buildingName;
        const tmjBuilding = this.currentPlan.tmjBuilding;
        
        if (!buildingSize || !tmjBuilding) {
          console.error(`❌ Building data missing from plan!`);
          console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
          this.completeBuilding();
          return;
        }
        
        console.log(`✓ Building from TMJ: ${buildingName}`);
        console.log(`   Structure size: ${buildingSize} tiles per structure`);
        console.log(`   Building count: ${this.currentPlan.buildingCount} structures`);
        console.log(`   Total tiles to place: ${buildingSize * this.currentPlan.buildingCount}`);
      
        // Cap road length at 30 tiles maximum
        const calculatedRoadLength = this.currentPlan.buildingCount * buildingSize * 2;
        const roadLength = Math.min(calculatedRoadLength, 30);
          console.log(`🛣️ Generating road path with target length: ${roadLength} (calculated: ${calculatedRoadLength}, capped at 30)`);
          console.log(`   hasReachedCenter: ${this.hasReachedCenter}`);
          console.log(`   Build preferences:`, this.buildPreferences);
          
          const roadPath = RoadBuilder.generateRoadPath(
            this.currentPlan.entryPoint,
            roadLength,
            this.gridManager,
            this.hasReachedCenter,  // Pass center-reached flag
            this.buildPreferences    // Pass manager's zone preferences
          );
          
          console.log(`✓ Road path generated: ${roadPath.length} tiles`);
          
          if (roadPath.length === 0) {
            console.error(`❌ Road path is EMPTY! Cannot build.`);
            console.log(`   Entry point: (${this.currentPlan.entryPoint.x}, ${this.currentPlan.entryPoint.y})`);
            console.log(`   Checking if entry point is buildable...`);
            const isBuildable = this.gridManager.isBuildable(this.currentPlan.entryPoint.x, this.currentPlan.entryPoint.y);
            console.log(`   Entry point buildable: ${isBuildable}`);
            if (!isBuildable) {
              const terrain = this.gridManager.getTerrainAt(this.currentPlan.entryPoint.x, this.currentPlan.entryPoint.y);
              console.log(`   Terrain data:`, terrain);
            }
            console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
            this.completeBuilding();
            return;
          }
          
        // Find building positions
        console.log(`🏢 Finding building positions along road...`);
        const buildingPositions = RoadBuilder.findBuildingPositions(
          roadPath,
          buildingSize,
          this.currentPlan.buildingCount,
          this.gridManager
        );
          
          console.log(`✓ Found ${buildingPositions.length} building positions (requested: ${this.currentPlan.buildingCount})`);
          
          // Initialize build progress (even if no buildings - still place roads!)
          // totalSteps = road tiles + number of buildings (not tiles per building)
          this.buildProgress = {
            roadPath: roadPath,
            buildingPositions: buildingPositions,
            currentStep: 0,
            totalSteps: roadPath.length + buildingPositions.length, // Each building counts as 1 step
            phase: 'roads', // roads, buildings, complete
            roadIndex: 0,
            buildingIndex: 0
          };
          
          if (buildingPositions.length === 0) {
            console.warn(`⚠️ No building positions found! Will build roads only.`);
          }
          
          console.log(`✅ ${this.name} ready to build`);
          console.log(`   Total steps: ${this.buildProgress.totalSteps} (${roadPath.length} roads + ${buildingPositions.length} buildings)`);
          console.log(`   Starting phase: roads`);
          console.log(`━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`);
      });
    });
  }

  /**
   * Calculate road orientation based on neighboring tiles
   * SIMPLIFIED: Just check which directions connect to this tile
   */
  calculateRoadOrientation(roadPath, index) {
    const current = roadPath[index];
    const prev = index > 0 ? roadPath[index - 1] : null;
    const next = index < roadPath.length - 1 ? roadPath[index + 1] : null;

    // Check which directions have connections
    // Y coordinates: smaller Y = top/north, larger Y = bottom/south
    // X coordinates: smaller X = left/west, larger X = right/east
    let hasNorth = false, hasSouth = false, hasEast = false, hasWest = false;

    // Check previous tile
    if (prev) {
      if (prev.y < current.y) hasNorth = true;  // prev is north (above)
      if (prev.y > current.y) hasSouth = true;  // prev is south (below)
      if (prev.x < current.x) hasWest = true;   // prev is west (left)
      if (prev.x > current.x) hasEast = true;   // prev is east (right)
    }

    // Check next tile
    if (next) {
      if (next.y < current.y) hasNorth = true;  // next is north (above)
      if (next.y > current.y) hasSouth = true;  // next is south (below)
      if (next.x < current.x) hasWest = true;   // next is west (left)
      if (next.x > current.x) hasEast = true;   // next is east (right)
    }

    // Count connections
    const connections = [hasNorth, hasSouth, hasEast, hasWest].filter(Boolean).length;

    // Return orientation based on connections
    if (connections >= 3) {
      return 'cross';
    } else if (connections === 2) {
      // Check if straight or corner
      if (hasNorth && hasSouth) return 'vertical';
      if (hasEast && hasWest) return 'horizontal';
      
      // Corner tiles
      if (hasNorth && hasEast) return 'corner_top_right';
      if (hasNorth && hasWest) return 'corner_top_left';
      if (hasSouth && hasEast) return 'corner_bottom_right';
      if (hasSouth && hasWest) return 'corner_bottom_left';
    } else if (connections === 1) {
      // Dead end
      if (hasNorth || hasSouth) return 'vertical';
      if (hasEast || hasWest) return 'horizontal';
    }

    return 'vertical';
  }

  /**
   * Update building phase - step by step construction
   * TWO-PHASE SYSTEM: 1 second construction tile + 1 second final tile
   */
  updateBuilding(deltaTime) {
    if (!this.buildProgress || !this.RoadBuilder || !this.BuildingPlacer) {
      console.warn(`⚠️ ${this.name} updateBuilding() called but missing dependencies:`,
        `buildProgress: ${!!this.buildProgress}, RoadBuilder: ${!!this.RoadBuilder}, BuildingPlacer: ${!!this.BuildingPlacer}`);
      return;
    }

    const { phase, roadPath, buildingPositions, roadIndex, buildingIndex } = this.buildProgress;

    // Check if we're waiting for construction delay
    if (this.buildProgress.constructionStartTime) {
      const elapsed = Date.now() - this.buildProgress.constructionStartTime;
      // Apply game speed: duration = base / speed (0.5x = 2000ms, 1.0x = 1000ms, 2.0x = 500ms)
      const constructionDuration = 1000 / this.state.gameSpeed;
      if (elapsed < constructionDuration) {
        // Still in construction phase, wait
        return;
      }
      // Construction phase complete, clear timer and proceed to place final tile
      this.buildProgress.constructionStartTime = null;
    }

    if (phase === 'roads') {
      // Build roads one tile at a time (2-second process each)
      if (roadIndex < roadPath.length) {
        const tile = roadPath[roadIndex];
        
        // Check if road already exists at this tile (continuing from existing road)
        const existingRoad = this.gridManager.getRoadAt(tile.x, tile.y);
        
        if (existingRoad && existingRoad.is_road) {
          // Road already exists - just move along it without spending money
          this.setTargetPosition(tile.x, tile.y);
          this.buildProgress.roadIndex++;
          this.buildProgress.currentStep++;
        } else {
          // Start construction tile phase if not started
          if (!this.buildProgress.currentConstructionTile || 
              this.buildProgress.currentConstructionTile.x !== tile.x || 
              this.buildProgress.currentConstructionTile.y !== tile.y) {
            // Start new construction
            console.log(`🚧 ${this.name} starting construction at (${tile.x}, ${tile.y})`);
            this.buildProgress.currentConstructionTile = { x: tile.x, y: tile.y };
            this.buildProgress.constructionStartTime = Date.now();
            
            // Trigger construction effect (construction tile + particles)
            if (this.constructionEffects) {
              const constructionDuration = 1000 / this.state.gameSpeed;
              this.constructionEffects.startConstruction(tile.x, tile.y, 'road', constructionDuration);
            }
            
            this.setTargetPosition(tile.x, tile.y);
            return; // Wait for construction timer
          }
          
          // Construction timer expired, place final road tile
          let orientation = this.calculateRoadOrientation(roadPath, roadIndex);
          
          console.log(`🛣️ ${this.name} placing NEW road tile ${roadIndex + 1}/${roadPath.length} at (${tile.x}, ${tile.y}) - ${orientation}`);
          
          // End construction tile display immediately before placing real tile
          if (this.constructionEffects) {
            this.constructionEffects.endConstruction(tile.x, tile.y);
          }
          
          // Play road construction sound 3 times with randomized volume
          if (this.soundManager) {
            const baseVolume = this.calculateVolumeMultiplier(tile.x, tile.y);
            
            // Play 3 instances with slight delays and volume variation
            for (let i = 0; i < 3; i++) {
              setTimeout(() => {
                // Random volume variation: ±20% (0.8 to 1.2)
                const volumeVariation = 0.8 + Math.random() * 0.4;
                this.soundManager.playRoad(baseVolume * volumeVariation);
              }, i * 666); // Spread over ~2 seconds (0ms, 666ms, 1332ms)
            }
          }
          
          this.gridManager.placeRoad(tile.x, tile.y, 1.0, orientation);
          
          // Trigger pop-in animation
          if (this.constructionEffects) {
            this.constructionEffects.startPopAnimation(tile.x, tile.y);
          }
          
          this.buildProgress.currentConstructionTile = null;
          this.buildProgress.roadIndex++;
          this.buildProgress.currentStep++;
        }
        
        if (this.buildProgress.roadIndex >= roadPath.length) {
          // Finished roads, start buildings
          console.log(`✅ ${this.name} completed all roads! Moving to building phase...`);
          this.buildProgress.phase = 'buildings';
          
          if (buildingPositions.length === 0) {
            console.log(`⚠️ No buildings to place, completing...`);
            this.buildProgress.phase = 'complete';
            this.completeBuilding();
          }
        }
      }
    } else if (phase === 'buildings') {
      // Place buildings one at a time (2-second process each)
      if (buildingIndex < buildingPositions.length) {
        const pos = buildingPositions[buildingIndex];
        
        // Start construction tile phase if not started
        if (!this.buildProgress.currentConstructionTile || 
            this.buildProgress.currentConstructionTile.x !== pos.x || 
            this.buildProgress.currentConstructionTile.y !== pos.y) {
          // Start new construction
          console.log(`🚧 ${this.name} starting construction at (${pos.x}, ${pos.y})`);
          this.buildProgress.currentConstructionTile = { x: pos.x, y: pos.y };
          this.buildProgress.constructionStartTime = Date.now();
          
          // Trigger construction effect
          if (this.constructionEffects) {
            const constructionDuration = 1000 / this.state.gameSpeed;
            this.constructionEffects.startConstruction(pos.x, pos.y, 'building', constructionDuration);
          }
          
          this.setTargetPosition(pos.x, pos.y);
          return; // Wait for construction timer
        }
        
        // Construction timer expired, place final building
        console.log(`🏢 ${this.name} placing building ${buildingIndex + 1}/${buildingPositions.length} at (${pos.x}, ${pos.y})`);
        
        // End construction tile display immediately before placing real tile
        if (this.constructionEffects) {
          this.constructionEffects.endConstruction(pos.x, pos.y);
        }
        
        // Play structure construction sound with viewport-based volume
        if (this.soundManager) {
          const volumeMultiplier = this.calculateVolumeMultiplier(pos.x, pos.y);
          this.soundManager.playStructure(volumeMultiplier);
        }
        
        this.BuildingPlacer.placeBuilding(
          pos.x,
          pos.y,
          this.currentPlan, // Pass entire plan with TMJ data
          this.managerId,
          this.gridManager,
          this.state
        );
        
        // Trigger pop-in animation
        if (this.constructionEffects) {
          this.constructionEffects.startPopAnimation(pos.x, pos.y);
        }
        
        this.buildProgress.currentConstructionTile = null;
        this.buildProgress.buildingIndex++;
        this.buildProgress.currentStep++;
        
        if (this.buildProgress.buildingIndex >= buildingPositions.length) {
          // Finished all buildings
          console.log(`✅ ${this.name} completed all buildings!`);
          this.buildProgress.phase = 'complete';
          this.completeBuilding();
        }
      } else {
        this.buildProgress.phase = 'complete';
        this.completeBuilding();
      }
    }
  }

  /**
   * Complete building phase
   */
  completeBuilding() {
    console.log(`${this.name} completed construction!`);
    
    // ROAD CONTINUATION SYSTEM: Store last road endpoint for next plan
    if (this.buildProgress && this.buildProgress.roadPath && this.buildProgress.roadPath.length > 0) {
      const roadPath = this.buildProgress.roadPath;
      this.lastRoadEndpoint = { ...roadPath[roadPath.length - 1] };
      
      // KEEP position at last location so arrow stays visible
      this.setTargetPosition(this.lastRoadEndpoint.x, this.lastRoadEndpoint.y);
      console.log(`📍 ${this.name} target position kept at last endpoint: (${this.targetPosition.x}, ${this.targetPosition.y})`);
      
      // Check if manager reached center (50, 50) or attempted to
      const reachedCenter = roadPath.some(tile => 
        tile.x === 50 && tile.y === 50
      );
      
      if (reachedCenter && !this.hasReachedCenter) {
        this.hasReachedCenter = true;
        console.log(`🎯 ${this.name} has REACHED THE CENTER! Now will prioritize zone tiles over center.`);
      }
      
      // Check if manager tried to build on center but it was occupied
      if (!this.hasReachedCenter) {
        // Check if last tile is very close to center and there's a road at center
        const lastTile = roadPath[roadPath.length - 1];
        const distToCenter = Math.abs(lastTile.x - 50) + Math.abs(lastTile.y - 50);
        const centerHasRoad = this.gridManager.getRoadAt(50, 50);
        
        if (distToCenter <= 2 && centerHasRoad) {
          this.hasReachedCenter = true;
          console.log(`🎯 ${this.name} attempted to reach center but found existing road! Now will prioritize zone tiles.`);
        }
      }
    }
    
    // Store original entry point if this was first plan
    if (!this.originalEntryPoint && this.currentPlan && this.currentPlan.entryPoint) {
      this.originalEntryPoint = { ...this.currentPlan.entryPoint };
      console.log(`🚩 ${this.name} original entry point reserved: (${this.originalEntryPoint.x}, ${this.originalEntryPoint.y})`);
    }
    
    // Add notification
    this.state.addNotification(
      `${this.name} completed ${this.currentPlan.buildingCount}x ${this.currentPlan.buildingName}!`,
      'success'
    );
    
    // Reset state (but KEEP position so arrow stays visible)
    this.currentPlan = null;
    this.currentState = MANAGER_STATES.IDLE;
  }

  /**
   * Give manager a raise
   */
  giveRaise(amount) {
    this.raises++;
    this.happiness = Math.min(100, this.happiness + 5);
    
    // Emit event
    this.state.emit('manager-action', {
      action: 'manager-raise',
      managerName: this.name,
      managerId: this.managerId
    });
  }

  /**
   * Fire manager
   */
  fire() {
    // Refund remaining budget if building
    if (this.currentPlan && this.currentState === MANAGER_STATES.BUILDING) {
      // Calculate refund
      const refund = this.currentPlan.totalCost * 0.5; // 50% refund
      this.state.addBudget(refund);
    }
    
    // Emit event
    this.state.emit('manager-action', {
      action: 'manager-fired',
      managerName: this.name,
      managerId: this.managerId
    });
  }

  /**
   * Reset manager to their original starting position
   * Completes current plan and returns to idle state
   */
  resetToStart() {
    console.log(`🔄 Resetting ${this.name} to starting position`);
    console.log(`  Current state: ${this.currentState}`);
    console.log(`  Current position: (${this.position.x}, ${this.position.y})`);
    console.log(`  Original entry point: ${this.originalEntryPoint ? `(${this.originalEntryPoint.x}, ${this.originalEntryPoint.y})` : 'NOT SET'}`);
    
    // If we have a current plan with an entry point but no originalEntryPoint, use the plan's entry point
    if (!this.originalEntryPoint && this.currentPlan && this.currentPlan.entryPoint) {
      this.originalEntryPoint = { ...this.currentPlan.entryPoint };
      console.log(`  ℹ️ Using current plan's entry point as original: (${this.originalEntryPoint.x}, ${this.originalEntryPoint.y})`);
    }
    
    // Complete any current plan
    if (this.currentPlan) {
      console.log(`  ✓ Clearing current plan: ${this.currentPlan.buildingName}`);
      this.currentPlan = null;
      this.currentPlans = null;
    }
    
    // Reset to idle state
    this.currentState = MANAGER_STATES.IDLE;
    
    // Reset position to original entry point
    if (this.originalEntryPoint) {
      this.position = { ...this.originalEntryPoint };
      this.targetPosition = { ...this.originalEntryPoint };
      console.log(`  ✓ Reset position to (${this.originalEntryPoint.x}, ${this.originalEntryPoint.y})`);
    } else {
      // If no original entry point, move far off-screen
      this.position = { x: -1000, y: -1000 };
      this.targetPosition = { x: -1000, y: -1000 };
      console.log(`  ⚠️ No original entry point, moved off-screen`);
    }
    
    // Clear building progress
    this.buildProgress = {
      roadTiles: [],
      buildings: [],
      currentStep: 0,
      totalSteps: 0
    };
    
    // Reset road continuation system
    this.lastRoadEndpoint = this.originalEntryPoint ? { ...this.originalEntryPoint } : null;
    
    // Emit event
    this.state.emit('manager-action', {
      action: 'manager-reset',
      managerName: this.name,
      managerId: this.managerId
    });
    
    console.log(`  ✓ ${this.name} reset complete - now idle at starting position`);
    console.log(`  New position: (${this.position.x}, ${this.position.y})`);
    console.log(`  New state: ${this.currentState}`);
  }

  /**
   * Get current status string
   */
  getStatus() {
    switch (this.currentState) {
      case MANAGER_STATES.IDLE:
        return 'Idle';
      case MANAGER_STATES.PROPOSING:
        return 'Proposing';
      case MANAGER_STATES.APPROVED:
        return 'Approved';
      case MANAGER_STATES.BUILDING:
        return `Building (${this.buildProgress.currentStep}/${this.buildProgress.totalSteps})`;
      default:
        return 'Unknown';
    }
  }

  /**
   * Get serializable data
   */
  getData() {
    return {
      id: this.managerId,
      name: this.name,
      specialty: this.specialty,
      happiness: this.happiness,
      efficiency: this.efficiency,
      raises: this.raises,
      autoApprove: this.autoApprove,
      state: this.currentState,
      status: this.getStatus(),
      currentPlan: this.currentPlan,
      currentPlans: this.currentPlans,
      position: this.position,
      targetPosition: this.targetPosition,
      // Road continuation system
      originalEntryPoint: this.originalEntryPoint,
      lastRoadEndpoint: this.lastRoadEndpoint,
      hasReachedCenter: this.hasReachedCenter,
      // Building progress for saves
      buildProgress: this.buildProgress
    };
  }
  
  /**
   * Toggle auto-approval mode
   */
  toggleAutoApprove() {
    this.autoApprove = !this.autoApprove;
    return this.autoApprove;
  }
  
  /**
   * Auto-select a plan based on manager's preferences
   * 80% chance to pick preference, 10% for each other option
   */
  autoSelectPlan() {
    if (!this.currentPlans || this.currentPlans.length === 0) {
      return 0; // Default to first plan
    }
    
    // buildPreferences is an object like { residential: 0.5, commercial: 0.2, ... }
    // Find the plan with the highest preference weight
    let preferredIndex = -1;
    let highestWeight = -1;
    
    for (let i = 0; i < this.currentPlans.length; i++) {
      const plan = this.currentPlans[i];
      const planType = plan.buildingType; // 'residential', 'commercial', 'industrial', etc.
      const weight = this.buildPreferences[planType] || 0;
      
      if (weight > highestWeight) {
        highestWeight = weight;
        preferredIndex = i;
      }
    }
    
    const random = Math.random();
    
    // 80% chance: pick preferred plan (if found)
    if (random < 0.8 && preferredIndex !== -1) {
      return preferredIndex;
    }
    
    // 20% chance: pick one of the other plans randomly
    const otherIndices = this.currentPlans
      .map((_, index) => index)
      .filter(index => index !== preferredIndex);
    
    if (otherIndices.length > 0) {
      return otherIndices[Math.floor(Math.random() * otherIndices.length)];
    }
    
    // Fallback: return preferred or 0
    return preferredIndex !== -1 ? preferredIndex : 0;
  }
}
