/**
 * ManagerCoordinator.js
 * Coordinates all active manager AI instances
 * Updates them each frame and manages their lifecycle
 */

import { ManagerAI } from './ManagerAI.js';
import { ConstructionEffects } from '../services/ConstructionEffects.js';

export class ManagerCoordinator {
  constructor(gameState, gridManager, soundManager = null) {
    this.state = gameState;
    this.gridManager = gridManager;
    this.soundManager = soundManager;
    this.managers = [];
    this.lastUpdate = Date.now();
    
    // Shared construction effects manager (pass gameState for speed access)
    this.constructionEffects = new ConstructionEffects(gameState);
    
    console.log('ManagerCoordinator initialized');
  }

  /**
   * Add a manager to active management
   */
  addManager(managerId) {
    // Check if already exists
    if (this.managers.find(m => m.managerId === managerId)) {
      console.warn(`Manager ${managerId} already active`);
      return null;
    }

    const managerAI = new ManagerAI(managerId, this.state, this.gridManager, this.constructionEffects, this.soundManager);
    this.managers.push(managerAI);
    
    console.log(`Added manager: ${managerAI.name}`);
    return managerAI;
  }

  /**
   * Remove a manager
   */
  removeManager(managerId) {
    const index = this.managers.findIndex(m => m.managerId === managerId);
    if (index === -1) return false;

    const manager = this.managers[index];
    manager.fire();
    this.managers.splice(index, 1);
    
    return true;
  }

  /**
   * Get manager AI instance by ID
   */
  getManager(managerId) {
    return this.managers.find(m => m.managerId === managerId);
  }

  /**
   * Get all managers
   */
  getAllManagers() {
    return this.managers;
  }

  /**
   * Update all managers and construction effects
   */
  update() {
    const now = Date.now();
    const deltaTime = now - this.lastUpdate;
    this.lastUpdate = now;

    // Cap deltaTime to prevent huge jumps
    const cappedDelta = Math.min(deltaTime, 100);

    // Update construction effects (particles)
    this.constructionEffects.update(cappedDelta);

    for (const manager of this.managers) {
      manager.update(cappedDelta);
    }
  }

  /**
   * Get managers with pending plans
   */
  getManagersWithPlans() {
    return this.managers.filter(m => m.currentState === 'proposing');
  }

  /**
   * Get managers currently building
   */
  getBuildingManagers() {
    return this.managers.filter(m => m.currentState === 'building');
  }

  /**
   * Get all manager data for UI
   */
  getManagersData() {
    return this.managers.map(m => m.getData());
  }

  /**
   * Trigger initial plan generation for first manager (called 3 seconds after game start)
   */
  triggerInitialPlans() {
    if (this.managers.length > 0) {
      const firstManager = this.managers[0];
      firstManager.generateInitialPlans();
      console.log(`Triggered initial plans for ${firstManager.name}`);
    }
  }
}
