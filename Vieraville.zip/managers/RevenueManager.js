/**
 * RevenueManager.js
 * Calculates monthly revenue and expenses from all buildings
 * Applies seasonal multipliers, manager bonuses, and employment rates
 * Buildings need workers to generate revenue!
 */

import { BUILDINGS } from '../constants/buildingData.js';
import { EmploymentManager } from './EmploymentManager.js';

export class RevenueManager {
  constructor(gameState) {
    this.state = gameState;
    this.employmentManager = new EmploymentManager(gameState);
  }

  /**
   * Calculate monthly revenue from all buildings
   * Called at the end of each month
   * EMPLOYMENT SYSTEM: Buildings need workers to generate revenue!
   */
  calculateMonthlyRevenue() {
    const gridManager = this.state.getGridManager();
    if (!gridManager) return { revenue: 0, expenses: 0, net: 0, breakdown: [] };

    // First, distribute employment across all buildings
    const employmentStats = this.employmentManager.distributeEmployment();

    const currentMonth = this.state.getCurrentMonth();
    const currentSeason = this.state.getCurrentSeason();
    
    let totalRevenue = 0;
    let totalExpenses = 0;
    const breakdown = [];
    const seenBuildings = new Set(); // Track buildings we've already counted

    // Scan all building tiles
    for (let y = 0; y < 100; y++) {
      for (let x = 0; x < 100; x++) {
        const building = gridManager.getBuildingAt(x, y);
        if (!building || !building.building_id) continue;

        // Skip if we've already counted this building
        if (seenBuildings.has(building.building_id)) continue;
        seenBuildings.add(building.building_id);

        // Base monthly revenue (from building instance, not definition)
        let baseRevenue = building.revenue_base || 0;

        // Get employment rate for this building
        const employmentRate = this.employmentManager.getBuildingEmploymentRate(building);

        // EMPLOYMENT MECHANIC:
        // - Buildings with jobs scale revenue by employment rate
        // - 100% employed = 100% revenue
        // - 50% employed = 50% revenue
        // - 0% employed = 0% revenue + 50% upkeep cost
        let revenue = 0;
        let expenses = 0;

        if (building.jobs_available && building.jobs_available > 0) {
          // This building requires workers
          if (employmentRate === 0) {
            // No workers: Pay 50% upkeep cost, no revenue
            revenue = 0;
            expenses = baseRevenue * 0.5;
          } else {
            // Has workers: Revenue scales with employment rate
            revenue = baseRevenue * employmentRate;
            expenses = revenue * 0.1; // 10% operating expenses
          }
        } else {
          // Building doesn't require workers (e.g., residential, some amenities)
          revenue = baseRevenue;
          expenses = revenue * 0.1;
        }

        // Apply seasonal multiplier (if building has seasonal data)
        const seasonalMultiplier = 1.0; // TODO: Add seasonal multipliers to building instances
        revenue *= seasonalMultiplier;

        // Apply manager bonus (if building was built by a manager)
        if (building.owner_manager) {
          const manager = this.state.managers.find(m => m.id === building.owner_manager);
          if (manager) {
            const managerBonus = this.getManagerBonus(manager, building);
            revenue *= managerBonus;
          }
        }

        totalRevenue += revenue;
        totalExpenses += expenses;

        // Track for breakdown
        breakdown.push({
          buildingId: building.building_id,
          buildingName: building.name,
          position: { x, y },
          revenue: Math.round(revenue),
          expenses: Math.round(expenses),
          net: Math.round(revenue - expenses),
          employmentRate: employmentRate,
          seasonalMultiplier: seasonalMultiplier
        });
      }
    }

    const netRevenue = totalRevenue - totalExpenses;

    // Update game state budget
    this.state.budget += netRevenue;
    
    // Track total earned (only positive revenue, not losses)
    if (netRevenue > 0) {
      this.state.totalEarned += netRevenue;
    }

    console.log(`💰 Revenue Calculated - Revenue: $${Math.round(totalRevenue)}, Expenses: $${Math.round(totalExpenses)}, Net: $${Math.round(netRevenue)}`);

    return {
      revenue: Math.round(totalRevenue),
      expenses: Math.round(totalExpenses),
      net: Math.round(netRevenue),
      breakdown: breakdown,
      employmentStats: employmentStats
    };
  }

  /**
   * Get seasonal multiplier for a building
   */
  getSeasonalMultiplier(buildingDef, season) {
    if (!buildingDef.seasonal_multipliers) return 1.0;
    
    const multipliers = buildingDef.seasonal_multipliers;
    
    switch (season) {
      case 'spring':
        return multipliers.spring || 1.0;
      case 'summer':
        return multipliers.summer || 1.0;
      case 'fall':
        return multipliers.fall || 1.0;
      case 'winter':
        return multipliers.winter || 1.0;
      default:
        return 1.0;
    }
  }

  /**
   * Get manager bonus multiplier based on specialization
   */
  getManagerBonus(manager, building) {
    // Base multiplier
    let bonus = 1.0;

    // Check if building type matches manager specialty
    if (manager.specialty === building.building_type) {
      // 20% bonus for matching specialty
      bonus += 0.2;
    }

    // Apply manager efficiency stat (ranges from 0.5 to 2.0)
    if (manager.efficiency) {
      bonus *= manager.efficiency;
    }

    return bonus;
  }

  /**
   * Get total monthly revenue estimate (without actually applying it)
   * Includes employment calculations
   */
  estimateMonthlyRevenue() {
    const gridManager = this.state.getGridManager();
    if (!gridManager) return 0;

    // Distribute employment to get current employment rates
    this.employmentManager.distributeEmployment();

    const currentSeason = this.state.getCurrentSeason();
    let totalRevenue = 0;
    let totalExpenses = 0;
    const seenBuildings = new Set();

    for (let y = 0; y < 100; y++) {
      for (let x = 0; x < 100; x++) {
        const building = gridManager.getBuildingAt(x, y);
        if (!building || !building.building_id) continue;

        // Skip if we've already counted this building
        if (seenBuildings.has(building.building_id)) continue;
        seenBuildings.add(building.building_id);

        let baseRevenue = building.revenue_base || 0;
        const employmentRate = this.employmentManager.getBuildingEmploymentRate(building);
        
        let revenue = 0;
        let expenses = 0;

        // Apply employment mechanic
        if (building.jobs_available && building.jobs_available > 0) {
          if (employmentRate === 0) {
            revenue = 0;
            expenses = baseRevenue * 0.5;
          } else {
            revenue = baseRevenue * employmentRate;
            expenses = revenue * 0.1;
          }
        } else {
          revenue = baseRevenue;
          expenses = revenue * 0.1;
        }

        const seasonalMultiplier = 1.0; // TODO: Add seasonal multipliers
        revenue *= seasonalMultiplier;

        // Apply manager bonus
        if (building.owner_manager) {
          const manager = this.state.managers.find(m => m.id === building.owner_manager);
          if (manager) {
            revenue *= this.getManagerBonus(manager, building);
          }
        }

        totalRevenue += revenue;
        totalExpenses += expenses;
      }
    }

    return Math.round(totalRevenue - totalExpenses);
  }

  /**
   * Get revenue by building type
   */
  getRevenueByType() {
    const gridManager = this.state.getGridManager();
    if (!gridManager) return {};

    const currentSeason = this.state.getCurrentSeason();
    const byType = {};
    const seenBuildings = new Set();

    for (let y = 0; y < 100; y++) {
      for (let x = 0; x < 100; x++) {
        const building = gridManager.getBuildingAt(x, y);
        if (!building || !building.building_id) continue;

        // Skip if we've already counted this building
        if (seenBuildings.has(building.building_id)) continue;
        seenBuildings.add(building.building_id);

        let revenue = building.revenue_base || 0;
        const seasonalMultiplier = 1.0; // TODO: Add seasonal multipliers
        revenue *= seasonalMultiplier;

        if (building.owner_manager) {
          const manager = this.state.managers.find(m => m.id === building.owner_manager);
          if (manager) {
            revenue *= this.getManagerBonus(manager, building);
          }
        }

        revenue *= 0.9; // Subtract expenses

        const type = building.building_type;
        if (type) {
          byType[type] = (byType[type] || 0) + revenue;
        }
      }
    }

    return byType;
  }

  /**
   * Calculate total upkeep costs for unstaffed buildings
   * Returns the total seasonal cost for buildings with 0 employees
   */
  calculateUpkeepCosts() {
    const gridManager = this.state.getGridManager();
    if (!gridManager) return 0;

    // Distribute employment to get current employment rates
    this.employmentManager.distributeEmployment();

    let totalUpkeep = 0;
    const seenBuildings = new Set();

    for (let y = 0; y < 100; y++) {
      for (let x = 0; x < 100; x++) {
        const building = gridManager.getBuildingAt(x, y);
        if (!building || !building.building_id) continue;

        // Skip if we've already counted this building
        if (seenBuildings.has(building.building_id)) continue;
        seenBuildings.add(building.building_id);

        // Only count buildings with jobs that have 0 employees
        if (building.jobs_available && building.jobs_available > 0) {
          const employmentRate = this.employmentManager.getBuildingEmploymentRate(building);
          
          if (employmentRate === 0) {
            // This building has no employees - it costs 50% upkeep
            const upkeepCost = (building.revenue_base || 0) * 0.5;
            totalUpkeep += upkeepCost;
          }
        }
      }
    }

    return Math.round(totalUpkeep);
  }
}
