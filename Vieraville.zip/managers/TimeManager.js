/**
 * TimeManager.js
 * Handles game clock progression
 * Triggers monthly, seasonal, and yearly events
 */

import { TIME, TAX } from '../constants/gameConfig.js';

export class TimeManager {
  constructor(gameState) {
    this.state = gameState;
    this.intervalId = null;
    this.isRunning = false;
    
    // Listen for year changes to check degradation
    this.state.on('year_change', () => this.onYearChange());
  }

  start() {
    if (this.isRunning) {
      console.warn('TimeManager already running');
      return;
    }

    console.log('TimeManager started');
    this.isRunning = true;
    this.updateInterval();
  }

  stop() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
      this.isRunning = false;
      console.log('TimeManager stopped');
    }
  }

  /**
   * Update the interval based on current game speed
   */
  updateInterval() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
    
    // Calculate duration based on game speed: duration = base / speed
    const duration = TIME.MONTH_DURATION / this.state.gameSpeed;
    this.intervalId = setInterval(() => this.tick(), duration);
    console.log(`TimeManager interval updated: ${duration}ms per month (speed: ${this.state.gameSpeed}x)`);
  }

  tick() {
    // Don't tick if game is paused
    if (this.state.isPaused) {
      return;
    }
    
    // Advance the month
    this.state.advanceMonth();

    // Check if it's tax collection month (end of winter - December)
    if (this.state.monthIndex === TAX.COLLECTION_MONTH) {
      this.collectTaxes();
    }

    // Check if it's end of season (every 3 months)
    const isEndOfSeason = this.state.tickCount % TIME.MONTHS_PER_SEASON === 0;
    
    if (isEndOfSeason) {
      // Revenue calculated at END OF SEASON only
      this.performSeasonalCalculations();
    } else {
      // Still update population/happiness monthly, just no revenue
      this.updatePopulationOnly();
    }

    // Check for degradation every month
    this.checkMonthlyDegradation();

    // Emit event for UI updates
    this.state.emit('month-changed', {
      month: this.state.getCurrentMonth(),
      season: this.state.getCurrentSeason(),
      year: this.state.year
    });
  }

  /**
   * Check for degradation every month (1% chance per structure, max 10 per month)
   */
  async checkMonthlyDegradation() {
    const { MaintenanceManager } = await import('./MaintenanceManager.js');
    const maintenanceManager = new MaintenanceManager(this.state);
    maintenanceManager.checkForDegradation();
  }

  /**
   * Called when year changes - check for degradation
   */
  async onYearChange() {
    // Year change handling if needed (currently degradation is monthly)
  }

  /**
   * Collect taxes at the end of winter (December)
   */
  collectTaxes() {
    const taxAmount = Math.floor(this.state.budget * this.state.taxRate);
    
    if (taxAmount > 0) {
      this.state.subtractBudget(taxAmount);
      
      // Emit tax collection event
      this.state.emit('tax-collected', {
        amount: taxAmount,
        rate: this.state.taxRate,
        year: this.state.year
      });
      
      console.log(`💸 Taxes collected: $${taxAmount.toLocaleString()} (${(this.state.taxRate * 100).toFixed(0)}% of budget)`);
    }
  }

  /**
   * Perform seasonal calculations (revenue + population)
   */
  async performSeasonalCalculations() {
    // Import managers dynamically to avoid circular dependencies
    const { RevenueManager } = await import('./RevenueManager.js');
    const { PopulationManager } = await import('./PopulationManager.js');
    const { MaintenanceManager } = await import('./MaintenanceManager.js');

    // Calculate revenue (seasonal instead of monthly)
    const revenueManager = new RevenueManager(this.state);
    const revenueReport = revenueManager.calculateMonthlyRevenue();
    
    // Update game state with seasonal revenue
    this.state.monthlyRevenue = revenueReport.net;

    // Calculate population and happiness
    const populationManager = new PopulationManager(this.state);
    const popStats = populationManager.calculatePopulation();
    const baseHappiness = populationManager.calculateHappiness();
    
    // Apply happiness modifiers from events
    const modifierTotal = this.state.getHappinessModifierTotal();
    
    // Apply maintenance penalty (permanent reduction from disrepair)
    const maintenanceManager = new MaintenanceManager(this.state);
    const maintenancePenalty = maintenanceManager.calculateHappinessPenalty();
    
    const finalHappiness = Math.max(0, Math.min(100, baseHappiness + modifierTotal - maintenancePenalty));

    // Update game state with new values
    this.state.population = popStats.total;
    this.state.happiness = finalHappiness;
    this.state.townHappiness = finalHappiness; // Backwards compatibility
    
    // Decrease duration on temporary modifiers
    this.state.updateHappinessModifiers();

    // Emit financial event
    this.state.emit('revenue-calculated', revenueReport);

    // Emit population event
    this.state.emit('population-updated', {
      population: popStats.total,
      happiness: finalHappiness,
      employed: popStats.employed,
      unemployed: popStats.unemployed,
      jobs: popStats.jobs
    });
  }

  /**
   * Update population only (no revenue calculation)
   */
  async updatePopulationOnly() {
    const { PopulationManager } = await import('./PopulationManager.js');

    // Calculate population and happiness
    const populationManager = new PopulationManager(this.state);
    const popStats = populationManager.calculatePopulation();
    const baseHappiness = populationManager.calculateHappiness();
    
    // Apply happiness modifiers from events
    const modifierTotal = this.state.getHappinessModifierTotal();
    const finalHappiness = Math.max(0, Math.min(100, baseHappiness + modifierTotal));

    // Update game state with new values
    this.state.population = popStats.total;
    this.state.happiness = finalHappiness;
    this.state.townHappiness = finalHappiness; // Backwards compatibility
    
    // Decrease duration on temporary modifiers
    this.state.updateHappinessModifiers();

    // Emit population event (no revenue event)
    this.state.emit('population-updated', {
      population: popStats.total,
      happiness: finalHappiness,
      employed: popStats.employed,
      unemployed: popStats.unemployed,
      jobs: popStats.jobs
    });
  }

  pause() {
    this.state.pause();
  }

  resume() {
    this.state.resume();
  }

  reset() {
    this.stop();
    this.state.reset();
  }
}
