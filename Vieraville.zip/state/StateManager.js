/**
 * StateManager.js
 * React context provider for GameState
 * Allows React components to subscribe to state changes
 */

import React, { createContext, useContext, useState, useEffect } from 'react';
import { GameState } from './GameState.js';

export const GameStateContext = createContext(null);

export function GameStateProvider({ children }) {
  const [gameState] = useState(() => GameState.getInstance());
  const [, forceUpdate] = useState(0);

  useEffect(() => {
    // Subscribe to state changes
    const handleStateChange = (eventType) => {
      // Force re-render on any state change
      forceUpdate(prev => prev + 1);
    };

    gameState.addListener(handleStateChange);

    return () => {
      gameState.removeListener(handleStateChange);
    };
  }, [gameState]);

  return React.createElement(GameStateContext.Provider, { value: gameState }, children);
}

// Custom hook for easy access to game state
export function useGameState() {
  const context = useContext(GameStateContext);
  if (!context) {
    throw new Error('useGameState must be used within GameStateProvider');
  }
  return context;
}
