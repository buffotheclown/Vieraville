/**
 * GameState.js
 * Central game state singleton
 * Manages all game data and provides methods for state updates
 */

import { STARTING, MONTHS, MONTH_TO_SEASON, TIME, MANAGER_LIMITS, GAME_SPEED, TAX } from '../constants/gameConfig.js';

export class GameState {
  static instance = null;

  constructor() {
    if (GameState.instance) {
      return GameState.instance;
    }

    // Financial
    this.budget = STARTING.BUDGET;
    this.monthlyRevenue = 0;
    this.monthlyCosts = 0;
    this.totalEarned = 0; // Track total income earned (not starting budget)
    this.taxRate = TAX.RATE; // Current tax rate (starts at 8%)
    
    // Time
    this.year = STARTING.YEAR;
    this.monthIndex = STARTING.MONTH_INDEX;
    this.tickCount = 0;
    
    // Population
    this.population = STARTING.POPULATION;
    this.availableJobs = 0;
    
    // Happiness
    this.happiness = STARTING.HAPPINESS;
    this.townHappiness = STARTING.HAPPINESS; // Backwards compatibility
    this.happinessModifiers = []; // Array of {value: number, duration: number, reason: string}
    this.freedom = 100;  // Starts at 100%
    
    // Map data
    this.mapData = null;
    this.terrainLayer = [];
    this.roadLayer = [];
    this.buildingLayer = [];
    this.entryPoints = [];
    this.gridManager = null; // Reference to GridManager instance
    
    // Managers
    this.hiredManagers = [];
    this.managers = [];  // Active manager instances
    
    // Buildings
    this.buildings = [];
    
    // Game state
    this.isPaused = false;
    this.currentScene = 'title';
    
    // Settings
    this.gameSpeed = GAME_SPEED.NORMAL; // Default to normal speed
    this.soundEnabled = true; // Sound on by default
    
    // Notifications
    this.notifications = [];
    
    // Event listeners for state changes
    this.listeners = [];
    
    // Event emitter (map of event names to arrays of callbacks)
    this.eventListeners = {};

    GameState.instance = this;
  }

  static getInstance() {
    if (!GameState.instance) {
      new GameState();
    }
    return GameState.instance;
  }

  // Time methods
  getCurrentMonth() {
    return MONTHS[this.monthIndex];
  }

  getCurrentSeason() {
    return MONTH_TO_SEASON[this.monthIndex];
  }

  advanceMonth() {
    this.monthIndex++;
    this.tickCount++;
    
    if (this.monthIndex >= MONTHS.length) {
      this.monthIndex = 0;
      this.advanceYear();
    }
    
    this.notifyListeners('month_tick');
    
    // Check for season change
    if (this.tickCount % TIME.MONTHS_PER_SEASON === 0) {
      this.notifyListeners('season_change');
      this.emit('season_change'); // Also emit for modern event system
    }
  }

  advanceYear() {
    this.year++;
    this.notifyListeners('year_change');
    this.emit('year_change', { year: this.year });
  }

  // Budget methods
  addBudget(amount) {
    this.budget += amount;
    this.notifyListeners('budget_change');
  }

  subtractBudget(amount) {
    this.budget -= amount;
    this.notifyListeners('budget_change');
  }

  canAfford(amount) {
    return this.budget >= amount;
  }

  // Population methods
  addPopulation(amount) {
    this.population += amount;
    this.notifyListeners('population_change');
  }

  // Manager methods
  hireManager(managerId) {
    console.log('🔴 [GameState] hireManager called with ID:', managerId);
    console.log('🔴 [GameState] Current hiredManagers array:', this.hiredManagers);
    console.log('🔴 [GameState] Is already hired?', this.hiredManagers.includes(managerId));
    
    if (!this.hiredManagers.includes(managerId)) {
      console.log('🔴 [GameState] Adding manager to hiredManagers array...');
      this.hiredManagers.push(managerId);
      console.log('🔴 [GameState] Updated hiredManagers array:', this.hiredManagers);
      console.log('🔴 [GameState] Calling notifyListeners for manager_hired...');
      this.notifyListeners('manager_hired');
      console.log('🔴 [GameState] notifyListeners completed');
    } else {
      console.log('🔴 [GameState] Manager already in hiredManagers, skipping');
    }
  }

  isManagerHired(managerId) {
    return this.hiredManagers.includes(managerId);
  }

  getAvailableManagerSlots() {
    return MANAGER_LIMITS.MAX_MANAGERS - this.hiredManagers.length;
  }

  // Building methods
  addBuilding(building) {
    this.buildings.push(building);
    this.notifyListeners('building_added');
    this.emit('building_added', building);
    
    // Immediately recalculate population and jobs when a building is added
    this.recalculateStats();
  }
  
  // Recalculate population, jobs, and happiness immediately
  async recalculateStats() {
    try {
      const { PopulationManager } = await import('../managers/PopulationManager.js');
      const populationManager = new PopulationManager(this);
      const popStats = populationManager.calculatePopulation();
      const happiness = populationManager.calculateHappiness();
      
      // Emit update event
      this.emit('population-updated', {
        population: popStats.total,
        happiness: happiness,
        employed: popStats.employed,
        unemployed: popStats.unemployed,
        jobs: popStats.jobs
      });
    } catch (error) {
      console.error('Error recalculating stats:', error);
    }
  }

  getBuildingCount() {
    return this.buildings.length;
  }

  getBuildingsByType(type) {
    return this.buildings.filter(b => b.type === type);
  }

  // Notification methods
  addNotification(message, type = 'info') {
    const notification = {
      id: Date.now(),
      message,
      type,
      timestamp: Date.now()
    };
    this.notifications.push(notification);
    this.notifyListeners('notification_added');
    return notification.id;
  }

  removeNotification(id) {
    this.notifications = this.notifications.filter(n => n.id !== id);
    this.notifyListeners('notification_removed');
  }

  // Scene management
  setScene(sceneName) {
    this.currentScene = sceneName;
    this.notifyListeners('scene_change');
  }

  // Happiness modifier methods
  addHappinessModifier(value, duration = null, reason = '') {
    this.happinessModifiers.push({
      value: value,
      duration: duration, // null = permanent, number = months until expires
      reason: reason
    });
  }

  updateHappinessModifiers() {
    // Decrease duration on all temporary modifiers
    this.happinessModifiers = this.happinessModifiers.filter(mod => {
      if (mod.duration === null) return true; // Keep permanent modifiers
      mod.duration--;
      return mod.duration > 0; // Remove expired modifiers
    });
  }

  getHappinessModifierTotal() {
    return this.happinessModifiers.reduce((sum, mod) => sum + mod.value, 0);
  }

  // Pause/Resume
  pause() {
    console.log('🛑 Game PAUSED');
    this.isPaused = true;
    this.notifyListeners('game_paused');
  }

  resume() {
    console.log('▶️ Game RESUMED');
    this.isPaused = false;
    this.notifyListeners('game_resumed');
  }

  // Grid Manager accessor
  getGridManager() {
    return this.gridManager;
  }

  setGridManager(gridManager) {
    this.gridManager = gridManager;
  }

  // Event system (legacy)
  addListener(callback) {
    this.listeners.push(callback);
  }

  removeListener(callback) {
    this.listeners = this.listeners.filter(l => l !== callback);
  }

  notifyListeners(eventType) {
    this.listeners.forEach(callback => {
      callback(eventType, this);
    });
  }

  // Modern event emitter
  on(eventName, callback) {
    if (!this.eventListeners[eventName]) {
      this.eventListeners[eventName] = [];
    }
    this.eventListeners[eventName].push(callback);
  }

  off(eventName, callback) {
    if (!this.eventListeners[eventName]) return;
    this.eventListeners[eventName] = this.eventListeners[eventName].filter(cb => cb !== callback);
  }

  emit(eventName, data) {
    if (!this.eventListeners[eventName]) return;
    this.eventListeners[eventName].forEach(callback => {
      callback(data);
    });
  }

  // Debug method
  getDebugInfo() {
    return {
      budget: this.budget,
      year: this.year,
      month: this.getCurrentMonth(),
      season: this.getCurrentSeason(),
      population: this.population,
      happiness: this.townHappiness,
      buildings: this.buildings.length,
      managers: this.hiredManagers.length
    };
  }

  // Reset for new game
  reset() {
    this.budget = STARTING.BUDGET;
    this.monthlyRevenue = 0;
    this.monthlyCosts = 0;
    this.totalEarned = 0;
    this.year = STARTING.YEAR;
    this.monthIndex = STARTING.MONTH_INDEX;
    this.tickCount = 0;
    this.population = STARTING.POPULATION;
    this.availableJobs = 0;
    this.townHappiness = STARTING.HAPPINESS;
    this.happiness = STARTING.HAPPINESS;
    this.freedom = 100;
    this.hiredManagers = [];
    this.managers = [];
    this.buildings = [];
    this.notifications = [];
    this.isPaused = false;
    this.notifyListeners('game_reset');
  }
}
