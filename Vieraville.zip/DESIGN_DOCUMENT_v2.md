# VieraVille Private Town Tycoon
**Game Design Document - Version 2.0**  
**Rosebud AI Game Jam (3-day sprint)**  
**Date:** February 2026  
**Genre:** 2D Top-Down Pixel-Art Town Builder / Management Tycoon  
**Platform:** PC (browser / standalone via Rosebud AI export)  
**Target Playtime:** 30–90 minutes per session (endless mode)  
**Inspiration:** Real-world Viera, Florida (Duda family master-planned community) + light SimCity / Stardew Valley automation

---

## 1. OVERVIEW

**Tagline:** Build the next Viera — profit, parks, or politics?

**Core Pitch:** You inherit 14,500 acres of raw Brevard County ranch land in 2030. Hire quirky AI managers to auto-develop a thriving master-planned town while you balance revenue, citizen happiness, manager drama, seasonal cycles, and random events. Automation keeps gameplay relaxing; strategic overrides and cash management keep it tense.

**Win Conditions:**
- **Primary:** Reach 38,000+ population ("Viera Glory")
- **Bonus:** Fill entire 100×100 map with buildings (Perfect Development Achievement)

**Lose Condition:** Negative cash balance sustained for 4 consecutive seasons (12 months / 1 year) → Bankruptcy game over

**Starting Resources:** $5,000,000 cash

---

## 2. CORE GAMEPLAY LOOP

### Phase 1: Setup
1. **Hire Managers** (1-3 at start; unlock up to 10 via milestones)
2. Each manager costs $150K/year salary (paid end of February)

### Phase 2: Plan Approval (End of Each Season)
1. **Managers propose 3 plans each** with general descriptions:
   - "More residential, fewer roads"
   - "Heavy commercial with long road network"
   - "Balanced agricultural expansion"
2. **Each plan has a total cost** (e.g., $800K)
3. **Player selects one plan per manager**
4. **Cost immediately deducted** from cash
5. **If insufficient funds:** Manager cannot execute (waits until next season)

### Phase 3: Construction (Continuous)
1. **Managers build tile-by-tile** using approved plan budget
2. **Roads built first** in "snake head" pattern:
   - From entry point toward map center (50, 50)
   - Deviates toward manager's preferred zone_preference tiles
   - Branches off existing roads when encountered
3. **Buildings placed after roads** reach suitable locations
4. **Plan completes** when budget fully spent
5. **Last road tile becomes new entry point** for that manager's next plan

### Phase 4: Monthly Revenue (Every 10 Seconds Real-Time)
1. **Revenue calculated** from all complete buildings
2. **Seasonal multipliers applied** to specific building types
3. **Manager salaries paid** at end of February

### Phase 5: Events (≈1 Per Season)
1. **Random event triggers** (60% negative, 40% positive)
2. **Player chooses resolution:**
   - Quick fix (cheap, temporary)
   - Long-term solution (expensive, permanent benefit)
3. **Events affect:** Cash, metrics, Freedom stat

### Phase 6: Manager Relationships
1. **Give raises** to boost happiness (+$70K/year per raise)
2. **Mediate conflicts** between despised managers building nearby
3. **Monitor happiness** to prevent resignations

### Phase 7: Milestones
1. **Population thresholds unlock manager slots** (3 → 5 → 7 → 10)
2. **Celebrations trigger** at key milestones

---

## 3. TECHNICAL SPECIFICATIONS

### 3.1 Grid & Rendering
- **Grid Size:** 100 × 100 tiles (10,000 total tiles)
- **Canvas Size:** 3200 × 3200 pixels
- **Tile Size:** 32 × 32 pixels (all graphics single-tile; no multi-tile sprites)
- **Camera:** Top-down, zoomable, smooth scrolling
- **Rendering Order:** Terrain → Roads → Buildings (bottom to top)

### 3.2 Time System
- **1 Month:** 10 seconds real-time
- **1 Season:** 3 months (30 seconds)
- **1 Year:** 12 months (120 seconds / 2 minutes)

**Seasons:**
- **Winter:** December, January, February (salary payment end of Feb)
- **Spring:** March, April, May
- **Summer:** June, July, August
- **Fall:** September, October, November

### 3.3 Building System
- **All structures:** Composed of individual 32×32 tiles placed adjacently
- **Example:** 4×4 farm = 16 individual farm tiles in a cluster
- **Identification:** All tiles in a structure share same `building_id` property
- **Construction:** Tile-by-tile placement over time (not instant)

### 3.4 Art Style
- **Visual Theme:** Vibrant Florida pixel art
- **Color Palette:** Pastels, palms, neon signs, sunset glows
- **Aesthetic:** Retro game charm with modern polish

---

## 4. TILED LAYER ARCHITECTURE

The game uses **Pure Tile-Based Architecture** with three distinct layers. No Tiled Objects or Sprite Objects are used.

### Layer 1: TERRAIN (Bottom, Static)
**Purpose:** Permanent ground state; never modified during gameplay

**Contents:** Grass, dirt, sand, water, trees, wetlands, scrubland

**Tile Properties:**
- `buildable` (boolean) — Can managers build here?
- `terrain_quality` (int, 0-100) — Affects build costs and yields
  - Rich Soil: 90
  - Grass: 70
  - Dirt: 60
  - Scrubland: 50
  - Sand: 45
  - Rocky Ground: 35
  - Water/Wetlands: 0 (unbuildable)
- `entry_point` (boolean) — Map edge tiles where roads can originate (24 total: 6 per edge)
- `zone_preference` (string) — Comma-separated hints for managers
  - Values: "residential", "commercial", "agricultural", "industrial", "amenity", "wetland", "mixed"
  - Example: "residential,commercial,mixed"

---

### Layer 2: ROADS (Middle, Dynamic)
**Purpose:** All road infrastructure built by managers

**Contents:** Dirt roads, paved roads, highways

**Construction Logic:**
1. **Snake Head Pattern:**
   - Primary direction: Toward map center (50, 50)
   - Deviates toward manager's preferred zone_preference tiles
   - Branches off existing roads when encountered
   - Returns toward center after placing buildings
2. **Shared Network:** All managers use same road system
3. **Construction Time:** 1 second per tile (construction marker → road)
4. **Cost:** $200 per road tile

**Tile Properties:**
- `is_road` (boolean) — Always true
- `road_quality` (int) — Determines road type:
  - Dirt Road: 50
  - Paved Road: 80
  - Highway: 100

---

### Layer 3: BUILDINGS (Top, Dynamic)
**Purpose:** ALL manager-constructed content (structures, farms, pastures, parks)

**Contents:** Houses, malls, factories, farms, pastures, parks, amenities

**Note:** Agricultural and amenity tiles (farms, groves, parks) are treated as "buildings" placed on top of grass, not terrain replacements.

**Tile Properties:**
- `building_id` (string) — Unique identifier assigned at runtime (e.g., "house_17")
- `building_type` (string) — Category: "residential", "commercial", "agricultural", "industrial", "amenity"
- `building_subtype` (string) — Optional specific identifier (e.g., "school") for manager targeting
- `structure_size` (string) — Footprint: "2x2", "3x3", "4x4", "6x6"
- `revenue_base` (int) — **FIXED** monthly income in dollars (set in Tiled; calculated once per complete structure)
- `build_cost` (int) — **70% of absolute value of revenue_base**
  - Example: revenue $60K → cost $42K
  - Example: park revenue -$5K → cost $3.5K
- `population_min` (int) — Minimum residents (residential only)
- `population_max` (int) — Maximum residents (residential only; randomly assigned on completion)
- `jobs_available` (int) — Jobs provided by this structure
- `happiness_effect` (int) — Town mood modifier per structure
- `seasonal_multiplier` (string) — Which season boosts this building: "winter", "summer", "fall", "none"
- `population_required` (int) — Minimum town population needed to unlock this building (0 = always available)
- `longevity_year_built` (int) — Year building was completed (for Eco-Conscious Longevity bonus calculation, assigned at runtime)
- `owner_manager` (string) — Manager archetype who built this
- `is_complete` (boolean) — Construction status (false during building, true when finished)

---

## 5. BUILDING ECONOMICS

### 5.1 Building Types Reference Table

| Building Type | Size | Revenue (Monthly) | Build Cost | Pop (Min-Max) | Jobs | Seasonal Boost | Happiness |
|---------------|------|-------------------|------------|---------------|------|----------------|-----------|
| **Small House** | 2×2 (4 tiles) | $50,000 | $35,000 | 2-4 | 0 | None | 0 |
| **Medium House** | 2×2 (4 tiles) | $70,000 | $49,000 | 3-6 | 0 | None | 0 |
| **Large Estate** | 2×2 (4 tiles) | $90,000 | $63,000 | 4-8 | 0 | None | 0 |
| **Small Shop** | 2×2 (4 tiles) | $65,000 | $45,500 | 0 | 5 | Winter (×1.5) | 5 |
| **Strip Mall** | 4×4 (16 tiles) | $150,000 | $105,000 | 0 | 25 | Winter (×1.5) | 5 |
| **Large Plaza** | 6×6 (36 tiles) | $300,000 | $210,000 | 0 | 60 | Winter (×1.5) | 10 |
| **Office Building** | 3×3 (9 tiles) | $125,000 | $87,500 | 0 | 30 | Winter (×1.5) | 5 |
| **School** | 3×3 (9 tiles) | $100,000 | $70,000 | 0 | 20 | None | 15 |
| **Factory** | 4×4 (16 tiles) | $215,000 | $150,500 | 0 | 50 | None | -15 |
| **Warehouse** | 4×4 (16 tiles) | $100,000 | $70,000 | 0 | 20 | None | -5 |
| **Celery Field** | 4×4 (16 tiles) | $100,000 | $70,000 | 0 | 10 | Winter (×1.5) | -5 |
| **Corn Field** | 4×4 (16 tiles) | $65,000 | $45,500 | 0 | 8 | Fall (×1.0) | -5 |
| **Sod Farm** | 4×4 (16 tiles) | $80,000 | $56,000 | 0 | 8 | Summer (×1.3) | -5 |
| **Hay Field** | 4×4 (16 tiles) | $70,000 | $49,000 | 0 | 8 | Summer (×1.3) | -5 |
| **Cattle Pasture** | 4×4 (16 tiles) | $45,000 | $31,500 | 0 | 6 | None | 0 |
| **Citrus Grove** | 4×4 (16 tiles) | $70,000 | $49,000 | 0 | 12 | None | 5 |
| **Small Park** | 2×2 (4 tiles) | -$5,000 | $3,500 | 0 | 2 | None | 20 |
| **Golf Course** | 6×6 (36 tiles) | $60,000 | $42,000 | 0 | 15 | None | 30 |
| **Pool/Rec Center** | 3×3 (9 tiles) | $40,000 | $28,000 | 0 | 10 | Summer (×1.3) | 25 |
| **Zoo Enclosure** | 4×4 (16 tiles) | $50,000 | $35,000 | 0 | 12 | None | 20 |

**Notes:**
- Revenue values are FIXED (set in Tiled custom properties)
- Build cost is always 70% of absolute value of revenue
- Negative revenue (parks) = maintenance costs

### 5.2 Seasonal Multipliers

**Applied to revenue of specific building types:**

- **Winter (×1.5):** Celery Field, All Commercial buildings (Snowbirds shopping)
- **Summer (×1.3):** Sod Farm, Hay Field, Pool/Rec Center
- **Fall (×1.0):** Corn Field (Harvest season, baseline multiplier)
- **None:** Residential buildings, and other buildings not listed above

**Implementation:** Multiply building's `revenue_base` by seasonal multiplier during revenue calculation.

### 5.3 Revenue Timing
- **Calculated:** End of each month (every 10 seconds real-time)
- **Paid:** All complete buildings generate revenue simultaneously
- **Formula:** `Total Monthly Revenue = Sum of (building.revenue_base × seasonal_multiplier)`

### 5.4 Population & Jobs System

**Jobs Requirement:** Population requires **50% of current population in available jobs**
- Example: 2,000 population requires 1,000 available jobs
- Accounts for non-working individuals (children, retirees, unemployed)

**Population Growth Mechanics:**
1. **Check performed:** End of each month
2. **Growth condition:** `available_jobs >= (current_population × 0.5)`
3. **If condition met:** Empty residential buildings fill up randomly according to `population_min/max`
4. **If condition NOT met:** No new residents move into empty houses

**Housing Capacity:**
- Each residential building has capacity defined by `population_min` and `population_max`
- When residential building completes: Remains empty (population = 0)
- At end of month: If jobs available, building fills with random population between min-max

**Job Availability:**
- Sum of `jobs_available` from all complete commercial, industrial, agricultural, and amenity buildings

**Example Flow:**
1. Player builds 5 Small Houses (capacity: 2-4 each, total max: 20 residents)
2. Houses complete but remain empty (population = 0)
3. End of month check: Current pop = 0, Required jobs = 0, Available jobs = 0 → No growth
4. Player builds Factory (50 jobs) and Shop (5 jobs) = 55 jobs available
5. End of month check: Required jobs = 0 (no pop yet), Available jobs = 55 → Houses fill up
6. Houses randomly assign: House 1 gets 3, House 2 gets 2, House 3 gets 4, House 4 gets 3, House 5 gets 2 (Total: 14 residents)
7. Next month check: Current pop = 14, Required jobs = 7, Available jobs = 55 → Can support up to 110 population

**Player Feedback Messages:**
- `available_jobs < (population × 0.5)` → "Residents need more jobs!" (persistent UI notification)
- `empty_housing > 0 AND jobs_available >= requirement` → "Build more jobs to fill empty housing!" (persistent UI notification)

**Demand System:**
- Notifications appear once per season when demand exists
- Notifications persist in UI window until resolved
- If demand unmet for 2+ consecutive seasons: Town Happiness decreases (-5 per season)
- Happiness continues to decrease each season until demand satisfied

### 5.5 Town Happiness Calculation

**Formula:** `Town Happiness = (Sum of all building happiness_effects ÷ Number of buildings)`

**Display:** Capped at 100% for player (internal value can exceed 100%)

**Decay Conditions:**
- Unmet housing demand for 2+ seasons: -5 happiness per season
- Unmet jobs demand for 2+ seasons: -5 happiness per season

**Affected By:**
- Building `happiness_effect` values (positive/negative)
- Capped by Freedom stat (hidden)
- Demand satisfaction

---

## 6. MANAGER SYSTEM

### 6.1 Universal Stats (All Managers)

| Stat | Range | Visible? | Description |
|------|-------|----------|-------------|
| **Happiness** | 0-100 | Yes | Affected by salary, raises, conflicts, plan approvals. **Starting value: 100** |
| **Efficiency** | 0-100 | Yes | Affects build speed and quality. **Starting value: 100**. Modified by Happiness + Specialty Stats |
| **Loyalty** | 0-100 | No | Quit risk if <30 (10% per season). Affects fire cost |
| **Experience** | 0-100 | Partial | Plan quality/ROI. Grows +1-5 per successful season |

**Happiness Factors:**
- +10 when plan approved
- +20 when raise given
- -10 when no raise for 5 years (one-time, fixable with raise)
- -Variable when building near despised managers
- -Variable when despised manager hired

### 6.2 Manager Archetypes & Specialty Stats

**All specialty stats are HIDDEN from player but affect manager behavior.**

| Manager | Zone Preferences | Build Bias | Specialty Stats | Event Bonus |
|---------|------------------|------------|-----------------|-------------|
| **Aggressive Developer** | industrial, commercial, mixed | Malls, Factories, Warehouses | **Speed** (25% faster), **Density** (prefers adjacent placement) | Tariffs: +20% absorb |
| **Resident-First** | residential, amenity, mixed | Homes, Parks, Schools | **Pop Growth** (+50% residential cap), **Quality** (+10% happiness), **School Builder** (builds 1 school at 4K pop, then every 8K) | Norovirus: +30% recovery |
| **Eco-Conscious** | wetland, agricultural, amenity | Farms, Zoo, Solar | **Longevity** (+1% revenue/year, max +15%), **Low Pollution** (ignores industrial penalties) | Greening: -10% loss |
| **Cost-Cutter** | residential, mixed | Cheap Dense Housing | **Cost Save** (20% cheaper builds), **Density** (adjacent placement), **Low Quality** (-5% happiness) | Tax Spike: +15% buffer |
| **Politically Savvy** | mixed | Roads, Infrastructure | **Influence** (Freedom restoration bonus), **Fast Roads** (50% faster road builds) | Shakedown: 50% auto-resolve |
| **Sod & Ag Specialist** | agricultural, mixed | Celery, Corn, Sod, Hay | **Yield** (+20% agricultural revenue), **Season Adapt** (+0.2 to seasonal multipliers) | Plague: +20% salvage |
| **Commercial Lease King** | commercial, mixed | Plazas, Offices, Shops | **Revenue Boost** (+15% commercial revenue), **Lease Speed** (15% faster commercial builds) | Snowbird Boom: +25% |
| **Homebuilder Boss** | residential, mixed | All Residential Types | **Pop Growth** (+50% residential cap), **Speed** (25% faster residential builds) | Zoning Lawsuit: +15% sway |
| **Ranch & Cattle Wrangler** | agricultural, mixed | Pastures, Groves, Cattle | **Resilience** (resist event damage), **Yield** (+15% agricultural revenue) | Heat Die-Off: -15% loss |
| **Amenities Guru** | amenity, residential, mixed | Golf, Pools, Parks, Trails, Zoo | **Happiness Boost** (+25% amenity happiness), **Quality** (+5% all building happiness) | Flu: +20% containment |

**Specialty Stat Examples:**
- **Speed (25% faster):** Build time reduced by 25%
- **Density:** Prefers placing buildings adjacent to existing structures
- **Pop Growth (+50%):** Small House (2-4) becomes (3-6), Medium House (3-6) becomes (5-9), Large Estate (4-8) becomes (6-12)
- **Yield (+20%):** Celery Field $100K → $120K revenue
- **Season Adapt (+0.2):** Winter ×1.5 → ×1.7 for this manager's buildings
- **Longevity (+1% per year, max +15%):** Applied per building structure (2×2, 4×4, etc.). Building built in Year 1: generates +1% Year 2, +2% Year 3... caps at +15% Year 15+
- **School Builder:** Resident-First builds 1 school at 4,000 population, 2nd school at 12,000, 3rd at 20,000, etc.

### 6.2a Population-Gated Buildings

Certain buildings require minimum population thresholds before they can be built.

**School Requirements:**
- **Resident-First Manager:** Builds 1st school at 4,000 population, then 1 additional school every 8,000 population thereafter
- **All Other Managers:** Build schools at 8,000 population intervals (8K, 16K, 24K, etc.)

**Implementation:**
- Managers check current population before selecting buildings to construct
- If population threshold not met: Building type unavailable in manager's build pool
- New building custom property: `population_required` (int) - Minimum population needed to unlock this building

### 6.3 Manager Relationships

Each manager has **2 LIKES** and **2 DESPISES**.

**Proximity Rule:** When structures are built within **10 tiles** of each other:
- **Adjacent to LIKED manager's building:** Happiness increases
- **Adjacent to DESPISED manager's building:** Happiness decreases (temporary; fixed with raise or event)
- **No stacking:** One adjacent structure triggers effect; multiple don't compound
- **Once per season max:** Happiness loss from competition only happens once per season

**Relationship Matrix:**

| Manager | Likes | Despises |
|---------|-------|----------|
| **Aggressive Developer** | Commercial Lease King, Politically Savvy | Eco-Conscious, Amenities Guru |
| **Resident-First** | Amenities Guru, Homebuilder Boss | Aggressive Developer, Cost-Cutter |
| **Eco-Conscious** | Sod & Ag Specialist, Ranch & Cattle Wrangler | Aggressive Developer, Commercial Lease King |
| **Cost-Cutter** | Homebuilder Boss, Politically Savvy | Resident-First, Amenities Guru |
| **Politically Savvy** | Aggressive Developer, Commercial Lease King | Eco-Conscious, Resident-First |
| **Sod & Ag Specialist** | Eco-Conscious, Ranch & Cattle Wrangler | Commercial Lease King, Aggressive Developer |
| **Commercial Lease King** | Aggressive Developer, Politically Savvy | Eco-Conscious, Sod & Ag Specialist |
| **Homebuilder Boss** | Resident-First, Cost-Cutter | Amenities Guru, Eco-Conscious |
| **Ranch & Cattle Wrangler** | Sod & Ag Specialist, Eco-Conscious | Aggressive Developer, Commercial Lease King |
| **Amenities Guru** | Resident-First, Eco-Conscious | Aggressive Developer, Cost-Cutter |

### 6.4 Manager Salaries & Raises

**Base Salary:** $150,000 per manager per year
- Paid at end of February (end of Winter season)
- Paid regardless of hire date (even if hired mid-year)

**Raises:** $70,000 per raise
- **Purpose:** Allows manager to execute additional concurrent plans
- **Effect on concurrent plans:**
  - 0 raises: 1 plan at a time
  - 1 raise ($220K/year): 2 plans simultaneously
  - 2 raises ($290K/year): 3 plans simultaneously
- **Happiness Impact:** Boosts happiness when given; prevents 5-year decay

### 6.5 Manager Logic (AI Behavior)

**Plan Generation:**
- Occurs at **end of each season**
- Each manager proposes **3 different plans**
- Plans are **general descriptions** shown to player:
  - "Heavy residential with minimal roads" ($300K)
  - "Balanced commercial expansion" ($700K)
  - "Long road network to new agricultural zone" ($1.2M)
- **Plan Cost Tiers** (randomly generated within ranges, rounded to nearest $100K):
  - **Tier 1:** $200K - $500K
  - **Tier 2:** $600K - $800K
  - **Tier 3:** $900K - $1.5M
- Each plan has **predetermined total cost**
- Player selects **one plan per manager**

**Plan Execution:**
1. **Cost immediately deducted** from player's cash
2. **Manager builds using plan budget as meter:**
   - Roads: $200 per tile
   - Buildings: 70% of building's revenue_base
3. **Manager continues building until budget depleted OR cannot afford next building**
4. **Budget Check:** Manager will only build roads if they can also afford to build buildings
   - If budget < cheapest building cost: Plan ends, remaining budget refunded to player
5. **Plan completes** when budget fully spent or insufficient funds remain
6. **Last road tile becomes new entry point** for next plan

**Manager Entity System ("Little Man"):**

Each manager has a visible entity (character sprite) that represents their current construction focus point.

**Entity Movement & Building Sequence:**
1. **Spawn:** Manager entity spawns at entry_point tile (map edge) when plan approved
2. **Road Building Phase:**
   - Entity moves forward 1 tile onto terrain (always 1 tile ahead of road construction)
   - Previous tile becomes road (construction marker → road, 1 second)
   - Entity continues moving toward map center (50, 50) OR preferred zone_preference tiles
   - Entity moves at 1 tile per second
3. **Branching Logic:**
   - When entity encounters existing roads: Can backtrack along connected road network (1 tile/second)
   - Creates T-junction branches when deviating toward new preferred zones
   - 90% of time: Entity at road endpoint, snaking forward
   - 10% of time: Entity backtracks to create strategic branches
4. **Building Phase Trigger:**
   - Entity reaches preferred zone_preference tile
   - Entity builds road ON the preferred zone tile (1 second)
   - Entity STOPS moving - Building Phase begins
5. **Building Placement:**
   - Buildings constructed **adjacent to/backwards from the road endpoint**
   - **Direction:** Buildings placed LEFT/behind road endpoint (toward existing road network)
   - **1×1 building:** One tile adjacent to road
   - **2×2 building:** Placed backwards toward existing road
   - **4×4 building:** Placed backwards/around road
   - Buildings construct tile-by-tile (see Construction Speed Formula)
6. **Resume or Complete:**
   - Buildings complete + budget remains: Entity resumes road building
   - Budget depleted: Plan complete, entity remains at last position (becomes entry point for next plan)

**Multiple Concurrent Plans:**
- Manager with raises can have 2-3 concurrent plans approved simultaneously
- **Execution:** Manager completes Plan A fully, then entity moves along roads to begin Plan B, then Plan C
- **Sequential only:** One plan at a time per manager (no simultaneous construction)
- **Benefit:** Reduces micromanagement (approve multiple plans at once, manager queues them)

**Entry Point Selection:**
- **Entry points pre-defined:** 24 tiles on map edges with `entry_point: true` custom property (already placed in Tiled map)
- **First plan:** Manager scans for unused entry_point tiles, selects one
- **Subsequent plans:** Entity starts from last position of previous plan (usually road endpoint)
- **Multiple endpoints:** If manager created multiple branches, randomly pick one endpoint

**Build Competition:**
- When 2+ managers want same tile: **50/50 random check**
- **Winner:** Builds on tile
- **Loser:** Loses happiness (once per season max), builds elsewhere

**Zone Preference Fallback:**
- If preferred zone unavailable: Build in "mixed" zones
- If no suitable tiles: Wait for next season

### 6.6 Construction Speed Formula

```
Build Time per Tile = Base Time ÷ (Efficiency ÷ 100) ÷ Speed Modifier

Where:
- Base Time = 1 second
- Efficiency = Manager's current efficiency stat (0-100)
- Speed Modifier = 1.25 if manager has "Speed" specialty, 1.15 if "Lease Speed", 1.5 if "Fast Roads" (for roads only), otherwise 1.0

Examples:
- Manager with 80 Efficiency, no Speed: 1 ÷ 0.8 ÷ 1.0 = 1.25 seconds per tile
- Manager with 80 Efficiency, Speed bonus: 1 ÷ 0.8 ÷ 1.25 = 1 second per tile
- Manager with 100 Efficiency, Speed bonus: 1 ÷ 1.0 ÷ 1.25 = 0.8 seconds per tile
```

**Special Cases:**
- **Politically Savvy building roads:** Speed Modifier = 1.5 (roads only)
- **Commercial Lease King building commercial:** Speed Modifier = 1.15 (commercial only)
- **Homebuilder Boss building residential:** Speed Modifier = 1.25 (residential only)

---

## 7. EVENTS SYSTEM

### 7.1 Event Frequency
- **Trigger Rate:** ≈1 event per season (randomized)
- **Distribution:** 60% negative, 40% positive

### 7.2 Negative Events (Cash/Metric Penalties)

1. **Hurricane Havoc** — Building damage, cash loss
2. **Citrus Greening Outbreak** — Citrus grove revenue loss
3. **Migrant Worker Crackdown** — Agricultural job loss, productivity drop
4. **Commissioner Shakedown** — Pay bribe or lose Freedom
5. **Property Tax Spike** — One-time cash penalty
6. **Zoo Animal Flu** — Zoo closure, revenue loss
7. **Water Park Algae Bloom** — Pool closure, happiness drop
8. **Celery Armyworm Plague** — Celery field damage
9. **Sewage Spill Scandal** — Happiness drop, cleanup cost
10. **Zoning Lawsuit Freeze** — Building restrictions, manager slowdown

### 7.3 Positive Events (Rewards)

1. **Snowbird Boom** — +50% winter retail revenue (one season)
2. **Crop Windfall** — Double agricultural yield (one season)
3. **Rocket Launch Festival** — +population, +revenue surge
4. **Eco Grant** — $800K free cash
5. **Viera Investor Rush** — +commercial leases, bonus revenue

### 7.4 Event Resolution

**Player Choices:**
- **Quick Fix:** Cheap ($50K-$200K), temporary solution (lasts 1-2 seasons)
- **Long-Term Investment:** Expensive ($500K-$1M), permanent benefit or prevention

**Manager Event Bonuses:**
- Managers with relevant specialty stats reduce event damage
- Example: Eco-Conscious manager reduces Citrus Greening loss by 10%
- Example: Politically Savvy has 50% chance to auto-resolve Commissioner Shakedown

### 7.5 Freedom Mechanic (Hidden from Player)

**Purpose:** Caps maximum achievable Town Happiness

**Starting Value:** 100

**Decreases From:**
- Events imposing taxes, regulations, laws
- Player choosing restrictive event resolutions
- Typical decrease: -5 to -20 per restrictive event

**Increases From:**
- Player actions to repeal restrictions:
  - Pay off politicians (cost varies: $200K-$500K)
  - Campaign for law changes (cost + time investment)
  - Long-term event resolutions that remove regulations
- **Politically Savvy manager:** Increases success odds of Freedom restoration by 25%

**Effect:** Town Happiness can never exceed current Freedom value
- Example: Freedom = 75 → Max Town Happiness = 75 (even if buildings would give 90)

---

## 8. METRICS DASHBOARD

**Always visible UI elements:**

1. **Population** (current / milestone target)
2. **Cash** (with bankruptcy warning if negative)
3. **Monthly Revenue** (calculated/updated end of month)
4. **Town Happiness** (0-100, shown as bar or percentage)
5. **Current Date** (e.g., "January, Winter, Year 2")
6. **Manager Status Panel** (for each active manager):
   - Portrait
   - Name
   - Happiness bar
   - Efficiency percentage
   - Current activity (Building, Waiting, Idle)

**Hidden Metrics (not displayed):**
- Freedom (affects max Town Happiness)
- Manager Loyalty
- Individual manager Efficiency formula components

---

## 9. PROGRESSION & MILESTONES

### 9.1 Population Milestones

| Population | Unlocks |
|------------|---------|
| **100** | First celebration animation |
| **1,000** | Unlock 5 manager slots (up from 3) |
| **10,000** | Unlock 7 manager slots; politics layer intensifies (more political events) |
| **38,000+** | Unlock all 10 manager slots; "Viera Mastered" achievement; endless optimization mode |

**Bonus Achievement:**
- **Perfect Development:** Fill entire 100×100 map (all buildable tiles occupied)

### 9.2 Manager Hiring Limits

**New Game:** 1-3 manager slots available
**Progressive Unlocks:** 4-10 slots unlocked via population milestones
**Persistence:** Unlocks saved in local storage for future runs

### 9.3 Bankruptcy & Cash Flow

**Warning Period:** Once cash goes negative, player has **4 consecutive seasons** (12 months / 1 year) to return to positive

**Game Over:** If still negative after 4 seasons → Bankruptcy screen

**No Banking System:** (Planned for future iteration)

---

## 10. SCOPE NOTES (3-Day Jam)

### Core Priorities (Must-Have)
1. **Grid rendering system** (Tiled map loader, 3-layer compositing)
2. **Manager FSM** (Finite State Machine for AI behavior)
3. **Plan generation & approval UI**
4. **Auto road/build system** (snake head pathfinding)
5. **Seasonal tick system** (month/season/year counter)
6. **Revenue calculation** (monthly with seasonal multipliers)
7. **Event pop-ups** (random triggers with choice UI)
8. **Cash tracking** (with bankruptcy detection)
9. **Manager relationship system** (like/despise proximity checks)

### Nice-to-Have Polish
- Speech bubble animations for manager feedback
- Confetti/celebration effects on milestones
- Real Viera, Florida photo gallery at 38K population
- Sound effects for building placement, cash transactions
- Background music (Florida-themed instrumental)

### Explicitly NOT Implemented (Keep Simple)
- Building demolition/selling
- Rezoning tools
- Complex pathfinding beyond snake head pattern
- Loan/banking system
- Deep economic simulation (supply chains, etc.)
- Multiplayer or leaderboards
- Custom map editor

### Art Requirements
- **Terrain tiles:** 6-8 types (grass, dirt, sand, water, trees, wetlands, scrubland, rocky)
- **Road tiles:** 3 types (dirt, paved, highway) + construction marker
- **Building tiles:** 20 types (see Section 5.1 table)
- **Manager portraits:** 10 unique character portraits
- **UI elements:** Buttons, panels, progress bars, icons

---

## 11. TECHNICAL IMPLEMENTATION NOTES

### 11.1 Tiled Map Setup
- **Map dimensions:** 100×100 tiles
- **Tileset:** All tile custom properties pre-configured
- **Layers:** Exactly 3 (Terrain, Roads, Buildings)
- **Export format:** JSON for easy loading in JavaScript

### 11.2 Data Structures

**Building Data (Runtime):**
```javascript
{
  building_id: "house_17",
  building_type: "residential",
  building_subtype: null,
  structure_size: "2x2",
  tiles: [{x: 10, y: 10}, {x: 11, y: 10}, {x: 10, y: 11}, {x: 11, y: 11}],
  revenue_base: 50000,
  build_cost: 35000,
  population: 3, // randomly assigned between min-max
  jobs_available: 0,
  happiness_effect: 0,
  seasonal_multiplier: "spring",
  owner_manager: "Homebuilder Boss",
  is_complete: true,
  construction_progress: 4 // tiles placed so far
}
```

**Manager Data (Runtime):**
```javascript
{
  name: "Homebuilder Boss",
  happiness: 85,
  efficiency: 90,
  loyalty: 75,
  experience: 45,
  salary: 220000, // base + raises
  raises: 1,
  concurrent_plans: 2,
  active_plans: [
    { budget: 450000, spent: 120000, status: "building" }
  ],
  entry_point: {x: 5, y: 0}, // current starting location
  zone_preferences: ["residential", "mixed"],
  specialty_stats: {
    pop_growth: 1.5, // +50%
    speed: 1.25 // 25% faster
  }
}
```

### 11.3 Core Game Loop (Pseudocode)

```
function gameLoop() {
  // 1. Update time
  tick += deltaTime;
  if (tick >= 10 seconds) {
    advanceMonth();
    calculateRevenue();
    updateDashboard();
    tick = 0;
  }
  
  // 2. Process manager construction
  for (manager in activeManagers) {
    if (manager.hasActivePlan) {
      buildNextTile(manager);
    }
  }
  
  // 3. Check for season end
  if (monthsElapsed % 3 === 0) {
    triggerPlanProposals();
    triggerRandomEvent();
  }
  
  // 4. Check for February
  if (currentMonth === "February" && seasonEnding) {
    paySalaries();
  }
  
  // 5. Check bankruptcy
  if (cash < 0) {
    consecutiveNegativeSeasons++;
    if (consecutiveNegativeSeasons >= 4) {
      gameOver("bankruptcy");
    }
  } else {
    consecutiveNegativeSeasons = 0;
  }
  
  // 6. Check milestones
  checkPopulationMilestones();
  
  // 7. Render
  renderLayers();
  renderUI();
}
```

---

**END OF DESIGN DOCUMENT v2.0**

**Total Word Count:** ~5,200 words  
**Last Updated:** [Current Date]  
**Status:** Ready for Implementation
