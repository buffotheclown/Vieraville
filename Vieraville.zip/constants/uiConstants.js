/**
 * uiConstants.js
 * UI layout, colors, sizes, and styling constants
 */

export const COLORS = {
  // Primary palette
  PRIMARY: '#2E7D32',        // Green (Florida nature)
  SECONDARY: '#1565C0',      // Blue (water)
  ACCENT: '#F57C00',         // Orange (citrus)
  
  // Status colors
  SUCCESS: '#4CAF50',
  WARNING: '#FF9800',
  ERROR: '#F44336',
  INFO: '#2196F3',
  
  // UI backgrounds
  PANEL_BG: '#1E1E1E',
  MODAL_BG: '#2C2C2C',
  OVERLAY: 'rgba(0, 0, 0, 0.7)',
  
  // Text colors
  TEXT_PRIMARY: '#FFFFFF',
  TEXT_SECONDARY: '#B0B0B0',
  TEXT_DISABLED: '#666666',
  
  // Manager status
  MANAGER_HAPPY: '#4CAF50',
  MANAGER_NEUTRAL: '#FFC107',
  MANAGER_UNHAPPY: '#F44336',
  
  // Building types (for canvas rendering)
  RESIDENTIAL: '#8BC34A',
  COMMERCIAL: '#2196F3',
  INDUSTRIAL: '#9E9E9E',
  AGRICULTURAL: '#CDDC39',
  RANCH: '#795548',
  AMENITY: '#E91E63',
  
  // Terrain
  GRASS: '#4CAF50',
  DIRT: '#8D6E63',
  WATER: '#2196F3',
  ROAD: '#424242'
};

export const PANEL_SIZES = {
  TOP_HUD_HEIGHT: 80,         // pixels
  MANAGER_PANEL_WIDTH: 280,   // pixels
  DASHBOARD_PANEL_WIDTH: 320, // pixels
  MANAGER_CARD_HEIGHT: 140,   // pixels
  TOAST_WIDTH: 300,           // pixels
  TOAST_HEIGHT: 80            // pixels
};

export const MODAL_SIZES = {
  SMALL: { width: 400, height: 300 },
  MEDIUM: { width: 600, height: 400 },
  LARGE: { width: 800, height: 600 }
};

export const Z_INDEX = {
  CANVAS: 1,
  HUD: 10,
  PANEL: 20,
  TOAST: 30,
  MODAL: 40,
  MODAL_OVERLAY: 35
};

export const FONTS = {
  FAMILY: '"Press Start 2P", "Courier New", monospace',
  SIZE_SMALL: '10px',
  SIZE_MEDIUM: '14px',
  SIZE_LARGE: '18px',
  SIZE_TITLE: '24px'
};

export const SPACING = {
  SMALL: 8,
  MEDIUM: 16,
  LARGE: 24,
  XLARGE: 32
};

export const BORDER_RADIUS = {
  SMALL: 4,
  MEDIUM: 8,
  LARGE: 12
};

export const ANIMATION = {
  DURATION_FAST: 200,      // ms
  DURATION_NORMAL: 300,    // ms
  DURATION_SLOW: 500,      // ms
  EASING: 'ease-in-out'
};

export const BUTTON_STYLES = {
  PRIMARY: {
    backgroundColor: COLORS.PRIMARY,
    color: COLORS.TEXT_PRIMARY,
    hoverBackgroundColor: '#388E3C'
  },
  SECONDARY: {
    backgroundColor: COLORS.SECONDARY,
    color: COLORS.TEXT_PRIMARY,
    hoverBackgroundColor: '#1976D2'
  },
  SUCCESS: {
    backgroundColor: COLORS.SUCCESS,
    color: COLORS.TEXT_PRIMARY,
    hoverBackgroundColor: '#66BB6A'
  },
  DANGER: {
    backgroundColor: COLORS.ERROR,
    color: COLORS.TEXT_PRIMARY,
    hoverBackgroundColor: '#EF5350'
  },
  DISABLED: {
    backgroundColor: COLORS.TEXT_DISABLED,
    color: COLORS.TEXT_SECONDARY,
    cursor: 'not-allowed'
  }
};
