/**
 * buildingData.js
 * All 20 building definitions with costs, revenues, and properties
 */

export const BUILDING_TYPES = {
  RESIDENTIAL: 'residential',
  COMMERCIAL: 'commercial',
  INDUSTRIAL: 'industrial',
  AGRICULTURAL: 'agricultural',
  RANCH: 'ranch',
  AMENITY: 'amenity'
};

export const SEASONS = {
  SPRING: 'Spring',
  SUMMER: 'Summer',
  FALL: 'Fall',
  WINTER: 'Winter'
};

export const BUILDINGS = {
  small_house: {
    id: 'small_house',
    type: BUILDING_TYPES.RESIDENTIAL,
    name: 'Small House',
    revenue_base: 1200,
    build_cost: 840,
    population_min: 2,
    population_max: 4,
    jobs_available: 0,
    happiness_effect: 5,
    seasonal_multiplier: { default: 1.0 },
    size_tiles: 2,
    population_required: 0
  },
  medium_house: {
    id: 'medium_house',
    type: BUILDING_TYPES.RESIDENTIAL,
    name: 'Medium House',
    revenue_base: 2000,
    build_cost: 1400,
    population_min: 3,
    population_max: 6,
    jobs_available: 0,
    happiness_effect: 8,
    seasonal_multiplier: { default: 1.0 },
    size_tiles: 3,
    population_required: 0
  },
  large_house: {
    id: 'large_house',
    type: BUILDING_TYPES.RESIDENTIAL,
    name: 'Large House',
    revenue_base: 3500,
    build_cost: 2450,
    population_min: 4,
    population_max: 8,
    jobs_available: 0,
    happiness_effect: 12,
    seasonal_multiplier: { default: 1.0 },
    size_tiles: 4,
    population_required: 0
  },
  small_shop: {
    id: 'small_shop',
    type: BUILDING_TYPES.COMMERCIAL,
    name: 'Small Shop',
    revenue_base: 5000,
    build_cost: 3500,
    population_min: 0,
    population_max: 0,
    jobs_available: 3,
    happiness_effect: 10,
    seasonal_multiplier: { default: 1.0 },
    size_tiles: 2,
    population_required: 0
  },
  strip_mall: {
    id: 'strip_mall',
    type: BUILDING_TYPES.COMMERCIAL,
    name: 'Strip Mall',
    revenue_base: 12000,
    build_cost: 8400,
    population_min: 0,
    population_max: 0,
    jobs_available: 8,
    happiness_effect: 15,
    seasonal_multiplier: { default: 1.0 },
    size_tiles: 4,
    population_required: 0
  },
  large_plaza: {
    id: 'large_plaza',
    type: BUILDING_TYPES.COMMERCIAL,
    name: 'Large Plaza',
    revenue_base: 25000,
    build_cost: 17500,
    population_min: 0,
    population_max: 0,
    jobs_available: 20,
    happiness_effect: 25,
    seasonal_multiplier: { default: 1.0 },
    size_tiles: 6,
    population_required: 0
  },
  office: {
    id: 'office',
    type: BUILDING_TYPES.COMMERCIAL,
    name: 'Office',
    revenue_base: 15000,
    build_cost: 10500,
    population_min: 0,
    population_max: 0,
    jobs_available: 25,
    happiness_effect: 5,
    seasonal_multiplier: { default: 1.0 },
    size_tiles: 4,
    population_required: 0
  },
  school: {
    id: 'school',
    type: BUILDING_TYPES.COMMERCIAL,
    name: 'School',
    revenue_base: -8000,
    build_cost: 5600,
    population_min: 0,
    population_max: 0,
    jobs_available: 15,
    happiness_effect: 40,
    seasonal_multiplier: { default: 1.0 },
    size_tiles: 5,
    population_required: 4000
  },
  factory: {
    id: 'factory',
    type: BUILDING_TYPES.INDUSTRIAL,
    name: 'Factory',
    revenue_base: 20000,
    build_cost: 14000,
    population_min: 0,
    population_max: 0,
    jobs_available: 40,
    happiness_effect: -15,
    seasonal_multiplier: { default: 1.0 },
    size_tiles: 6,
    population_required: 0,
    tileId: 31 // Top-left tile ID in tileset for this building
  },
  warehouse: {
    id: 'warehouse',
    type: BUILDING_TYPES.INDUSTRIAL,
    name: 'Warehouse',
    revenue_base: 10000,
    build_cost: 7000,
    population_min: 0,
    population_max: 0,
    jobs_available: 15,
    happiness_effect: -8,
    seasonal_multiplier: { default: 1.0 },
    size_tiles: 4,
    population_required: 0
  },
  celery_farm: {
    id: 'celery_farm',
    type: BUILDING_TYPES.AGRICULTURAL,
    name: 'Celery Farm',
    revenue_base: 8000,
    build_cost: 5600,
    population_min: 0,
    population_max: 0,
    jobs_available: 5,
    happiness_effect: 0,
    seasonal_multiplier: { [SEASONS.WINTER]: 1.5, default: 1.0 },
    size_tiles: 4,
    population_required: 0
  },
  corn_farm: {
    id: 'corn_farm',
    type: BUILDING_TYPES.AGRICULTURAL,
    name: 'Corn Farm',
    revenue_base: 6000,
    build_cost: 4200,
    population_min: 0,
    population_max: 0,
    jobs_available: 4,
    happiness_effect: 0,
    seasonal_multiplier: { [SEASONS.FALL]: 1.0, default: 1.0 },
    size_tiles: 4,
    population_required: 0
  },
  sod_farm: {
    id: 'sod_farm',
    type: BUILDING_TYPES.AGRICULTURAL,
    name: 'Sod Farm',
    revenue_base: 7000,
    build_cost: 4900,
    population_min: 0,
    population_max: 0,
    jobs_available: 6,
    happiness_effect: 5,
    seasonal_multiplier: { [SEASONS.SUMMER]: 1.3, default: 1.0 },
    size_tiles: 5,
    population_required: 0
  },
  hay_farm: {
    id: 'hay_farm',
    type: BUILDING_TYPES.AGRICULTURAL,
    name: 'Hay Farm',
    revenue_base: 5000,
    build_cost: 3500,
    population_min: 0,
    population_max: 0,
    jobs_available: 3,
    happiness_effect: 0,
    seasonal_multiplier: { [SEASONS.SUMMER]: 1.3, default: 1.0 },
    size_tiles: 4,
    population_required: 0
  },
  citrus_grove: {
    id: 'citrus_grove',
    type: BUILDING_TYPES.AGRICULTURAL,
    name: 'Citrus Grove',
    revenue_base: 9000,
    build_cost: 6300,
    population_min: 0,
    population_max: 0,
    jobs_available: 8,
    happiness_effect: 10,
    seasonal_multiplier: { default: 1.0 },
    size_tiles: 6,
    population_required: 0
  },
  cattle_pasture: {
    id: 'cattle_pasture',
    type: BUILDING_TYPES.RANCH,
    name: 'Cattle Pasture',
    revenue_base: 12000,
    build_cost: 8400,
    population_min: 0,
    population_max: 0,
    jobs_available: 6,
    happiness_effect: -5,
    seasonal_multiplier: { default: 1.0 },
    size_tiles: 8,
    population_required: 0
  },
  small_park: {
    id: 'small_park',
    type: BUILDING_TYPES.AMENITY,
    name: 'Small Park',
    revenue_base: -1000,
    build_cost: 700,
    population_min: 0,
    population_max: 0,
    jobs_available: 2,
    happiness_effect: 20,
    seasonal_multiplier: { default: 1.0 },
    size_tiles: 2,
    population_required: 0
  },
  golf_course: {
    id: 'golf_course',
    type: BUILDING_TYPES.AMENITY,
    name: 'Golf Course',
    revenue_base: 15000,
    build_cost: 10500,
    population_min: 0,
    population_max: 0,
    jobs_available: 12,
    happiness_effect: 35,
    seasonal_multiplier: { default: 1.0 },
    size_tiles: 10,
    population_required: 0
  },
  pool: {
    id: 'pool',
    type: BUILDING_TYPES.AMENITY,
    name: 'Community Pool',
    revenue_base: -2000,
    build_cost: 1400,
    population_min: 0,
    population_max: 0,
    jobs_available: 3,
    happiness_effect: 25,
    seasonal_multiplier: { [SEASONS.SUMMER]: 1.3, default: 1.0 },
    size_tiles: 3,
    population_required: 0
  },
  zoo: {
    id: 'zoo',
    type: BUILDING_TYPES.AMENITY,
    name: 'Zoo',
    revenue_base: 8000,
    build_cost: 5600,
    population_min: 0,
    population_max: 0,
    jobs_available: 20,
    happiness_effect: 50,
    seasonal_multiplier: { default: 1.0 },
    size_tiles: 12,
    population_required: 0
  }
};

// Helper to get all buildings as array
export const BUILDINGS_ARRAY = Object.values(BUILDINGS);

// Helper to get buildings by type
export function getBuildingsByType(type) {
  return BUILDINGS_ARRAY.filter(b => b.type === type);
}

// Helper to get building by ID
export function getBuildingById(id) {
  return BUILDINGS[id];
}

// Get buildings that match manager's preferences
export function getBuildingsForPreferences(preferences, population) {
  return BUILDINGS_ARRAY.filter(building => {
    // Check population requirement
    if (building.population_required > population) {
      return false;
    }
    
    // Check if manager likes this building type
    const preference = preferences[building.type] || 0;
    return preference > 0;
  });
}
