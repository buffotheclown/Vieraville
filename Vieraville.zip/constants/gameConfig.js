/**
 * gameConfig.js
 * Core game configuration constants
 * All timing, grid, costs, and win/lose conditions
 */

export const GRID = {
  WIDTH: 100,              // tiles
  HEIGHT: 100,             // tiles
  TILE_SIZE: 32,           // pixels
  CANVAS_WIDTH: 3200,      // pixels (100 * 32)
  CANVAS_HEIGHT: 3200      // pixels (100 * 32)
};

export const TIME = {
  MONTH_DURATION: 20000,   // milliseconds (20 seconds = normal speed)
  MONTHS_PER_SEASON: 3,
  SEASONS_PER_YEAR: 4,
  MONTHS_PER_YEAR: 12
};

export const GAME_SPEED = {
  HALF: 0.5,     // 30 seconds per month
  NORMAL: 1.0,   // 20 seconds per month
  DOUBLE: 2.0    // 10 seconds per month
};

export const MONTHS = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

export const SEASONS = {
  SPRING: 'Spring',
  SUMMER: 'Summer',
  FALL: 'Fall',
  WINTER: 'Winter'
};

// Map month index to season
export const MONTH_TO_SEASON = {
  0: SEASONS.WINTER,   // January
  1: SEASONS.WINTER,   // February
  2: SEASONS.SPRING,   // March
  3: SEASONS.SPRING,   // April
  4: SEASONS.SPRING,   // May
  5: SEASONS.SUMMER,   // June
  6: SEASONS.SUMMER,   // July
  7: SEASONS.SUMMER,   // August
  8: SEASONS.FALL,     // September
  9: SEASONS.FALL,     // October
  10: SEASONS.FALL,    // November
  11: SEASONS.WINTER   // December
};

export const STARTING = {
  BUDGET: 5000000,         // $5M
  YEAR: 1,
  MONTH_INDEX: 0,          // January
  POPULATION: 0,
  HAPPINESS: 100
};

export const COSTS = {
  ROAD_PER_TILE: 200,           // $200
  MANAGER_SALARY_BASE: 100000,  // $100K per year base salary
  BUILDING_MAINTENANCE: 50,     // $50 per building per month
  MANAGER_RAISE: 50000          // $50K per raise (one-time cost)
};

export const MANAGER_SALARY = {
  BASE_ANNUAL: 100000,          // $100K per year
  RAISE_INCREASE: 50000         // Each raise adds $50K per year
};

export const TAX = {
  RATE: 0.08,                   // 8% tax rate
  COLLECTION_MONTH: 11          // December (end of winter, month index 11)
};

export const MANAGER_LIMITS = {
  MAX_MANAGERS: Infinity,  // No limit - hire as many managers as you want!
  UNLOCK_SECOND_AT_POP: 0,    // Can hire immediately
  UNLOCK_THIRD_AT_POP: 0      // Can hire immediately
};

export const MANAGER_STATS = {
  STARTING_HAPPINESS: 100,
  STARTING_EFFICIENCY: 100,
  RAISE_HAPPINESS_BONUS: 5,
  UNHAPPY_THRESHOLD: 50,
  RELATIONSHIP_BONUS: 10,
  RELATIONSHIP_PENALTY: 15
};

export const WIN_CONDITIONS = {
  TARGET_POPULATION: 16000,
  MIN_HAPPINESS: 70            // percentage
};

export const LOSE_CONDITIONS = {
  MIN_HAPPINESS: 0             // percentage
};

export const GAME_STATES = {
  TITLE: 'title',
  MANAGER_SELECTION: 'manager_selection',
  PLAYING: 'playing',
  VICTORY: 'victory',
  DEFEAT: 'defeat'
};
