/**
 * managerData.js
 * All 10 manager definitions with specialties, relationships, and build preferences
 */

export const MANAGER_SPECIALTIES = {
  POP_GROWTH: 'Pop Growth',
  COMMERCIAL_FOCUS: 'Commercial Focus',
  ECO_CONSCIOUS: 'Eco-Conscious',
  CELERY_QUEEN: 'Celery Queen',
  INDUSTRIAL_BARON: 'Industrial Baron',
  LUXURY_DEVELOPER: 'Luxury Developer',
  THRIFTY_BUILDER: 'Thrifty Builder',
  BALANCED_APPROACH: 'Balanced Approach',
  RESIDENT_FIRST: 'Resident-First',
  PROFIT_MAXIMIZER: 'Profit Maximizer'
};

export const MANAGERS = [
  {
    id: 'maria_chen',
    name: 'Maria Chen',
    specialty: MANAGER_SPECIALTIES.POP_GROWTH,
    flavor_text: 'I believe in density and walkable neighborhoods. Let\'s grow this town!',
    portrait_asset: 'maria_portrait.png',
    starting_happiness: 100,
    starting_efficiency: 100,
    likes: ['robert_lang'],
    dislikes: ['sarah_kim'],
    specialty_effect: {
      type: 'population_bonus',
      value: 0.5  // +50% to residential capacity
    },
    build_preferences: {
      residential: 0.5,
      commercial: 0.2,
      amenity: 0.3,
      industrial: 0.0,
      agricultural: 0.0,
      ranch: 0.0
    }
  },
  {
    id: 'robert_lang',
    name: 'Robert Lang',
    specialty: MANAGER_SPECIALTIES.ECO_CONSCIOUS,
    flavor_text: 'Sustainable building practices create lasting value for generations.',
    portrait_asset: 'robert_portrait.png',
    starting_happiness: 100,
    starting_efficiency: 100,
    likes: ['maria_chen', 'carlos_mendez'],
    dislikes: ['tony_russo'],
    specialty_effect: {
      type: 'longevity',
      value: 0.01  // +1% revenue per year per building
    },
    build_preferences: {
      residential: 0.2,
      commercial: 0.1,
      amenity: 0.3,
      industrial: 0.0,
      agricultural: 0.3,
      ranch: 0.1
    }
  },
  {
    id: 'sarah_kim',
    name: 'Sarah Kim',
    specialty: MANAGER_SPECIALTIES.CELERY_QUEEN,
    flavor_text: 'Viera\'s celery heritage is our competitive advantage. Let\'s capitalize on it!',
    portrait_asset: 'sarah_portrait.png',
    starting_happiness: 100,
    starting_efficiency: 100,
    likes: ['carlos_mendez'],
    dislikes: ['maria_chen', 'priya_patel'],
    specialty_effect: {
      type: 'celery_bonus',
      value: 0.5  // +50% to celery farm revenue
    },
    build_preferences: {
      residential: 0.0,
      commercial: 0.1,
      amenity: 0.0,
      industrial: 0.1,
      agricultural: 0.7,  // Heavy celery preference
      ranch: 0.1
    }
  },
  {
    id: 'tony_russo',
    name: 'Tony Russo',
    specialty: MANAGER_SPECIALTIES.INDUSTRIAL_BARON,
    flavor_text: 'Jobs and industry drive prosperity. Everything else follows.',
    portrait_asset: 'tony_portrait.png',
    starting_happiness: 100,
    starting_efficiency: 100,
    likes: ['james_cooper'],
    dislikes: ['robert_lang', 'priya_patel'],
    specialty_effect: {
      type: 'job_bonus',
      value: 0.25  // +25% jobs in industrial buildings
    },
    build_preferences: {
      residential: 0.1,
      commercial: 0.2,
      amenity: 0.0,
      industrial: 0.6,
      agricultural: 0.0,
      ranch: 0.1
    }
  },
  {
    id: 'priya_patel',
    name: 'Priya Patel',
    specialty: MANAGER_SPECIALTIES.LUXURY_DEVELOPER,
    flavor_text: 'Quality over quantity. Let\'s build a community people aspire to join.',
    portrait_asset: 'priya_portrait.png',
    starting_happiness: 100,
    starting_efficiency: 100,
    likes: ['emily_nguyen'],
    dislikes: ['sarah_kim', 'tony_russo', 'david_brown'],
    specialty_effect: {
      type: 'happiness_bonus',
      value: 0.5  // +50% happiness from her buildings
    },
    build_preferences: {
      residential: 0.3,
      commercial: 0.2,
      amenity: 0.4,
      industrial: 0.0,
      agricultural: 0.0,
      ranch: 0.1
    }
  },
  {
    id: 'carlos_mendez',
    name: 'Carlos Mendez',
    specialty: MANAGER_SPECIALTIES.THRIFTY_BUILDER,
    flavor_text: 'Every dollar saved is a dollar earned. Efficiency is my middle name.',
    portrait_asset: 'carlos_portrait.png',
    starting_happiness: 100,
    starting_efficiency: 100,
    likes: ['sarah_kim', 'robert_lang', 'david_brown'],
    dislikes: [],
    specialty_effect: {
      type: 'cost_reduction',
      value: 0.15  // -15% build costs
    },
    build_preferences: {
      residential: 0.25,
      commercial: 0.25,
      amenity: 0.1,
      industrial: 0.2,
      agricultural: 0.15,
      ranch: 0.05
    }
  },
  {
    id: 'emily_nguyen',
    name: 'Emily Nguyen',
    specialty: MANAGER_SPECIALTIES.BALANCED_APPROACH,
    flavor_text: 'A well-rounded town needs a mix of everything. Balance is key.',
    portrait_asset: 'emily_portrait.png',
    starting_happiness: 100,
    starting_efficiency: 100,
    likes: ['priya_patel', 'james_cooper'],
    dislikes: [],
    specialty_effect: {
      type: 'efficiency_bonus',
      value: 0.2  // +20% plan generation speed
    },
    build_preferences: {
      residential: 0.2,
      commercial: 0.2,
      amenity: 0.2,
      industrial: 0.15,
      agricultural: 0.15,
      ranch: 0.1
    }
  },
  {
    id: 'david_brown',
    name: 'David Brown',
    specialty: MANAGER_SPECIALTIES.RESIDENT_FIRST,
    flavor_text: 'Residents are our priority. Education and housing come before profit.',
    portrait_asset: 'david_portrait.png',
    starting_happiness: 100,
    starting_efficiency: 100,
    likes: ['carlos_mendez'],
    dislikes: ['priya_patel', 'james_cooper'],
    specialty_effect: {
      type: 'school_priority',
      value: true  // Builds school at 4K then every 8K (others every 8K only)
    },
    build_preferences: {
      residential: 0.5,
      commercial: 0.3,  // Commercial includes schools
      amenity: 0.2,
      industrial: 0.0,
      agricultural: 0.0,
      ranch: 0.0
    }
  },
  {
    id: 'james_cooper',
    name: 'James Cooper',
    specialty: MANAGER_SPECIALTIES.PROFIT_MAXIMIZER,
    flavor_text: 'Revenue is the lifeblood of this town. Let\'s maximize returns.',
    portrait_asset: 'james_portrait.png',
    starting_happiness: 100,
    starting_efficiency: 100,
    likes: ['tony_russo', 'emily_nguyen'],
    dislikes: ['david_brown'],
    specialty_effect: {
      type: 'revenue_bonus',
      value: 0.15  // +15% revenue from his buildings
    },
    build_preferences: {
      residential: 0.1,
      commercial: 0.4,
      amenity: 0.2,  // Golf course specifically
      industrial: 0.2,
      agricultural: 0.0,
      ranch: 0.1
    }
  },
  {
    id: 'lisa_martinez',
    name: 'Lisa Martinez',
    specialty: MANAGER_SPECIALTIES.COMMERCIAL_FOCUS,
    flavor_text: 'Retail and services create vibrant communities. Let\'s bring commerce to Viera!',
    portrait_asset: 'lisa_portrait.png',
    starting_happiness: 100,
    starting_efficiency: 100,
    likes: [],
    dislikes: [],
    specialty_effect: {
      type: 'commercial_bonus',
      value: 0.3  // +30% to commercial building revenue
    },
    build_preferences: {
      residential: 0.2,
      commercial: 0.6,
      amenity: 0.2,
      industrial: 0.0,
      agricultural: 0.0,
      ranch: 0.0
    }
  }
];

// Helper to get manager by ID
export function getManagerById(id) {
  return MANAGERS.find(m => m.id === id);
}

// Helper to get available managers (not hired)
export function getAvailableManagers(hiredManagerIds) {
  return MANAGERS.filter(m => !hiredManagerIds.includes(m.id));
}

// Helper to get hired managers
export function getHiredManagers(hiredManagerIds) {
  return MANAGERS.filter(m => hiredManagerIds.includes(m.id));
}
