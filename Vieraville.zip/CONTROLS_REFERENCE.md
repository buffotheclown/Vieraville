# VieraVille - Controls & Features Reference

## 🎮 Camera Controls

### Mouse Controls
- **Click + Drag** - Pan camera around the map
- **Scroll Wheel** - Zoom in/out (0.5x to 2x)
- **Click Manager Card** - Open manager detail modal

### Keyboard Controls
- **W** - Pan camera up
- **A** - Pan camera left
- **S** - Pan camera down
- **D** - Pan camera right

## ⌨️ Keyboard Shortcuts

### Game Controls
- **Ctrl + S** (Windows/Linux) / **Cmd + S** (Mac) - Quick save game
- **M** - Toggle sound mute/unmute
- **Escape** - Close open modals (planned)

## 🔊 Sound System

### Sound Toggle
- **Button Location:** Top right of screen (speaker icon 🔊/🔇)
- **Keyboard Shortcut:** Press **M** to mute/unmute
- **Visual Feedback:** Icon changes and toast notification appears
- **Persistence:** Sound preference saved to browser localStorage

### Sound Types
You'll hear procedural sounds for:
- **UI Actions** - Button clicks, hovers, modal open/close
- **Money Events** - Revenue gains/losses, big payouts
- **Buildings** - Placement chords vary by building type
- **Managers** - Hiring, plans proposed/approved/denied
- **Game Events** - Random events, milestones, victory/defeat
- **Time** - Month changes, season transitions

## 👔 Manager Actions

### In Manager Panel (Left Sidebar)
- **Click Manager Card** - View details and current activity
- **Hire Button** - Open manager selection screen

### In Manager Detail Modal
- **Approve Plan** - Green checkmark - Manager begins construction
- **Deny Plan** - Red X - Manager goes back to planning
- **Give Raise** - Yellow button - Costs $50K, boosts happiness +5%
- **Fire Manager** - Red button - Removes manager permanently

## 💰 Budget Management

### Revenue System
- Calculated automatically every month (10 seconds real-time)
- Based on building types and seasonal multipliers
- Manager bonuses apply to their specialty buildings
- Check Dashboard Panel (right sidebar) for detailed breakdown

### Costs
- **Roads:** $200 per tile
- **Buildings:** Varies by type (see building info)
- **Manager Salaries:** $3K per month per manager
- **Building Maintenance:** $50 per building per month
- **Raises:** $50K one-time cost

## 📊 Dashboard Panel (Right Sidebar)

### Revenue Tab
- Revenue breakdown by building type
- Monthly income vs. costs
- Net profit/loss

### Population Tab
- Total population count
- Employed vs. unemployed breakdown
- Employment rate percentage

### Happiness Tab
- Overall town happiness (0-100%)
- Breakdown by factors:
  - Employment Rate (30% weight)
  - Building Diversity (20% weight)
  - Amenities (25% weight)
  - Housing Quality (25% weight)
  - Manager Relationships (15% weight)

### Buildings Tab
- Count of each building type
- Total buildings in town

## 🎯 Win/Lose Conditions

### Victory 🎉
- **Target:** 16,000 population + 70% happiness
- **Reward:** Victory modal with stats and credits
- **Option:** Continue playing after victory

### Defeat 💔
- **Condition 1:** Happiness drops to 0%
- **Condition 2:** Budget drops below -$100K (bankruptcy)
- **Result:** Game over, must restart

## 💾 Save/Load System

### Auto-Save
- Automatically saves every 30 seconds
- Saves to browser localStorage
- No manual action required

### Manual Save
- **Keyboard:** Ctrl+S / Cmd+S
- **Menu:** Click "Save/Load" button (planned)
- **Confirmation:** Toast notification appears

### Continue Game
- Title screen shows "Continue" if save exists
- Displays last save metadata (year, population)
- "New Game" overwrites existing save (with confirmation)

## 🎲 Random Events

### Frequency
- Occur approximately every 1 minute of gameplay
- Seasonal events have themed effects
- Some events offer choices (planned)

### Event Types
- **Positive:** Tourism booms, business grants, federal funding
- **Negative:** Hurricanes, economic downturns, scandals
- **Neutral:** News coverage, population shifts

## 🏆 Milestones

### Population Thresholds
- **500 Pop:** Unlock 2nd manager slot
- **1,000 Pop:** $500K bonus
- **5,000 Pop:** $1M bonus + efficiency boost
- **10,000 Pop:** $2M bonus + unlock 5th manager slot

### Rewards
- Cash bonuses added to budget
- Manager efficiency increases
- New manager slots unlocked
- Special building unlocks (planned)

## 👥 Manager Relationships

### Likes & Dislikes
- Each manager has preferences
- **Green Heart (💚):** Likes another manager (+10% happiness)
- **Broken Heart (💔):** Dislikes another manager (-15% happiness)
- Check Manager Selection screen for compatibility warnings

### Strategy Tips
- Hire compatible managers for maximum happiness
- Avoid hiring conflicting managers early game
- Relationship effects compound with multiple managers

## 🏗️ Building Strategy

### Building Types
- **Residential:** Houses, apartments, condos (population)
- **Commercial:** Shops, restaurants, services (revenue + jobs)
- **Industrial:** Factories, warehouses (high revenue, low happiness)
- **Civic:** Schools, hospitals, police (happiness + jobs)
- **Recreational:** Parks, golf, theme parks (happiness)

### Seasonal Multipliers
- Buildings perform better in certain seasons
- Check building details for seasonal bonuses
- Plan construction timing for maximum revenue

## 🗺️ Map Information

### Grid System
- 100x100 tile grid (3200x3200 pixels)
- Each tile is 32x32 pixels
- Three layers: Terrain (static), Roads (dynamic), Buildings (dynamic)

### Entry Points
- Dark blue tiles on edges of map
- Managers start here when constructing
- Roads must connect from entry points

### Terrain Types
- **Grass:** Standard buildable land
- **Water:** Lake, ocean (unbuildable)
- **Beach:** Sand near water (buildable)
- **Wetland:** Swamp areas (unbuildable)

## 🎨 UI Panels

### Top HUD
- Logo, date/season display, budget, population, happiness, sound toggle

### Manager Panel (Left)
- List of hired managers
- Current activity status
- Hire additional managers button

### Dashboard Panel (Right)
- Detailed stats and breakdowns
- Tabs for revenue, population, happiness, buildings

### Notification Toasts (Bottom Right)
- Auto-dismiss after 5 seconds
- Show important game events
- Monthly revenue updates

## 🐛 Troubleshooting

### Sound Not Playing
1. Click anywhere on screen to initialize audio
2. Check sound toggle button (should show 🔊)
3. Try pressing **M** to toggle sound
4. Check browser console for errors

### Performance Issues
1. Zoom out to see less detail
2. Close other browser tabs
3. Refresh page to clear memory
4. Check browser developer tools for issues

### Save Not Loading
1. Check that localStorage is enabled in browser
2. Try exporting save as JSON backup
3. Clear browser cache (may delete saves)
4. Check browser console for errors

---

**Pro Tips:**
- Start with a balanced manager (like Alex Chen)
- Build residential first to grow population
- Watch seasonal multipliers for revenue optimization
- Keep happiness above 50% to avoid penalties
- Save frequently (Ctrl+S)
- Mute sound during long sessions (M key)

**Version:** 1.0
**Last Updated:** Current Session
