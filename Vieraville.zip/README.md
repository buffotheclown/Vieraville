# 🏖️ VieraVille Private Town Tycoon

A 2D top-down pixel-art town builder/management tycoon game where you hire autonomous AI managers to build Florida's premier master-planned community.

![Version](https://img.shields.io/badge/version-1.0%20GOLD-brightgreen)
![Status](https://img.shields.io/badge/status-production%20ready-success)
![Completion](https://img.shields.io/badge/completion-100%25-blue)

---

## 🎮 Game Overview

Build and manage a thriving Florida community from a $5 million budget. Hire up to 5 specialized managers who autonomously generate construction plans, manage their own building projects, and contribute to your town's growth. Navigate seasonal changes, random events, and complex economic systems to reach the victory condition: **16,000 population with 70% happiness!**

### Key Features
- ✅ **10 Unique AI Managers** with specialties and personalities
- ✅ **20 Building Types** across 6 categories
- ✅ **Autonomous AI** - Managers plan and build independently
- ✅ **Complex Economy** - Seasonal multipliers, manager bonuses, monthly calculations
- ✅ **Relationship System** - Managers like/dislike each other
- ✅ **Random Events** - Hurricanes, tourism booms, scandals
- ✅ **Procedural Sound** - 25+ unique sounds with Tone.js
- ✅ **Save/Load System** - Auto-save + manual quick save
- ✅ **Professional UI** - Dashboard, notifications, detailed stats

---

## 🚀 Quick Start

### New Players: Read the [QUICK_START_GUIDE.md](QUICK_START_GUIDE.md) 📖
A step-by-step walkthrough for your first 10 minutes!

### Playing the Game
1. **Open** `index.html` in a modern browser (Chrome, Firefox, Safari)
2. **Click anywhere** to initialize sound (browser requirement)
3. **Hire your first manager** from the selection screen (try Alex Chen!)
4. **Approve construction plans** as they're proposed
5. **Watch your town grow** month by month
6. **Reach 16,000 population** with 70%+ happiness to win!

### Controls
- **Mouse Drag / WASD** - Pan camera
- **Scroll Wheel** - Zoom in/out
- **M Key** - Mute/unmute sound
- **Ctrl+S / Cmd+S** - Quick save
- **Click Manager Cards** - View details and approve/deny plans

---

## 📁 Project Structure

```
/
├── index.html                    # Entry point
├── App.js                        # Main React app
├── README.md                     # This file
├── COMPLETE_FEATURE_LIST.md      # Full feature documentation
├── IMPLEMENTATION_PLAN.md        # Technical roadmap
├── SOUND_SYSTEM.md               # Audio architecture docs
├── CONTROLS_REFERENCE.md         # Player guide
│
├── constants/                    # Game configuration
│   ├── gameConfig.js            # Grid, time, costs, win/lose
│   ├── buildingData.js          # 20 building definitions
│   ├── managerData.js           # 10 manager definitions
│   └── uiConstants.js           # Colors, sizes, styling
│
├── state/                        # State management
│   ├── GameState.js             # Central game state singleton
│   └── StateManager.js          # React context provider
│
├── managers/                     # Game systems
│   ├── TimeManager.js           # Month/season/year progression
│   ├── ManagerAI.js             # Finite state machine AI
│   ├── RevenueManager.js        # Economic calculations
│   ├── PopulationManager.js     # Population & happiness
│   ├── EventManager.js          # Random events
│   ├── SoundManager.js          # Procedural audio (Tone.js)
│   ├── SaveManager.js           # LocalStorage persistence
│   └── ...
│
├── services/                     # Business logic
│   ├── TiledLoader.js           # Map loading
│   ├── PlanGenerator.js         # AI plan generation
│   ├── BuildingPlacer.js        # Building placement
│   ├── RoadBuilder.js           # Pathfinding for roads
│   └── RelationshipService.js   # Manager compatibility
│
├── components/                   # React UI components
│   ├── scenes/                  # Main screens
│   │   ├── TitleScreen.js
│   │   ├── ManagerSelection.js
│   │   └── GameScene.js
│   ├── hud/                     # HUD elements
│   │   ├── TopHUD.js
│   │   ├── ManagerPanel.js
│   │   ├── DashboardPanel.js
│   │   └── NotificationToast.js
│   ├── modals/                  # Popup windows
│   │   ├── ManagerDetailModal.js
│   │   ├── EventModal.js
│   │   ├── VictoryModal.js
│   │   └── DefeatModal.js
│   └── canvas/                  # Rendering
│       ├── GameCanvas.js
│       └── EntityLayer.js
│
└── utils/                        # Helper functions
    └── GridUtils.js
```

---

## 🎯 Game Systems

### Manager AI
Each manager operates with a **Finite State Machine:**
1. **Idle** - Wait for cooldown, then generate plan
2. **Proposing** - Present plan to player for approval
3. **Approved** - Plan accepted, ready to build
4. **Building** - Construct roads and buildings tile-by-tile

Managers have **specialties** (+20-30% bonus) and **relationships** (likes/dislikes affecting happiness).

### Economic System
- **Monthly Revenue** calculated from all buildings
- **Seasonal Multipliers** (e.g., Beach +50% in Summer)
- **Manager Bonuses** apply to specialty buildings
- **Costs:** Roads ($200/tile), salaries ($3K/month), maintenance ($50/building)

### Happiness System
Multi-factor calculation with weighted components:
- Employment Rate (30%)
- Building Diversity (20%)
- Amenities (25%)
- Housing Quality (25%)
- Manager Relationships (15%)

### Sound System
Procedural audio with **Tone.js** - no audio files needed!
- 25+ unique sound effects
- Type-specific building chords
- Event-driven music cues
- Mute toggle (M key)
- Persistent preferences

---

## 📊 Building Types

### Residential (6 types)
Small/Medium/Large Houses, Apartments, Condos, Luxury Estates

### Commercial (5 types)
Shops, Restaurants, Offices, Shopping Malls, Business Parks

### Industrial (3 types)
Small/Large Factories, Warehouses

### Civic (3 types)
Schools, Hospitals, Police Stations

### Recreational (2 types)
Parks, Golf Courses

### Agricultural (1 type)
Farms

*Each with unique costs, population, jobs, revenue, and seasonal bonuses*

---

## 👔 Manager Roster

1. **Alex Chen** - Balanced Developer
2. **Maria Rodriguez** - Residential Specialist
3. **James Thompson** - Commercial Expert
4. **Sarah Williams** - Industrial Tycoon
5. **David Park** - Civic Leader
6. **Emily Zhang** - Recreational Guru
7. **Michael O'Brien** - Agricultural Expert
8. **Priya Patel** - Mixed-Use Visionary
9. **Carlos Mendez** - Ranch Manager
10. **Lisa Anderson** - Luxury Developer

*Each with unique bonuses, relationships, and personalities*

---

## 🏆 Win/Lose Conditions

### Victory 🎉
- Reach **16,000 population**
- Maintain **70%+ happiness**
- Unlock victory modal with stats
- Option to continue playing

### Defeat 💔
- Happiness drops to **0%**
- Budget falls below **-$100K** (bankruptcy)
- Game over, must restart

---

## 💾 Save System

- **Auto-save** every 30 seconds to LocalStorage
- **Manual save** with Ctrl+S / Cmd+S
- **Export/Import** saves as JSON
- **Continue** from title screen if save exists
- Full game state restoration

---

## 🔊 Sound Features

All sounds are **procedurally generated** using Tone.js:

- **UI Sounds** - Clicks, hovers, modal open/close
- **Money Sounds** - Coin gain/loss, big payouts
- **Building Sounds** - Chords vary by building type
- **Manager Sounds** - Hired melody, plan feedback
- **Event Sounds** - Positive/negative progressions
- **Ambient Sounds** - Month changes, seasons

Toggle with **M key** or click the 🔊 button!

---

## 🛠️ Technology Stack

- **Framework:** React 18 (createElement, no JSX)
- **Architecture:** ESM modules, importmap, buildless
- **Rendering:** HTML5 Canvas 2D
- **Audio:** Tone.js (Web Audio API)
- **Storage:** LocalStorage
- **Map Format:** Tiled JSON (optional)

**No build tools required!** Pure ESM modules running directly in browser.

---

## 📚 Documentation

### For Players
- **[QUICK_START_GUIDE.md](QUICK_START_GUIDE.md)** - 🌟 **Start here!** Your first 10 minutes
- **[CONTROLS_REFERENCE.md](CONTROLS_REFERENCE.md)** - Complete controls & tips reference

### For Developers
- **[COMPLETE_FEATURE_LIST.md](COMPLETE_FEATURE_LIST.md)** - Full feature documentation
- **[IMPLEMENTATION_PLAN.md](IMPLEMENTATION_PLAN.md)** - Technical roadmap & phase tracking
- **[DESIGN_DOCUMENT_v2.md](DESIGN_DOCUMENT_v2.md)** - Original design specifications

### For Audio/QA
- **[SOUND_SYSTEM.md](SOUND_SYSTEM.md)** - Audio architecture documentation
- **[SOUND_IMPLEMENTATION_SUMMARY.md](SOUND_IMPLEMENTATION_SUMMARY.md)** - Sound feature summary
- **[SOUND_TEST_CHECKLIST.md](SOUND_TEST_CHECKLIST.md)** - QA testing guide

---

## 🎨 Credits

**Game Design & Development**
- Full-stack implementation in React/Canvas/Tone.js
- Buildless architecture with ESM modules
- Procedural audio system
- Autonomous AI managers

**Inspiration**
- Viera, Florida - Master-planned community by the Duda family

**Created for**
- 3-Day Game Jam Project
- Rosebud AI Platform

---

## 📈 Project Stats

- **Files:** 45+
- **Lines of Code:** 8,000+
- **Components:** 20+
- **Managers:** 10 unique AIs
- **Buildings:** 20 types
- **Sound Effects:** 25+
- **Development Time:** 30+ hours
- **Completion:** 100%

---

## 🐛 Known Limitations

### By Design
- First click required to initialize audio (browser security)
- Population updates silent (covered by month changes)
- Building sounds throttled to 200ms (prevents spam)

### Optional Enhancements
- Entity walk animations (sprite sheets)
- Tile-by-tile construction animation
- Background music loops
- Event choice system

---

## 🚀 Getting Started (Development)

### Prerequisites
- Modern web browser (Chrome, Firefox, Safari)
- Local web server (for CORS if needed)
- No build tools required!

### Running Locally
1. Clone or download the repository
2. Open `index.html` in browser
3. Or use a simple HTTP server:
   ```bash
   python -m http.server 8000
   # Navigate to http://localhost:8000
   ```

### File Structure
All code is organized by responsibility:
- **constants/** - Configuration (no logic)
- **state/** - Data management
- **managers/** - Game systems
- **services/** - Business logic
- **components/** - UI rendering
- **utils/** - Helper functions

---

## 📝 License

Created for educational and portfolio purposes.
Inspired by real-world master-planned communities.

---

## 🎉 Status

**✅ Version 1.0 GOLD - Production Ready**

All core systems implemented, tested, and documented.
Ready for release, playtesting, and iteration!

**Win condition:** Build to 16K population with 70% happiness
**Good luck, Developer!** 🏖️

---

**Made with ❤️ using React, Canvas, and Tone.js**
**No build tools • Pure ESM modules • Procedural audio**
