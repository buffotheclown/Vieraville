# VieraVille - Game Jam Features

## New Interactive Features for Players 🎮

### 1. Building/Road Inspection System 🔍
**Click any building or road tile to view detailed information:**

**Buildings show:**
- Name, type, and subtype
- Location coordinates
- Year built and age
- Which manager built it
- Current population (if residential)
- Employment rate and workers (if has jobs)
- Revenue per season
- Happiness contribution
- Repair status and cost

**Roads show:**
- Location coordinates
- Road quality
- Orientation
- Repair status and cost

### 2. Demolition System 🏚️
**Click buildings to demolish them:**
- Receive 50% refund of estimated building value
- Instantly removes building from grid
- Frees up workers for other buildings
- Strategic tool for reshaping your town
- Confirmation dialog prevents accidents

### 3. Emergency Repair System 🔧
**Buildings and roads degrade over time:**
- 15% chance per year for any tile to need repairs
- Tiles needing repair show yellow overlay + 🔧 wrench icon
- Click to view repair cost (1% of original build cost)
- Pay to repair immediately
- **Happiness penalty:** Every 10 tiles in disrepair = -1% happiness (PERMANENT)
- Repairing tiles does NOT restore lost happiness
- Encourages proactive maintenance

**Repair Costs:**
- Roads: $200 per tile (matches build cost)
- Buildings: 1% of estimated value (varies by building)

## New Events System 📰

### Added 10 New Negative Events:
All events have weighted random chances (25% chance per season)

1. **🦠 Red Tide Outbreak**
   - $45K cleanup cost
   - -4% happiness for 3 months

2. **🕳️ Sinkhole Emergency**
   - $90K emergency repairs
   - Immediate cost spike

3. **💧 Water Shortage**
   - $25K water imports
   - -6% happiness for 4 months
   - Extended drought impact

4. **⚡ Major Power Outage**
   - $35K grid repairs
   - -7% happiness for 2 months

5. **🐍 Invasive Python Problem**
   - $20K removal program
   - -3% happiness for 6 months
   - Florida-specific threat!

6. **⚖️ Zoning Lawsuit**
   - $60K legal fees and settlement
   - Pure financial hit

7. **🌉 Infrastructure Failure**
   - $80K replacement cost
   - -5% happiness for 3 months

8. **☣️ Chemical Spill**
   - $55K hazmat cleanup
   - -8% happiness for 4 months
   - Severe happiness impact

9. **🕵️ Corruption Scandal**
   - $40K investigations
   - -10% happiness for 5 months
   - Most severe happiness penalty

10. **💨 Wildfire Smoke**
    - $15K air quality measures
    - -4% happiness for 2 months
    - Environmental disaster

### Existing Events (For Reference):
**Positive:**
- Tourism Boom (+$50K)
- Federal Grant (+$100K)
- Population Influx (+5% residents)
- Perfect Weather (+5% happiness, 3 months)

**Negative (Original):**
- Hurricane Damage (-$75K)
- Flooding (-$30K, -3% happiness, 2 months)
- Economic Downturn (-$40K)
- Heat Wave (-5% happiness, 3 months)

**Mixed:**
- Local Festival (-$20K, +8% happiness, 2 months)
- Sports Victory (+10% happiness, 4 months)

**Total Events: 20** (4 positive, 14 negative, 2 mixed)

## Technical Implementation 🛠️

### New Files Created:
1. **`/managers/MaintenanceManager.js`**
   - Handles degradation checks (yearly)
   - Manages repair costs and logic
   - Calculates happiness penalties
   - Provides building/road inspection info
   - Handles demolition with refunds

2. **`/components/modals/InspectionModal.js`**
   - Beautiful UI for viewing tile details
   - Repair and demolish buttons
   - Color-coded stats (employment, happiness)
   - Conditional rendering based on tile type

### Modified Files:
1. **`/managers/EventManager.js`** - Added 10 new negative events
2. **`/managers/TimeManager.js`** - Integrated degradation checks on year change
3. **`/state/GameState.js`** - Added year_change event emission
4. **`/components/scenes/GameScene.js`** - Added tile click handling and inspection modal
5. **`/components/canvas/GameCanvas.js`** - Added click detection and repair indicators
6. **`/managers/GridManager.js`** - Added clearBuilding() method

### Visual Indicators:
- Yellow overlay on tiles needing repair
- 🔧 Wrench icon on damaged tiles
- Visible from any zoom level
- Helps players find maintenance needs quickly

### Game Balance:
- Degradation rate: 15% per year (balanced to create steady maintenance pressure)
- Happiness penalty: -1% per 10 tiles in disrepair (encourages repairs)
- Repair costs: Minimal (1% of value) to not bankrupt players
- Demolition refund: 50% to discourage spam but allow strategic changes

## Player Engagement 🎯

**Before:** Players watched managers build autonomously
**After:** Players can:
- Inspect any tile for detailed info
- Repair damaged infrastructure
- Demolish unwanted buildings
- Make strategic decisions about maintenance
- React to more varied random events
- Balance short-term costs vs long-term happiness

**Fidget Factor:** Click-and-explore gameplay while automation runs!

## Future Enhancement Ideas 💡
- Road quality upgrades (Dirt → Paved → Highway)
- Building customization (rename, color palettes)
- Landmark placement (fountains, parks, statues)
- Zone designation tool
- Traffic visualization overlay
- Seasonal decorations
