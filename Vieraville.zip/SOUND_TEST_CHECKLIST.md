# VieraVille Sound System - Test Checklist

## Pre-Game Testing

### Title Screen
- [ ] Button hover sounds play on mouse over
- [ ] Start/Continue button plays success sound
- [ ] Cancel on "New Game" dialog plays error sound
- [ ] Sound persists across page reloads (localStorage)

## Manager Selection

### Selection Screen
- [ ] Clicking available manager plays UI click
- [ ] Clicking hired manager plays error sound
- [ ] Manager with conflict shows warning and plays error
- [ ] "Hire Manager" button plays manager hired melody (C-E-G-C ascending)

## Main Game

### Monthly/Seasonal Sounds
- [ ] Month change plays subtle ambient tone every 10 seconds
- [ ] Season change plays themed note (Spring=E, Summer=G, Fall=A, Winter=C)
- [ ] Year change doesn't have separate sound (covered by month)

### Revenue Sounds
- [ ] Positive monthly revenue plays coin gain (metallic chime)
- [ ] Negative monthly revenue plays coin loss (lower metallic tone)
- [ ] Zero revenue plays no sound

### Manager Actions
- [ ] Plan proposed plays two-note question (A4-E5)
- [ ] Plan approved plays success chime
- [ ] Plan denied plays error tone
- [ ] Give raise subtracts budget (coin loss sound)
- [ ] Fire manager plays error tone

### Building Placement
- [ ] Residential building plays C-E-G major chord
- [ ] Commercial building plays D-F#-A major chord
- [ ] Industrial building plays E-G-B major chord
- [ ] Civic building plays F-A-C major chord
- [ ] Recreational building plays G-B-D major chord
- [ ] Construction placement plays brief noise burst

### Events
- [ ] Positive event (e.g., Tourism Boom) plays rising major chord progression
- [ ] Negative event (e.g., Hurricane) plays falling minor chord progression
- [ ] Neutral event plays stable two-note chord

### Milestones
- [ ] Population milestone (500, 1K, 5K, 10K) plays grand fanfare
- [ ] Big money reward plays rapid coin succession (5 chimes)
- [ ] Milestone modal opens with appropriate sounds

### Victory/Defeat
- [ ] Victory condition triggers extended celebratory melody
- [ ] Defeat condition triggers somber descending melody
- [ ] End game modals open/close with modal sounds

### UI Interactions
- [ ] All buttons play UI click on press
- [ ] Manager cards play UI click when opened
- [ ] Modal open plays ascending two-note arpeggio
- [ ] Modal close plays descending two-note arpeggio
- [ ] Error actions (can't afford, invalid) play error tone
- [ ] Success confirmations play success chime

### Sound Controls
- [ ] Sound toggle button (🔊/🔇) in TopHUD works
- [ ] Muting stops all sounds immediately
- [ ] Unmuting plays test click sound
- [ ] Sound preference persists across page reloads
- [ ] Sound toggle updates icon in real-time

### Save/Load
- [ ] Manual save (Ctrl+S) doesn't have sound (silent auto-save)
- [ ] Save modal open plays modal open sound
- [ ] Save modal close plays modal close sound
- [ ] Load game plays success sound
- [ ] Delete save shows confirmation (no specific sound)

## Edge Cases

### Audio Context
- [ ] First click anywhere initializes audio context
- [ ] "Audio context started" logged to console
- [ ] Test sound plays on successful initialization
- [ ] No errors if audio context fails to initialize
- [ ] Graceful fallback if Tone.js fails to load

### Performance
- [ ] No audio stuttering during gameplay
- [ ] No memory leaks over extended play sessions
- [ ] Multiple simultaneous sounds don't cause issues
- [ ] Sound cleanup on component unmount

### Browser Compatibility
- [ ] Chrome/Edge - Full support
- [ ] Firefox - Full support
- [ ] Safari - Auto-play policy handled
- [ ] Mobile browsers - Touch interaction initializes audio

## Volume Testing
- [ ] Master volume defaults to -10dB (comfortable level)
- [ ] Volume persists across sessions
- [ ] All sounds respect master volume
- [ ] Volume ramps smoothly when changed

## Stress Testing
- [ ] Rapid clicking doesn't cause audio glitches
- [ ] Multiple events in quick succession sound natural
- [ ] Month changes during event modals don't conflict
- [ ] Victory/defeat sounds override other sounds appropriately

## Accessibility
- [ ] Game fully playable with sound disabled
- [ ] Visual feedback accompanies all sound cues
- [ ] Sound toggle is easily discoverable
- [ ] No critical information conveyed by sound alone

## Known Behaviors (Expected)
- First click initializes audio (browser security requirement)
- Month change sound is subtle and non-intrusive
- Population updates don't trigger separate sound (covered by month change)
- Multiple buildings placed rapidly may overlap chords (acceptable)
- Season change only plays on first month of season

## Bugs to Watch For
- [ ] Sound continuing after mute
- [ ] Volume not persisting
- [ ] Audio context not initializing on mobile
- [ ] Memory leaks from undisposed synths
- [ ] Conflicting sounds during rapid interactions

---

## Test Results Template

**Browser:** _______________
**Date:** _______________
**Tester:** _______________

**Issues Found:**
1. 
2. 
3. 

**Notes:**


---

**Status:** Ready for Testing
**Last Updated:** Current Session
